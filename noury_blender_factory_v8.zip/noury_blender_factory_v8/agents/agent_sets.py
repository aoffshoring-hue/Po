#!/usr/bin/env python3
"""Sets: every filming location of the series.

terrain : "meadow" (hills) | "coast" (dunes + sea / lake)
props   : trees, pines, palms, houses, garden, rocks, fireflies
flags   : water, glow (magic), night (moon + stars), snow (snowfall, no grass), storm
To add a location, add an entry here; new prop families are built in blender/build_scene.py.
"""
import json
from pathlib import Path

LOCATIONS = {
    "meadow":           {"label": "la prairie", "sky": [0.38, 0.68, 0.95], "ground": [0.30, 0.62, 0.28],
                         "wind": 0.12, "terrain": "meadow", "props": ["trees"]},
    "storm_meadow":     {"label": "la prairie sous l'orage", "sky": [0.30, 0.38, 0.52], "ground": [0.22, 0.42, 0.24],
                         "wind": 1.0, "terrain": "meadow", "props": ["trees"], "storm": True},
    "forest":           {"label": "la forêt", "sky": [0.42, 0.66, 0.80], "ground": [0.20, 0.48, 0.22],
                         "wind": 0.35, "terrain": "meadow", "props": ["trees"]},
    "coast":            {"label": "la plage", "sky": [0.40, 0.72, 0.95], "ground": [0.88, 0.76, 0.52],
                         "wind": 0.5, "terrain": "coast", "water": True, "props": ["palms"]},
    "rocky_coast":      {"label": "la côte rocheuse", "sky": [0.34, 0.45, 0.60], "ground": [0.62, 0.58, 0.50],
                         "wind": 0.9, "terrain": "coast", "water": True, "props": ["rocks"], "storm": True},
    "magical_clearing": {"label": "la clairière magique", "sky": [0.45, 0.36, 0.72], "ground": [0.24, 0.52, 0.32],
                         "wind": 0.1, "terrain": "meadow", "props": ["trees", "fireflies"], "glow": True},
    "village":          {"label": "le village", "sky": [0.42, 0.70, 0.96], "ground": [0.55, 0.62, 0.32],
                         "wind": 0.15, "terrain": "meadow", "props": ["houses", "trees"]},
    "village_night":    {"label": "le village la nuit", "sky": [0.10, 0.12, 0.30], "ground": [0.30, 0.38, 0.25],
                         "wind": 0.08, "terrain": "meadow", "props": ["houses", "fireflies"], "night": True,
                         "glow": True},
    "garden":           {"label": "le jardin", "sky": [0.45, 0.72, 0.95], "ground": [0.34, 0.60, 0.26],
                         "wind": 0.12, "terrain": "meadow", "props": ["garden", "trees"]},
    "night_forest":     {"label": "la forêt de nuit", "sky": [0.08, 0.10, 0.26], "ground": [0.14, 0.30, 0.18],
                         "wind": 0.15, "terrain": "meadow", "props": ["trees", "fireflies"], "night": True},
    "snowy_hill":       {"label": "la colline enneigée", "sky": [0.62, 0.74, 0.88], "ground": [0.86, 0.90, 0.96],
                         "wind": 0.3, "terrain": "meadow", "props": ["pines"], "snow": True},
    "desert_oasis":     {"label": "l'oasis", "sky": [0.50, 0.75, 0.95], "ground": [0.93, 0.74, 0.46],
                         "wind": 0.35, "terrain": "coast", "water": True, "props": ["palms", "rocks"]},
}


def main():
    out = Path(__file__).resolve().parent.parent / "export"
    out.mkdir(parents=True, exist_ok=True)
    (out / "sets_config.json").write_text(json.dumps({"environments": LOCATIONS}, ensure_ascii=False, indent=2),
                                          encoding="utf-8")
    print(f"[Sets] {len(LOCATIONS)} lieux de tournage")


if __name__ == "__main__":
    main()
