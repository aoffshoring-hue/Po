#!/usr/bin/env python3
"""Thumbnail 1280x720: joyful image of the finale + big readable title."""
import json
import subprocess
from pathlib import Path

from PIL import Image, ImageDraw, ImageEnhance, ImageFilter, ImageFont

FONTS = ["/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
         "/usr/share/fonts/dejavu-sans-fonts/DejaVuSans-Bold.ttf"]


def font(size):
    for f in FONTS:
        if Path(f).exists():
            return ImageFont.truetype(f, size)
    return ImageFont.load_default()


def main():
    base = Path(__file__).resolve().parent.parent
    out = base / "export"
    script = json.loads((out / "script_config.json").read_text(encoding="utf-8"))
    video = out / "FINAL_VIDEO.mp4"
    ts = script["scenes"][-1]["start"] + 1.5          # wide shot of the happy finale (everybody visible)
    vdur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0",
                                 str(video)], capture_output=True, text=True).stdout or 0)
    if ts >= vdur - 1:
        ts = vdur * 0.9
    grab = out / "thumb_src.png"
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-ss", f"{ts:.2f}", "-i", str(video), "-frames:v", "1", str(grab)],
                   check=True)
    img = Image.open(grab).convert("RGB").resize((1280, 720), Image.LANCZOS)
    img = ImageEnhance.Color(img).enhance(1.25)
    img = ImageEnhance.Contrast(img).enhance(1.08).filter(ImageFilter.UnsharpMask(2, 80, 2))
    d = ImageDraw.Draw(img)
    title = script["title"].split(":")[-1].strip().upper()
    f = font(84)
    while d.textlength(title, font=f) > 1180 and f.size > 40:
        f = font(f.size - 4)
    x = (1280 - d.textlength(title, font=f)) / 2
    d.text((x, 590), title, font=f, fill=(255, 236, 120), stroke_width=9, stroke_fill=(90, 20, 90))
    d.text((40, 30), "Yakine & Nour", font=font(44), fill=(255, 255, 255), stroke_width=6, stroke_fill=(220, 60, 130))
    img.save(out / "thumbnail.jpg", quality=90)
    print("[Thumbnail] thumbnail.jpg prête")


if __name__ == "__main__":
    main()
