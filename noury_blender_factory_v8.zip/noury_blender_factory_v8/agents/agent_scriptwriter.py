#!/usr/bin/env python3
"""Scriptwriter: validates the director plan and writes script_config.json."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import cast_library as CL  # noqa: E402


def main():
    base = Path(__file__).resolve().parent.parent
    out = base / "export"
    plan_path = out / "director_plan.json"
    if not plan_path.exists():
        raise FileNotFoundError("Run agent_director.py first")
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    for s in plan["scenes"]:
        present = {"Yakine", "Nour"} | {g["key"] for g in s.get("guests", [])}
        if not s.get("lines"):
            raise ValueError(f"Scene {s['id']} has no dialogue")
        for ln in s["lines"]:
            if ln["character"] not in CL.ALL:
                raise ValueError(f"Scene {s['id']}: unknown character {ln['character']}")
            if ln["character"] not in present:
                raise ValueError(f"Scene {s['id']}: {ln['character']} speaks but is not in the scene")
            if not ln["text"].strip():
                raise ValueError(f"Scene {s['id']}: empty line")
    (out / "script_config.json").write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")
    n = sum(len(s["lines"]) for s in plan["scenes"])
    print(f"[Scriptwriter] {len(plan['scenes'])} scènes, {n} répliques : {plan['title']}")


if __name__ == "__main__":
    main()
