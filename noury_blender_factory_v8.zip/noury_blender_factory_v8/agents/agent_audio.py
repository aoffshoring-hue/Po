#!/usr/bin/env python3
"""Audio: one voice per character (heroes and guests) + music that follows the emotion of each scene.

Voices
  1. Azure AI Speech (official neural voices) when AZURE_SPEECH_KEY + AZURE_SPEECH_REGION are set.
     Voice, pitch and rate of each character are defined in agents/cast_library.py.
     Heroes can be overridden with NOURY_VOICE_YAKINE / NOURY_VOICE_NOUR / NOURY_PITCH_NOUR.
  2. gTTS fallback (free, pitch-shifted per character).
  The emotion of the speaker changes speed and pitch (fear = faster, care = slower, joy = brighter).
Lines of a scene are placed one after the other (2.5 s after the scene starts, 0.6 s apart).

Outputs (export/)
  voices/line_XX.wav       one clean file per line (used by the lip-sync)
  dialogue_timing.json     start / duration / character of each line
  audio_master.mp3         all dialogue on the episode timeline
  bg_music.wav             music, one mood per scene, cross-faded
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
import urllib.request
from pathlib import Path
from xml.sax.saxutils import escape

import numpy as np
import soundfile as sf

sys.path.insert(0, str(Path(__file__).resolve().parent))
import cast_library as CL  # noqa: E402

SR = 24000
FIRST_LINE = 2.5
GAP = 0.6
EMOTION_PROSODY = {   # emotion -> (rate %, pitch % added to the character pitch)
    "wonder": (-6, 6), "curiosity": (0, 4), "fear": (8, 8), "care": (-12, -2), "determination": (4, 0),
    "tension": (6, 4), "hope": (-6, 4), "joy": (6, 10), "happy": (4, 6), "excited": (8, 10),
    "surprised": (4, 10), "sad": (-14, -4), "worried": (-4, 2), "hurt": (-8, -2), "calm": (-8, 0),
}


def voice_of(key):
    v = dict(CL.get(key)["voice"])
    if key == "Yakine":
        v["azure"] = os.environ.get("NOURY_VOICE_YAKINE") or v["azure"]
    if key == "Nour":
        v["azure"] = os.environ.get("NOURY_VOICE_NOUR") or v["azure"]
        v["pitch"] = int(os.environ.get("NOURY_PITCH_NOUR") or v["pitch"])
    return v


# ------------------------------------------------------------------ voices
def azure_tts(text, voice, rate, pitch, out_mp3):
    key, region = os.environ["AZURE_SPEECH_KEY"], os.environ["AZURE_SPEECH_REGION"]
    ssml = (f"<speak version='1.0' xml:lang='fr-FR'><voice name='{voice}'>"
            f"<prosody rate='{rate:+d}%' pitch='{pitch:+d}%'>{escape(text)}</prosody></voice></speak>")
    req = urllib.request.Request(
        f"https://{region}.tts.speech.microsoft.com/cognitiveservices/v1", data=ssml.encode("utf-8"),
        headers={"Ocp-Apim-Subscription-Key": key, "Content-Type": "application/ssml+xml",
                 "X-Microsoft-OutputFormat": "audio-24khz-96kbitrate-mono-mp3", "User-Agent": "noury-factory"})
    with urllib.request.urlopen(req, timeout=60) as r:
        Path(out_mp3).write_bytes(r.read())


def gtts_tts(text, shift, rate, out_wav, tmp):
    from gtts import gTTS
    raw = Path(tmp) / "g.mp3"
    gTTS(text=text, lang="fr", tld="fr", slow=False).save(str(raw))
    tempo = max(0.5, min(2.0, (1.0 / shift) * (1.0 + rate / 100.0)))
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(raw), "-af",
                    f"asetrate=24000*{shift},aresample=24000,atempo={tempo:.4f}", str(out_wav)], check=True)


def clean_voice(src, dst):
    """Broadcast-style chain: low cut, gentle compression, presence, soft edges, loudness."""
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(src), "-ac", "1", "-ar", str(SR), "-af",
                    "highpass=f=90,acompressor=threshold=-20dB:ratio=3:attack=5:release=80,"
                    "equalizer=f=3500:t=q:w=1.2:g=3,afade=t=in:d=0.02,areverse,afade=t=in:d=0.08,areverse,"
                    "loudnorm=I=-16:TP=-2", str(dst)], check=True)


# ------------------------------------------------------------------ music
NOTE = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}
MOODS = {
    #               key  mode     bpm  bright perc  pulse
    "wonder":        ("D", "major", 84, 0.9, False, False),
    "curiosity":     ("F", "major", 100, 0.8, True, False),
    "fear":          ("A", "minor", 72, 0.3, False, True),
    "care":          ("C", "major", 76, 0.5, False, False),
    "determination": ("D", "minor", 112, 0.6, True, True),
    "tension":       ("E", "minor", 92, 0.4, False, True),
    "hope":          ("G", "major", 80, 0.7, False, False),
    "joy":           ("C", "major", 124, 1.0, True, False),
    "worried":       ("A", "minor", 80, 0.4, False, False),
    "excited":       ("F", "major", 116, 0.9, True, False),
    "sad":           ("D", "minor", 68, 0.3, False, False),
}
PROG = {"major": [(0, "M"), (7, "M"), (9, "m"), (5, "M")],     # I V vi IV
        "minor": [(0, "m"), (8, "M"), (3, "M"), (10, "M")]}    # i VI III VII
PENTA = {"major": [0, 2, 4, 7, 9], "minor": [0, 3, 5, 7, 10]}


def hz(semi_from_c4):
    return 261.63 * 2 ** (semi_from_c4 / 12.0)


def tone(freq, n, bright):
    t = np.arange(n) / SR
    w = np.sin(2 * np.pi * freq * t)
    w += 0.35 * bright * np.sin(2 * np.pi * 2 * freq * t) + 0.12 * bright * np.sin(2 * np.pi * 3 * freq * t)
    return w


def scene_music(mood, seconds, seed):
    key, mode, bpm, bright, perc, pulse = MOODS.get(mood, MOODS["wonder"])
    rng = np.random.default_rng(seed)
    n = int(seconds * SR)
    out = np.zeros(n)
    root = NOTE[key]
    beat = 60.0 / bpm
    bar = 4 * beat
    for b in range(int(seconds / bar) + 1):
        a = int(b * bar * SR)
        if a >= n:
            break
        ln = min(n - a, int(bar * SR))
        deg, q = PROG[mode][b % 4]
        env = np.minimum(1, np.arange(ln) / (0.5 * SR)) * np.minimum(1, (ln - np.arange(ln)) / (0.4 * SR))
        for iv in (0, 4 if q == "M" else 3, 7):                       # soft pad chord
            out[a:a + ln] += 0.045 * env * tone(hz(root + deg + iv - 12), ln, bright * 0.6)
        bass_env = np.exp(-np.arange(ln) / SR * 1.5)
        out[a:a + ln] += 0.08 * bass_env * np.sin(2 * np.pi * hz(root + deg - 24) * np.arange(ln) / SR)
        if pulse:                                                      # tension: repeated low eighths
            for k in range(8):
                s = a + int(k * beat / 2 * SR)
                m = min(n - s, int(0.18 * SR))
                if m > 0:
                    out[s:s + m] += 0.04 * np.exp(-np.arange(m) / SR * 18) * \
                        np.sin(2 * np.pi * hz(root + deg - 12) * np.arange(m) / SR)
    scale = [root + p + o for o in (0, 12) for p in PENTA[mode]]
    step = beat / 2
    k = 3
    for i in range(int(seconds / step)):                               # plucked melody (bells)
        if rng.random() < (0.45 if bright < 0.5 else 0.3):
            continue
        k = int(np.clip(k + rng.integers(-2, 3), 0, len(scale) - 1))
        s = int(i * step * SR)
        m = min(n - s, int(0.9 * SR))
        if m <= 0:
            break
        tt = np.arange(m) / SR
        f = hz(scale[k] + 12)
        note = (np.sin(2 * np.pi * f * tt) + 0.4 * np.sin(2 * np.pi * 2.76 * f * tt) * np.exp(-tt * 12)) \
            * np.exp(-tt * (5.0 if bright > 0.5 else 3.0))
        out[s:s + m] += 0.05 * (0.6 + 0.4 * bright) * note
    if perc:                                                           # light kick + shaker
        for i in range(int(seconds / beat)):
            s = int(i * beat * SR)
            m = min(n - s, int(0.25 * SR))
            if m <= 0:
                break
            tt = np.arange(m) / SR
            if i % 2 == 0:
                out[s:s + m] += 0.12 * np.sin(2 * np.pi * (110 * np.exp(-tt * 18) + 45) * tt) * np.exp(-tt * 14)
            sh = s + int(beat / 2 * SR)
            m2 = min(n - sh, int(0.06 * SR))
            if m2 > 0:
                out[sh:sh + m2] += 0.02 * rng.standard_normal(m2) * np.exp(-np.arange(m2) / SR * 60)
    return out


def make_music(scenes, duration, path):
    n = int(duration * SR)
    total = np.zeros(n)
    fade = int(1.5 * SR)
    for i, s in enumerate(scenes):
        a = max(0, int(s["start"] * SR) - fade // 2)
        b = min(n, int(s["end"] * SR) + fade // 2)
        seg = scene_music(s.get("emotion", "wonder"), (b - a) / SR, seed=i * 13 + 5)[: b - a]
        env = np.ones(b - a)
        if i:
            env[:fade] = np.linspace(0, 1, fade)
        if i < len(scenes) - 1:
            env[-fade:] = np.linspace(1, 0, fade)
        total[a:b] += seg * env
    total[: 3 * SR] *= np.linspace(0, 1, 3 * SR)
    total[-3 * SR:] *= np.linspace(1, 0, 3 * SR)
    total /= max(1e-6, np.abs(total).max()) / 0.5
    sf.write(str(path), total.astype(np.float32), SR, subtype="PCM_16")


# ------------------------------------------------------------------ main
def speaker_emotion(scene, key):
    for g in scene.get("guests", []):
        if g["key"] == key:
            return g.get("emotion", scene.get("emotion", ""))
    return scene.get("emotions", {}).get(key, scene.get("emotion", ""))


def main():
    base = Path(__file__).resolve().parent.parent
    out = base / "export"
    vdir = out / "voices"
    vdir.mkdir(parents=True, exist_ok=True)
    script = json.loads((out / "script_config.json").read_text(encoding="utf-8"))
    duration = float(script.get("duration_seconds", 240))
    use_azure = bool(os.environ.get("AZURE_SPEECH_KEY") and os.environ.get("AZURE_SPEECH_REGION"))
    print(f"[Audio] Voix : {'Azure AI Speech' if use_azure else 'gTTS (secours)'}")
    master = np.zeros(int(duration * SR))
    timing = []
    n = 0
    with tempfile.TemporaryDirectory(prefix="noury_audio_") as tmp:
        for si, s in enumerate(script["scenes"]):
            cursor = float(s["start"]) + FIRST_LINE
            for ln in s.get("lines", []):
                text, who = ln["text"].strip(), ln["character"]
                v = voice_of(who)
                rate, dp = EMOTION_PROSODY.get(speaker_emotion(s, who), (0, 0))
                rate += v.get("rate", 0)
                raw = Path(tmp) / f"raw_{n:02d}"
                if use_azure:
                    raw = raw.with_suffix(".mp3")
                    azure_tts(text, v["azure"], rate, v.get("pitch", 0) + dp, raw)
                else:
                    raw = raw.with_suffix(".wav")
                    gtts_tts(text, v["gtts_shift"] * (1 + dp / 200.0), rate, raw, tmp)
                line = vdir / f"line_{n:02d}.wav"
                clean_voice(raw, line)
                data, _ = sf.read(str(line))
                a = int(cursor * SR)
                m = max(0, min(len(data), len(master) - a))
                master[a:a + m] += data[:m]
                dur = len(data) / SR
                if cursor + dur > s["end"] - 0.3:
                    print(f"[Audio] attention : la scène {s['id']} déborde ({cursor + dur - s['start']:.1f} s)")
                timing.append({"scene": si, "character": who, "text": text, "file": f"voices/{line.name}",
                               "start": round(cursor, 3), "duration": round(dur, 3)})
                cursor += dur + GAP
                n += 1
    peak = np.abs(master).max()
    if peak > 0.98:
        master *= 0.98 / peak
    wav = out / "dialogue_master.wav"
    sf.write(str(wav), master.astype(np.float32), SR, subtype="PCM_16")
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(wav), "-ac", "2", "-codec:a", "libmp3lame",
                    "-q:a", "2", str(out / "audio_master.mp3")], check=True)
    (out / "dialogue_timing.json").write_text(json.dumps(timing, ensure_ascii=False, indent=2), encoding="utf-8")
    make_music(script["scenes"], duration, out / "bg_music.wav")
    print(f"[Audio] {len(timing)} répliques ({len({t['character'] for t in timing})} voix) + musique par émotion")


if __name__ == "__main__":
    if not shutil.which("ffmpeg"):
        raise SystemExit("ffmpeg missing")
    main()
