#!/usr/bin/env python3
"""Lip-sync: one mouth shape per frame, for every speaking character.

With Rhubarb Lip Sync (phonetic recognizer, works for French) every line gets real mouth shapes:
  A = M/B/P closed   B = consonants, slightly open   C = open (è, a)   D = wide open (a)
  E = rounded (o)    F = puckered (ou, w)            G = F/V           H = L    X = rest
Without Rhubarb, shapes are estimated from the voice volume.

Output: export/lipsync.json
  values[]   mouth opening per frame       speakers[]  who is talking on each frame ("" = nobody)
  visemes    one letter per frame          lines       [[start, end, character], ...]
"""
import json
import os
import shutil
import subprocess
from pathlib import Path

import numpy as np
import soundfile as sf


def rhubarb_bin():
    return os.environ.get("RHUBARB_BIN") or shutil.which("rhubarb")


def run_rhubarb(exe, wav):
    # the phonetic recognizer is language independent (French OK)
    r = subprocess.run([exe, "-q", "-r", "phonetic", "-f", "json", "--extendedShapes", "GHX", str(wav)],
                       capture_output=True, text=True)
    if r.returncode:
        raise RuntimeError(r.stderr[-500:])
    return json.loads(r.stdout)["mouthCues"]


def amplitude_viseme(v):
    if v < 0.06:
        return "X"
    if v < 0.25:
        return "B"
    if v < 0.5:
        return "C"
    return "D"


def main():
    base = Path(__file__).resolve().parent.parent
    out = base / "export"
    script = json.loads((out / "script_config.json").read_text(encoding="utf-8"))
    timing = json.loads((out / "dialogue_timing.json").read_text(encoding="utf-8"))
    fps = int(script.get("fps", 24))
    total = fps * int(script.get("duration_seconds", 240))
    values = np.zeros(total, dtype=np.float32)
    speakers = [""] * total
    visemes = ["X"] * total
    exe = rhubarb_bin()
    used_rhubarb = 0
    lines = []

    for line in timing:
        data, sr = sf.read(str(out / line["file"]))
        if data.ndim > 1:
            data = data.mean(axis=1)
        hop = sr // fps
        n = len(data) // hop
        rms = np.sqrt((data[: n * hop].reshape(n, hop) ** 2).mean(axis=1)) if n else np.zeros(0)
        voiced = rms[rms > 0.01]
        ref = float(np.percentile(voiced, 90)) if voiced.size else 1.0
        env = np.clip((rms - 0.012) / max(ref, 1e-4), 0, 1)
        env = np.convolve(env, [0.25, 0.5, 0.25], mode="same")
        f0 = int(round(line["start"] * fps))
        who = line["character"]
        for k in range(n):
            f = f0 + k
            if 0 <= f < total:
                values[f] = env[k]
                visemes[f] = amplitude_viseme(env[k])
                speakers[f] = who
        lines.append([line["start"], round(line["start"] + line["duration"], 3), who])
        cues = None
        if exe:
            try:
                cues = run_rhubarb(exe, out / line["file"])
                used_rhubarb += 1
            except Exception as exc:      # keep the amplitude estimate for this line
                print(f"[LipSync] Rhubarb failed on {line['file']}: {exc}")
        if cues:
            for c in cues:
                a = f0 + int(round(c["start"] * fps))
                b = f0 + int(round(c["end"] * fps))
                for f in range(max(0, a), min(total, max(b, a + 1))):
                    visemes[f] = c["value"]

    (out / "lipsync.json").write_text(json.dumps({
        "fps": fps, "values": [round(float(v), 3) for v in values], "speakers": speakers,
        "visemes": "".join(visemes), "lines": lines,
        "source": "rhubarb" if used_rhubarb else "amplitude"}), encoding="utf-8")
    talking = sum(1 for v in visemes if v != "X")
    print(f"[LipSync] {talking} images parlées, {len(lines)} répliques - méthode : "
          f"{'Rhubarb (' + str(used_rhubarb) + ' répliques)' if used_rhubarb else 'volume de la voix'}")


if __name__ == "__main__":
    main()
