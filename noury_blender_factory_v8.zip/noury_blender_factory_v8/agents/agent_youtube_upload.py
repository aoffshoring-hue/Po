#!/usr/bin/env python3
"""Uploads FINAL_VIDEO.mp4 to YouTube (Data API v3, OAuth refresh token).

Required GitHub secrets: YT_CLIENT_ID, YT_CLIENT_SECRET, YT_REFRESH_TOKEN
Optional: YT_PRIVACY (public | unlisted | private, default public)
If the secrets are absent the step is skipped (useful for test runs).
"""
import json
import os
import sys
from pathlib import Path


def main():
    cid, csec, rtok = (os.environ.get(k, "") for k in ("YT_CLIENT_ID", "YT_CLIENT_SECRET", "YT_REFRESH_TOKEN"))
    if not (cid and csec and rtok):
        print("[YouTube] Secrets absents : upload ignoré.")
        return
    from google.oauth2.credentials import Credentials
    from googleapiclient.discovery import build
    from googleapiclient.http import MediaFileUpload

    base = Path(__file__).resolve().parent.parent
    out = base / "export"
    qc = json.loads((out / "qc_report.json").read_text(encoding="utf-8"))
    if not qc.get("passed"):
        sys.exit("[YouTube] QC non validé : publication refusée.")
    meta = json.loads((out / "youtube_metadata.json").read_text(encoding="utf-8"))
    creds = Credentials(None, refresh_token=rtok, client_id=cid, client_secret=csec,
                        token_uri="https://oauth2.googleapis.com/token",
                        scopes=["https://www.googleapis.com/auth/youtube.upload",
                                "https://www.googleapis.com/auth/youtube"])
    yt = build("youtube", "v3", credentials=creds, cache_discovery=False)
    body = {
        "snippet": {"title": meta["title"], "description": meta["description"], "tags": meta["tags"],
                    "categoryId": meta["categoryId"], "defaultLanguage": meta["defaultLanguage"],
                    "defaultAudioLanguage": "fr"},
        "status": {"privacyStatus": os.environ.get("YT_PRIVACY", "public"),
                   "selfDeclaredMadeForKids": True, "embeddable": True},
    }
    media = MediaFileUpload(str(out / "FINAL_VIDEO.mp4"), mimetype="video/mp4", chunksize=8 * 1024 * 1024,
                            resumable=True)
    req = yt.videos().insert(part="snippet,status", body=body, media_body=media)
    resp = None
    while resp is None:
        status, resp = req.next_chunk()
        if status:
            print(f"[YouTube] Upload {int(status.progress() * 100)}%")
    vid = resp["id"]
    print(f"[YouTube] Publiée : https://youtu.be/{vid}")
    thumb = out / "thumbnail.jpg"
    if thumb.exists():
        try:
            yt.thumbnails().set(videoId=vid, media_body=MediaFileUpload(str(thumb), mimetype="image/jpeg")).execute()
            print("[YouTube] Miniature appliquée")
        except Exception as exc:  # custom thumbnails need a verified channel
            print(f"[YouTube] Miniature non appliquée : {exc}")
    (out / "youtube_result.json").write_text(json.dumps({"videoId": vid}), encoding="utf-8")


if __name__ == "__main__":
    main()
