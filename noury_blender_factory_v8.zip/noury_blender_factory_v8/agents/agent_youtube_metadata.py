#!/usr/bin/env python3
"""YouTube metadata generated from the episode (+ automatic credits of the free libraries used)."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import licences as L  # noqa: E402
from agent_sets import LOCATIONS  # noqa: E402


def and_list(items):
    items = list(items)
    return items[0] if len(items) == 1 else ", ".join(items[:-1]) + " et " + items[-1]


def credits_block(base):
    """CC-BY assets actually used in THIS episode MUST be credited (author + source + licence);
    the other free libraries are thanked (not required, but fair)."""
    p = base / "assets" / "library" / "library.json"
    lib = json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
    out = base / "export"
    used_models = json.loads((out / "used_assets.json").read_text(encoding="utf-8")).get("models", []) \
        if (out / "used_assets.json").exists() else None
    used_sounds = set(json.loads((out / "sfx_used.json").read_text(encoding="utf-8"))) \
        if (out / "sfx_used.json").exists() else None
    all_models = [m for lst in lib.get("models", {}).values() for m in lst]
    all_sounds = [x for lst in lib.get("sounds", {}).values() for x in lst]
    models = used_models if used_models is not None else all_models
    sounds = [x for x in all_sounds if used_sounds is None or x.get("path") in used_sounds]
    items = list(lib.get("hdri", {}).values()) + list(lib.get("textures", {}).values()) + models + sounds
    sources = sorted({i.get("source") for i in items if i.get("source") and i.get("source") != "manuel"})
    ccby, seen = [], set()
    for i in items:
        code = i.get("licence") if i.get("licence") in ("CC-BY", "CC-BY-SA") else L.normalise(i.get("licence"))
        if L.needs_credit(code) and (i.get("source"), i.get("id")) not in seen:
            seen.add((i.get("source"), i.get("id")))
            ccby.append(i)
    lines = []
    if sources:
        lines += ["", "🎨 Ressources libres utilisées : " + ", ".join(sources) + "."]
    if ccby:
        lines.append("Sous licence Creative Commons Attribution (CC BY) :")
    for i in ccby:
        lic = "CC BY-SA" if i.get("licence") == "CC-BY-SA" else "CC BY"
        via = " via Sketchfab" if i.get("source") == "Objaverse" else ""
        lines.append(f"• « {i.get('title') or i.get('id')} » par {i.get('creator') or '?'} "
                     f"({i.get('source')}{via}, {lic}) {i.get('url', '')}".rstrip())
    return lines


def main():
    base = Path(__file__).resolve().parent.parent
    out = base / "export"
    s = json.loads((out / "script_config.json").read_text(encoding="utf-8"))
    title = f"{s['title']} ✨ Dessin animé pour enfants | {s['episode_label']}"[:100]
    guests = s.get("cast_names", [])
    places = [LOCATIONS[k]["label"] for k in s.get("locations", []) if k in LOCATIONS]
    desc = "\n".join([
        f"{s['title']} - {s['episode_label']}",
        "",
        "Aujourd'hui, Yakine et Nour vivent une nouvelle aventure"
        + (f" avec {and_list(guests)}" if guests else "") + " !",
        f"🌍 Les lieux : {', '.join(places)}." if places else "",
        "",
        f"💛 La leçon du jour : {s['moral']}",
        "",
        "Un dessin animé doux et coloré pour les petits de 3 à 7 ans.",
        "Nouvel épisode chaque jour avec Yakine et Nour !",
        *credits_block(base),
        "",
        "#dessinanimé #histoirepourenfants #YakineEtNour",
    ])
    if len(desc) > 4950:          # YouTube limit is 5000 characters: shorten the story part, never the credits
        desc = desc.replace("Un dessin animé doux et coloré pour les petits de 3 à 7 ans.\n", "")[:4950]
    meta = {"title": title, "description": desc,
            "tags": ["dessin animé", "dessin animé enfant", "histoire pour enfants", "Yakine et Nour",
                     "conte pour enfants", s["theme"], "animation 3D", "français"] + guests,
            "categoryId": "1", "defaultLanguage": "fr", "madeForKids": True}
    (out / "youtube_metadata.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[Metadata] {title}")


if __name__ == "__main__":
    main()
