#!/usr/bin/env python3
"""Actors: design sheets of the heroes + every guest of the episode."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import cast_library as CL  # noqa: E402


def entry(key):
    c = CL.get(key)
    d = dict(c["design"])
    item = {"key": key, "name": c["name"], "kind": c["kind"], **d}
    if c["kind"] in ("hero", "human"):
        adult = bool(d.get("adult"))
        item["leg_len"] = 0.62 if adult else 0.48
        item["head_scale"] = 0.82 if adult else 1.0
        item.setdefault("height", 1.0)
        # head centre height (character scale 1): legs + spine-to-head pivot + head radius
        item["head_h"] = round(item["leg_len"] + (0.6 if adult else 0.54) + 0.33 * item["head_scale"], 3)
    else:
        item["species"] = c["species"]
        item["height"] = d.get("size", 1.0)
        item["head_h"] = {"cat": 0.44, "dog": 0.48, "rabbit": 0.40, "bird": 0.08, "owl": 0.42}[c["species"]]
    return item


def main():
    base = Path(__file__).resolve().parent.parent
    out = base / "export"
    out.mkdir(parents=True, exist_ok=True)
    script = json.loads((out / "script_config.json").read_text(encoding="utf-8"))
    keys = ["Yakine", "Nour"] + list(script.get("cast", []))
    chars = [entry(k) for k in keys]
    payload = {"generator": "Noury cast", "version": 5, "characters": chars}
    (out / "actors_config.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[Actors] {len(chars)} personnages : {', '.join(c['name'] for c in chars)}")


if __name__ == "__main__":
    main()
