#!/usr/bin/env python3
"""Renders a chunk of frames and encodes it:  python agents/agent_blender_render.py [chunk_index chunk_total]"""
import json
import math
import subprocess
import sys
from pathlib import Path

from agent_blender_build import blender_bin


def main():
    idx, total = (int(sys.argv[1]), int(sys.argv[2])) if len(sys.argv) >= 3 else (0, 1)
    base = Path(__file__).resolve().parent.parent
    out = base / "export"
    cfg = json.loads((out / "animation_config.json").read_text(encoding="utf-8"))
    n = int(cfg["total_frames"])
    size = math.ceil(n / total)
    first, last = idx * size + 1, min(n, (idx + 1) * size)
    cmd = [blender_bin(), "-b", str(out / "episode.blend"), "--python-exit-code", "1",
           "--python", str(base / "agents" / "blender" / "render_chunk.py"), "--", str(idx), str(total)]
    print("[Render]", " ".join(cmd), flush=True)
    r = subprocess.run(cmd, cwd=str(base))
    if r.returncode:
        sys.exit(f"[Render] Blender exited with code {r.returncode}")
    frame = lambda f: out / "frames" / f"frame_{f:04d}.png"
    missing = [f for f in range(first, last + 1) if not frame(f).exists() or frame(f).stat().st_size <= 1000]
    if missing:
        sys.exit(f"[Render] {len(missing)} missing/empty frames, e.g. {missing[:5]}")
    seg_dir = out / "segments"
    seg_dir.mkdir(exist_ok=True)
    seg = seg_dir / f"seg_{idx:03d}.mp4"
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-framerate", str(cfg["fps"]), "-start_number", str(first),
                    "-i", str(out / "frames" / "frame_%04d.png"), "-frames:v", str(last - first + 1),
                    "-c:v", "libx264", "-preset", "medium", "-crf", "11", "-tune", "animation",
                    "-pix_fmt", "yuv420p", str(seg)], check=True)
    print(f"[Render] chunk {idx + 1}/{total} OK : frames {first}-{last} -> {seg.name}")


if __name__ == "__main__":
    main()
