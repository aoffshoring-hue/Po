#!/usr/bin/env python3
"""Segments (or frames) + voices + music + sound effects -> FINAL_VIDEO.mp4, with title and end cards."""
import json
import os
import shutil
import subprocess
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

FONTS = ["/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
         "/usr/share/fonts/dejavu-sans-fonts/DejaVuSans-Bold.ttf",
         "/usr/share/fonts/TTF/DejaVuSans-Bold.ttf"]


def font(size):
    for f in FONTS:
        if Path(f).exists():
            return ImageFont.truetype(f, size)
    return ImageFont.load_default()


def card(path, w, h, lines):
    """Transparent PNG with big outlined title lines: [(text, size, y_ratio)]."""
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    for text, size, yr in lines:
        f = font(int(size * h / 1080))
        while d.textlength(text, font=f) > w * 0.9 and f.size > 20:
            f = font(f.size - 4)
        x = (w - d.textlength(text, font=f)) / 2
        y = int(h * yr)
        sw = max(3, f.size // 9)
        d.text((x + 5, y + 6), text, font=f, fill=(0, 0, 0, 110), stroke_width=sw, stroke_fill=(0, 0, 0, 110))
        d.text((x, y), text, font=f, fill=(255, 240, 176, 255), stroke_width=sw, stroke_fill=(90, 30, 90, 255))
    img.save(path)


def and_list(items):
    items = list(items)
    return items[0] if len(items) == 1 else ", ".join(items[:-1]) + " et " + items[-1]


def main():
    base = Path(__file__).resolve().parent.parent
    out = base / "export"
    cfg = json.loads((out / "animation_config.json").read_text(encoding="utf-8"))
    script = json.loads((out / "script_config.json").read_text(encoding="utf-8"))
    fps, dur, expected = int(cfg["fps"]), int(cfg["duration_seconds"]), int(cfg["total_frames"])
    frames = out / "frames"
    voice, music, video = out / "audio_master.mp3", out / "bg_music.wav", out / "FINAL_VIDEO.mp4"
    if not shutil.which("ffmpeg"):
        raise FileNotFoundError("ffmpeg missing")
    segs = sorted((out / "segments").glob("seg_*.mp4")) if (out / "segments").exists() else []
    if segs:
        lst = out / "segments.txt"
        lst.write_text("".join(f"file '{s.resolve()}'\n" for s in segs), encoding="utf-8")
        src = ["-f", "concat", "-safe", "0", "-r", str(fps), "-i", str(lst)]
        probe = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
                                "stream=width,height", "-of", "csv=p=0", str(segs[0])],
                               capture_output=True, text=True, check=True).stdout.strip().split(",")
        w, h = int(probe[0]), int(probe[1])
    else:
        n = len(list(frames.glob("frame_*.png")))
        if n != expected:
            raise RuntimeError(f"Expected {expected} frames, found {n}")
        src = ["-framerate", str(fps), "-start_number", "1", "-i", str(frames / "frame_%04d.png")]
        w, h = Image.open(frames / "frame_0001.png").size
    guests = script.get("cast_names", [])
    sub = script.get("episode_label", "") + (f"  -  avec {and_list(guests)}" if guests else "")
    card(out / "card_title.png", w, h, [(script.get("title", "Yakine et Nour"), 84, 0.10), (sub, 46, 0.22)])
    card(out / "card_end.png", w, h, [("FIN", 120, 0.28), ("À bientôt pour une nouvelle aventure !", 54, 0.45)])
    fc = (f"[0:v]fade=t=in:st=0:d=1.2,fade=t=out:st={dur - 1.5}:d=1.5[base];"
          f"[3:v]format=rgba,fade=t=in:st=0.6:d=0.8:alpha=1,fade=t=out:st=4.5:d=1:alpha=1[tt];"
          f"[4:v]format=rgba,fade=t=in:st={dur - 5}:d=0.8:alpha=1[te];"
          f"[base][tt]overlay=0:0:enable='between(t,0.5,5.6)'[b1];"
          f"[b1][te]overlay=0:0:enable='gte(t,{dur - 5})'[vout];"
          f"[1:a]apad,atrim=0:{dur},volume=1.0,asplit=2[v][vs];"
          f"[2:a]atrim=0:{dur},volume=0.2[m];"
          f"[5:a]atrim=0:{dur},volume=0.32[fx];"
          f"[m][fx]amix=inputs=2:duration=longest:normalize=0[bed];"
          f"[bed][vs]sidechaincompress=threshold=0.05:ratio=4:release=400[duck];"
          f"[v][duck]amix=inputs=2:duration=longest:normalize=0,"
          f"afade=t=in:d=1,afade=t=out:st={dur - 2}:d=2,loudnorm=I=-16:TP=-1.5[a]")
    cmd = ["ffmpeg", "-y", "-v", "error", *src, "-i", str(voice), "-i", str(music),
           "-loop", "1", "-framerate", str(fps), "-t", str(dur), "-i", str(out / "card_title.png"),
           "-loop", "1", "-framerate", str(fps), "-t", str(dur), "-i", str(out / "card_end.png"),
           "-i", str(out / "sfx.wav"),
           "-filter_complex", fc, "-map", "[vout]", "-map", "[a]", "-frames:v", str(expected),
           "-c:v", "libx264", "-preset", os.environ.get("NOURY_X264_PRESET", "slow"), "-crf", "17",
           "-tune", "animation", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k",
           "-movflags", "+faststart", str(video)]
    p = subprocess.run(cmd, capture_output=True, text=True, cwd=str(base))
    if p.returncode:
        raise RuntimeError("FFmpeg failed:\n" + p.stderr[-4000:])
    print(f"[Montage] {video.name} ({video.stat().st_size // 1024} Ko)")


if __name__ == "__main__":
    main()
