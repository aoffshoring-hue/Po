#!/usr/bin/env python3
"""Asset library manager: free assets from several online libraries, downloaded automatically.

Sources (each one is optional, the factory never stops because of a missing asset):
  Poly Haven  polyhaven.com   CC0, no key     sky HDRIs per mood (day, sunset, storm, night) + ground textures
  ambientCG   ambientcg.com   CC0, no key     more textures: snow, plaster walls, wood, soil, roof tiles, pebbles
  Poly Pizza  poly.pizza      CC0 / CC-BY     stylised low-poly 3D models (Quaternius, Kenney...): trees, pines,
                              key: POLYPIZZA_API_KEY      palms, bushes, mushrooms, rocks
  Sketchfab   sketchfab.com   CC0 / CC-BY     huge library of downloadable models (cartoon / low poly searches)
                              key: SKETCHFAB_API_TOKEN
  BlendKit    blendkit.com    CC0 / Royalty Free   Blender-native models, free assets only
                              key: BLENDKIT_API_KEY (+ NOURY_ARTIFACT_KEY for royalty-free files, kept encrypted)
  Freesound   freesound.org   CC0 / CC-BY     real sound effects: birds, waves, wind, crickets, animals, footsteps
                              key: FREESOUND_API_KEY
  Manual      assets/manual/  your licence    files downloaded by hand from sites without API
                                              (3dtextures.me, freepbr.com, Kenney.nl, Quaternius.com, CGTrader free...)

  Objaverse   huggingface.co  CC0 / CC-BY     800 000 Creative Commons objects (allenai/objaverse), no key
  Packs       direct links    per pack        complete packs (Kenney CC0, Quaternius QAL...) listed in config

Every source can be switched on/off and every licence rule is set in config/asset_sources.json.
All licences go through agents/licences.py: CC0 always, CC-BY / CC-BY-SA if allowed (credited automatically),
"restricted" licences (no redistribution) only with NOURY_ARTIFACT_KEY (files kept encrypted), NC / ND never.
The library lives in assets/library/ (cached between GitHub runs, it grows a little at each run).
Output: assets/library/library.json + assets/library/CREDITS.md
"""
import io
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.parse
import urllib.request
import fnmatch
import gzip
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import licences as L  # noqa: E402

BASE = Path(__file__).resolve().parent.parent
LIB = BASE / "assets" / "library"
MANUAL = BASE / "assets" / "manual"
UA = {"User-Agent": "NouryCartoonFactory/2.0 (automated kids series; CC0 assets)"}
CONFIG = L.load_config()
POLICY = L.policy(CONFIG)
ALLOW_CCBY = POLICY["attribution"]
MAX_NEW_DOWNLOADS = int(os.environ.get("NOURY_MAX_DOWNLOADS", "70"))   # per run, keeps each run fast

HDRI_MOODS = {        # mood -> (Poly Haven categories to try, fallback ids)
    "day": (["pure skies", "skies", "outdoor"], ["kloofendal_48d_partly_cloudy_puresky"]),
    "sunset": (["sunrise-sunset"], []),
    "storm": (["overcast"], []),
    "night": (["night"], []),
}
PH_TEXTURES = {"grass": ["sparse_grass", "forrest_ground_01", "aerial_grass_rock"],
               "sand": ["coast_sand_01", "coast_sand_02", "sand_01"],
               "rock": ["rock_face", "aerial_rocks_02", "rock_wall_08"]}
AMBIENT_TEXTURES = {"snow": "snow", "plaster": "plaster", "wood": "planks", "soil": "ground soil",
                    "tiles": "roofing tiles", "pebbles": "gravel"}
MODEL_FAMILIES = {    # family -> (searches, models to keep PER SOURCE, words to avoid in titles)
    "tree": (["tree", "oak tree", "round tree"], 4, ["dead", "christmas", "house", "stump", "log"]),
    "pine": (["pine tree", "fir tree"], 3, ["dead", "christmas", "log"]),
    "palm": (["palm tree"], 2, ["dead"]),
    "bush": (["bush", "shrub"], 3, ["dead"]),
    "mushroom": (["mushroom"], 2, ["house"]),
    "rock": (["rock", "boulder"], 3, ["house", "wall"]),
    "house": (["house", "cottage"], 3, ["interior", "room", "ruin", "haunted", "dollhouse"]),
    "village_prop": (["well", "market stall", "wooden cart", "bench"], 4, ["interior", "gym", "office"]),
    "flower": (["flowers", "flower pot", "tulip"], 3, ["dead", "vase interior"]),
    "boat": (["rowboat", "small boat"], 2, ["wreck", "military", "war", "warship"]),
    "snowman": (["snowman"], 1, []),
}
STYLE_WORDS = ("low poly", "stylized", "cartoon")       # added to searches on big libraries (Sketchfab, BlendKit)
BAD_WORDS = ("gun", "weapon", "blood", "skull", "zombie", "horror", "sexy", "nsfw", "military", "knife")
SOUNDS = {            # key -> (Freesound search, min/max duration in seconds, how many)
    "amb_birds": ("birds forest ambience", 20, 120, 1),
    "amb_waves": ("ocean waves beach", 20, 120, 1),
    "amb_wind": ("wind ambience", 20, 120, 1),
    "amb_crickets": ("crickets night", 15, 120, 1),
    "meow": ("cat meow", 0.4, 3, 2),
    "woof": ("dog bark", 0.3, 3, 2),
    "chirp": ("small bird chirp", 0.3, 3, 2),
    "hoot": ("owl hoot", 0.5, 4, 1),
    "step_grass": ("footstep grass", 0.1, 1.5, 3),
    "step_snow": ("footstep snow", 0.1, 1.5, 3),
    "step_sand": ("footstep sand", 0.1, 1.5, 3),
    "chime": ("magic sparkle chime", 0.5, 4, 3),
    "thud": ("body fall thud", 0.2, 2, 1),
    "whoosh": ("wind gust whoosh", 1, 5, 1),
}
budget = {"left": MAX_NEW_DOWNLOADS}
SECRET = os.environ.get("NOURY_ARTIFACT_KEY", "").strip()   # protects restricted files (never redistributed)
REJECTED = []                                                 # (source, title, licence) -> licence report


def source_cfg(name):
    return CONFIG.get("sources", {}).get(name, {})


def enabled(name):
    return source_cfg(name).get("enabled", True)


def quota(name, default):
    q = source_cfg(name).get("max_per_family")
    return int(q) if q else default


def accept(source, title, licence_text):
    """Licence gate used by every source. Returns the normalised code, or None (and records the refusal)."""
    code = L.check(licence_text, POLICY)
    if code is None:
        REJECTED.append((source, str(title)[:60], str(licence_text)[:40], L.normalise(licence_text) or "inconnue"))
    elif L.needs_encryption(code) and not (SECRET and shutil.which("openssl")):
        REJECTED.append((source, str(title)[:60], str(licence_text)[:40], "restreinte sans NOURY_ARTIFACT_KEY"))
        return None
    return code


def family_items(models, family, source):
    """Keeps the entries whose file still exists; returns (all entries, entries of `source`)."""
    have = [m for m in models.get(family, []) if (BASE / m["path"]).exists()]
    models[family] = have
    return have, [m for m in have if m.get("source") == source]


def child_safe(title):
    t = (title or "").lower()
    return not any(w in t for w in BAD_WORDS)


def encrypt_file(src, dst):
    """AES-256 encryption with openssl (key = NOURY_ARTIFACT_KEY). Used for royalty-free files:
    they may be used in the videos but must never be redistributed (public caches / artifacts)."""
    subprocess.run(["openssl", "enc", "-aes-256-cbc", "-pbkdf2", "-salt", "-in", str(src), "-out", str(dst),
                    "-pass", "env:NOURY_ARTIFACT_KEY"], check=True, env={**os.environ, "NOURY_ARTIFACT_KEY": SECRET})


# ------------------------------------------------------------------ http helpers
def http_json(url, headers=None, timeout=30):
    req = urllib.request.Request(url, headers={**UA, **(headers or {})})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def http_bytes(url, headers=None, timeout=180):
    req = urllib.request.Request(url, headers={**UA, **(headers or {})})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def save(url, dest, headers=None, min_size=2000, magic=None):
    """Download once (cached). Returns the relative path or None."""
    if dest.exists() and dest.stat().st_size >= min_size:
        return rel(dest)
    if budget["left"] <= 0:
        return None
    data = http_bytes(url, headers)
    if len(data) < min_size or (magic and not data.startswith(magic)):
        raise ValueError(f"unexpected file ({len(data)} bytes)")
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(dest.suffix + ".part")
    tmp.write_bytes(data)
    tmp.replace(dest)
    budget["left"] -= 1
    time.sleep(0.3)                  # be gentle with free services
    return rel(dest)


def rel(p):
    return str(Path(p).resolve().relative_to(BASE))


def ok_licence(text):
    """Kept for compatibility: normalised code if allowed by the policy."""
    return L.check(text, POLICY)


# ------------------------------------------------------------------ Poly Haven
def polyhaven(lib):
    if not enabled("polyhaven"):
        return
    hd = lib.setdefault("hdri", {})
    for mood, (cats, fallback) in HDRI_MOODS.items():
        if hd.get(mood) and (BASE / hd[mood]["path"]).exists():
            continue
        candidates = list(fallback)
        for cat in cats:
            try:
                found = http_json("https://api.polyhaven.com/assets?type=hdris&categories=" + urllib.parse.quote(cat))
                ranked = sorted(found.items(), key=lambda kv: -int(kv[1].get("download_count", 0)))
                candidates += [k for k, _ in ranked[:5]]
            except Exception as exc:
                print(f"[Assets] Poly Haven categorie '{cat}' : {exc}")
        for hid in dict.fromkeys(candidates):
            try:
                url = http_json(f"https://api.polyhaven.com/files/{hid}")["hdri"]["2k"]["hdr"]["url"]
                path = save(url, LIB / "hdri" / f"{mood}_{hid}.hdr", min_size=100_000)
                if path:
                    hd[mood] = {"path": path, "id": hid, "source": "Poly Haven", "licence": "CC0", "licence_name": "CC0",
                                "url": f"https://polyhaven.com/a/{hid}"}
                    break
            except Exception as exc:
                print(f"[Assets] Poly Haven HDRI {hid} : {exc}")

    tx = lib.setdefault("textures", {})
    names = {"diff": ("diffuse", "diff"), "rough": ("rough",), "nor": ("nor_gl",)}
    for kind, ids in PH_TEXTURES.items():
        if kind in tx and all((BASE / tx[kind][m]).exists() for m in ("diff", "rough", "nor")):
            continue
        for tid in ids:
            try:
                files = http_json(f"https://api.polyhaven.com/files/{tid}")
                maps = {}
                for m, keys in names.items():
                    url = next((v.get("2k", v.get("1k", {})).get("jpg", {}).get("url") for k, v in files.items()
                                if k.lower() in keys and isinstance(v, dict)), None)
                    if not url:
                        raise KeyError(f"map {m} missing")
                    maps[m] = save(url, LIB / "textures" / f"{kind}_{tid}_{m}.jpg", min_size=10_000)
                if all(maps.values()):
                    tx[kind] = {**maps, "id": tid, "source": "Poly Haven", "licence": "CC0", "licence_name": "CC0",
                                "url": f"https://polyhaven.com/a/{tid}"}
                    break
            except Exception as exc:
                print(f"[Assets] Poly Haven texture {tid} : {exc}")


# ------------------------------------------------------------------ ambientCG
def _find_zip(obj, attribute="1K-JPG"):
    if isinstance(obj, dict):
        if obj.get("attribute") == attribute and (obj.get("downloadLink") or obj.get("rawLink")):
            return obj.get("downloadLink") or obj.get("rawLink")
        obj = list(obj.values())
    if isinstance(obj, list):
        for v in obj:
            r = _find_zip(v, attribute)
            if r:
                return r
    return None


def ambientcg(lib):
    if not enabled("ambientcg"):
        return
    tx = lib.setdefault("textures", {})
    for kind, query in AMBIENT_TEXTURES.items():
        if kind in tx and all((BASE / tx[kind][m]).exists() for m in ("diff", "rough", "nor")):
            continue
        try:
            url = ("https://ambientcg.com/api/v2/full_json?type=Material&sort=Popular&limit=5&include=downloadData&q="
                   + urllib.parse.quote(query))
            assets = http_json(url).get("foundAssets", [])
            for a in assets:
                link = _find_zip(a)
                if not link or budget["left"] <= 0:
                    continue
                aid = a.get("assetId", "asset")
                folder = LIB / "textures"
                folder.mkdir(parents=True, exist_ok=True)
                wanted = {"diff": "_Color.", "rough": "_Roughness.", "nor": "_NormalGL."}
                maps = {m: folder / f"{kind}_{aid}_{m}.jpg" for m in wanted}
                if not all(p.exists() for p in maps.values()):
                    data = http_bytes(link)
                    budget["left"] -= 1
                    with zipfile.ZipFile(io.BytesIO(data)) as z:
                        for m, tag in wanted.items():
                            member = next((n for n in z.namelist() if tag in n and n.lower().endswith(".jpg")), None)
                            if not member:
                                raise KeyError(f"{tag} missing in zip")
                            maps[m].write_bytes(z.read(member))
                tx[kind] = {**{m: rel(p) for m, p in maps.items()}, "id": aid, "source": "ambientCG",
                            "licence": "CC0", "licence_name": "CC0", "url": f"https://ambientcg.com/view?id={aid}"}
                break
        except Exception as exc:
            print(f"[Assets] ambientCG {kind} : {exc}")


# ------------------------------------------------------------------ Poly Pizza
def polypizza(lib):
    key = os.environ.get("POLYPIZZA_API_KEY", "").strip()
    if not enabled("polypizza"):
        return
    if not key:
        print("[Assets] Poly Pizza : pas de clé POLYPIZZA_API_KEY, modèles 3D ignorés")
        return
    headers = {"x-auth-token": key}
    models = lib.setdefault("models", {})
    for family, (queries, keep, avoid) in MODEL_FAMILIES.items():
        keep = quota("polypizza", keep)
        _, mine = family_items(models, family, "Poly Pizza")
        if len(mine) >= keep:
            continue
        seen = {m["id"] for m in models[family]}
        for q in queries:
            results = []
            for base_url in ("https://api.poly.pizza/v1.1", "https://api.poly.pizza/v1"):
                try:
                    d = http_json(f"{base_url}/search/{urllib.parse.quote(q)}?limit=24", headers)
                    results = d.get("results") or d.get("Results") or d.get("Models") or []
                    break
                except Exception as exc:
                    print(f"[Assets] Poly Pizza '{q}' ({base_url}) : {exc}")
            for m in results:
                if len([x for x in models[family] if x.get("source") == "Poly Pizza"]) >= keep:
                    break
                mid = str(m.get("ID") or m.get("Id") or m.get("id") or "")
                title = str(m.get("Title") or m.get("title") or "")
                lic_text = m.get("Licence") or m.get("License") or m.get("licence")
                lic = accept("Poly Pizza", title, lic_text) if mid and mid not in seen else None
                tris = int(m.get("Tri Count") or m.get("TriCount") or m.get("triCount") or 0)
                url = m.get("Download") or m.get("download")
                if (not mid or mid in seen or not lic or not url or m.get("Animated")
                        or tris > 8000 or any(w in title.lower() for w in avoid) or not child_safe(title)):
                    continue
                try:
                    path = save(url, LIB / "models" / family / f"{mid}.glb", min_size=1000, magic=b"glTF")
                except Exception as exc:
                    print(f"[Assets] Poly Pizza {mid} : {exc}")
                    continue
                if not path:
                    break
                creator = (m.get("Creator") or {}).get("Username", "") if isinstance(m.get("Creator"), dict) else ""
                models[family].append({"path": path, "id": mid, "title": title, "creator": creator,
                                       "source": "Poly Pizza", "licence": lic, "licence_name": str(lic_text),
                                       "format": "glb",
                                       "attribution": m.get("Attribution", ""),
                                       "url": f"https://poly.pizza/m/{mid}"})
                seen.add(mid)
            if len([x for x in models[family] if x.get("source") == "Poly Pizza"]) >= keep:
                break


# ------------------------------------------------------------------ Sketchfab


def sketchfab(lib):
    """Sketchfab (sketchfab.com): the biggest library of downloadable Creative Commons models, many cartoon ones.
    Key: SKETCHFAB_API_TOKEN (free account -> Settings -> Password & API). Models come as glTF archives."""
    token = os.environ.get("SKETCHFAB_API_TOKEN", "").strip()
    if not enabled("sketchfab"):
        return
    if not token:
        print("[Assets] Sketchfab : pas de clé SKETCHFAB_API_TOKEN, ignoré")
        return
    headers = {"Authorization": f"Token {token}"}
    lic_param = ",".join(["cc0"] + (["by"] if POLICY["attribution"] else [])
                         + (["by-sa"] if POLICY["share_alike"] else []))
    models = lib.setdefault("models", {})
    for family, (queries, keep, avoid) in MODEL_FAMILIES.items():
        keep = quota("sketchfab", keep)
        _, mine = family_items(models, family, "Sketchfab")
        if len(mine) >= keep:
            continue
        seen = {m["id"] for m in models[family]}
        for q in [f"{w} {q}" for q in queries[:2] for w in STYLE_WORDS[:2]]:
            if len([x for x in models[family] if x.get("source") == "Sketchfab"]) >= keep or budget["left"] <= 0:
                break
            params = {"type": "models", "q": q, "downloadable": "true", "license": lic_param,
                      "max_face_count": 25000, "sort_by": "-likeCount", "count": 12}
            try:
                results = http_json("https://api.sketchfab.com/v3/search?" + urllib.parse.urlencode(params),
                                    headers).get("results", [])
            except Exception as exc:
                print(f"[Assets] Sketchfab '{q}' : {exc}")
                continue
            for m in results:
                if len([x for x in models[family] if x.get("source") == "Sketchfab"]) >= keep or budget["left"] <= 0:
                    break
                uid, title = str(m.get("uid", "")), str(m.get("name", ""))
                lic_slug = ((m.get("license") or {}).get("slug") or (m.get("license") or {}).get("label") or "")
                lic = accept("Sketchfab", title, lic_slug) if uid and uid not in seen else None
                if (not uid or uid in seen or not lic or L.needs_encryption(lic)
                        or m.get("isAgeRestricted") or int(m.get("animationCount") or 0) > 0
                        or int(m.get("faceCount") or 0) > 25000
                        or any(w in title.lower() for w in avoid) or not child_safe(title)):
                    continue
                folder = LIB / "models" / family / f"skfb_{uid}"
                gltf = folder / "scene.gltf"
                try:
                    if not gltf.exists():
                        info = http_json(f"https://api.sketchfab.com/v3/models/{uid}/download", headers)
                        g = info.get("gltf") or {}
                        if not g.get("url") or int(g.get("size") or 0) > 40_000_000:
                            continue
                        data = http_bytes(g["url"])          # temporary signed link, never cached
                        budget["left"] -= 1
                        with zipfile.ZipFile(io.BytesIO(data)) as z:
                            names = z.namelist()
                            root = next((n for n in names if n.endswith("scene.gltf")), None)
                            if not root:
                                raise KeyError("scene.gltf missing")
                            prefix = root[: -len("scene.gltf")]
                            folder.mkdir(parents=True, exist_ok=True)
                            for n in names:
                                if n.startswith(prefix) and not n.endswith("/") and ".." not in n:
                                    dest = folder / n[len(prefix):]
                                    dest.parent.mkdir(parents=True, exist_ok=True)
                                    dest.write_bytes(z.read(n))
                        time.sleep(0.5)
                except Exception as exc:
                    print(f"[Assets] Sketchfab {uid} : {exc}")
                    shutil.rmtree(folder, ignore_errors=True)
                    continue
                user = m.get("user") or {}
                models[family].append({"path": rel(gltf), "id": uid, "title": title, "format": "gltf",
                                       "creator": user.get("displayName") or user.get("username", ""),
                                       "source": "Sketchfab", "licence": lic, "licence_name": str(lic_slug),
                                       "url": f"https://sketchfab.com/3d-models/{uid}"})
                seen.add(uid)


# ------------------------------------------------------------------ BlendKit
BLENDKIT_HOSTS = ("https://www.blenderkit.com", "https://www.blendkit.com")


def blendkit(lib):
    """BlendKit (blendkit.com, formerly BlenderKit): Blender-native models (.blend), FREE assets only.
    Key: BLENDKIT_API_KEY (free account -> profile -> ADD-ON -> Show API key).
    Licences: CC0 (used freely) and Royalty Free (allowed in commercial videos, but the file itself must never be
    redistributed). Royalty-free files are therefore only used when NOURY_ARTIFACT_KEY is set: they are stored
    encrypted in the cache and the episode artifact is encrypted too."""
    key = os.environ.get("BLENDKIT_API_KEY", "").strip()
    if not enabled("blendkit"):
        return
    if not key:
        print("[Assets] BlendKit : pas de clé BLENDKIT_API_KEY, ignoré")
        return
    headers = {"Authorization": f"Bearer {key}", "accept": "application/json"}
    if not POLICY["restricted"]:
        print("[Assets] BlendKit : licence Royalty Free non autorisée (NOURY_ARTIFACT_KEY absent ou réglage) "
              "-> seulement les modèles CC0")
    scene_uuid = "8f2c1d5e-4b7a-4c1e-9a52-6e0b7d3f1a90"      # fixed id of the Noury project
    models = lib.setdefault("models", {})
    for family, (queries, keep, avoid) in MODEL_FAMILIES.items():
        keep = quota("blendkit", keep)
        _, mine = family_items(models, family, "BlendKit")
        if len(mine) >= keep:
            continue
        seen = {m["id"] for m in models[family]}
        for q in [f"{STYLE_WORDS[1]} {q}" for q in queries[:2]] + queries[:1]:
            if len([x for x in models[family] if x.get("source") == "BlendKit"]) >= keep or budget["left"] <= 0:
                break
            results = []
            query = f"{q} asset_type:model is_free:true order:-score"
            for host in BLENDKIT_HOSTS:
                try:
                    results = http_json(f"{host}/api/v1/search/?" + urllib.parse.urlencode(
                        {"query": query, "page_size": 20, "addon_version": "3.12.0"}), headers).get("results", [])
                    break
                except Exception as exc:
                    print(f"[Assets] BlendKit '{q}' ({host}) : {exc}")
            for a in results:
                if len([x for x in models[family] if x.get("source") == "BlendKit"]) >= keep or budget["left"] <= 0:
                    break
                aid = str(a.get("assetBaseId") or a.get("id") or "")
                title = str(a.get("name", ""))
                lic = accept("BlendKit", title, a.get("license")) if aid and aid not in seen else None
                params = a.get("dictParameters") or {}
                faces = int(params.get("faceCount") or a.get("faceCount") or 0)
                if (not aid or aid in seen or not lic or a.get("isFree") is False or a.get("canDownload") is False
                        or faces > 40000 or params.get("animated") or any(w in title.lower() for w in avoid)
                        or not child_safe(title)):
                    continue
                blend_file = next((f for f in a.get("files", []) if f.get("fileType") == "blend"
                                   and f.get("downloadUrl")), None)
                if not blend_file:
                    continue
                secure = L.needs_encryption(lic)
                dest = LIB / "models" / family / (f"bk_{aid}.blend.enc" if secure else f"bk_{aid}.blend")
                try:
                    if not dest.exists():
                        info = http_json(blend_file["downloadUrl"] + ("&" if "?" in blend_file["downloadUrl"] else "?")
                                         + urllib.parse.urlencode({"scene_uuid": scene_uuid}), headers)
                        url = info.get("filePath") or info.get("url")
                        if not url:
                            raise KeyError("no filePath")
                        data = http_bytes(url)
                        budget["left"] -= 1
                        if not data.startswith(b"BLENDER") and not data[:2] == b"\x1f\x8b" \
                                and not data[:4] == b"\x28\xb5\x2f\xfd":
                            raise ValueError("not a .blend file")
                        dest.parent.mkdir(parents=True, exist_ok=True)
                        plain = dest.with_name(f"bk_{aid}.blend.part")
                        plain.write_bytes(data)
                        if secure:
                            encrypt_file(plain, dest)
                            plain.unlink()
                        else:
                            plain.replace(dest)
                        time.sleep(0.5)
                except Exception as exc:
                    print(f"[Assets] BlendKit {aid} : {exc}")
                    continue
                author = a.get("author") or {}
                models[family].append({"path": rel(dest), "id": aid, "title": title, "format": "blend",
                                       "encrypted": secure, "creator": author.get("fullName", ""),
                                       "source": "BlendKit", "licence": lic,
                                       "licence_name": "BlendKit " + str(a.get("license")),
                                       "url": f"https://www.blendkit.com/asset-gallery-detail/{aid}/"})
                seen.add(aid)


# ------------------------------------------------------------------ Freesound
def to_wav(src, dst, one_shot):
    af = "silenceremove=start_periods=1:start_threshold=-45dB," if one_shot else ""
    af += "highpass=f=40,loudnorm=I=-18:TP=-2"
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(src), "-ac", "1", "-ar", "24000", "-af", af, str(dst)],
                   check=True)


def freesound(lib):
    key = os.environ.get("FREESOUND_API_KEY", "").strip()
    if not enabled("freesound"):
        return
    if not key:
        print("[Assets] Freesound : pas de clé FREESOUND_API_KEY, bruitages procéduraux conservés")
        return
    if not shutil.which("ffmpeg"):
        return
    sounds = lib.setdefault("sounds", {})
    lic_filter = 'license:"Creative Commons 0"' if not ALLOW_CCBY else \
        '(license:"Creative Commons 0" OR license:"Attribution")'
    for skey, (query, dmin, dmax, keep) in SOUNDS.items():
        have = [s for s in sounds.get(skey, []) if (BASE / s["path"]).exists()]
        sounds[skey] = have
        if len(have) >= keep:
            continue
        params = {"query": query, "filter": f"{lic_filter} duration:[{dmin} TO {dmax}]", "sort": "rating_desc",
                  "fields": "id,name,license,username,previews,duration", "page_size": 8, "token": key}
        results = []
        for endpoint in ("https://freesound.org/apiv2/search/", "https://freesound.org/apiv2/search/text/"):
            try:
                results = http_json(endpoint + "?" + urllib.parse.urlencode(params)).get("results", [])
                break
            except Exception as exc:
                print(f"[Assets] Freesound '{query}' : {exc}")
        seen = {s["id"] for s in have}
        for r in results:
            if len(sounds[skey]) >= keep or budget["left"] <= 0:
                break
            sid = str(r.get("id"))
            lic = accept("Freesound", r.get("name", ""), r.get("license")) if str(r.get("id")) not in seen else None
            url = (r.get("previews") or {}).get("preview-hq-mp3")
            if not lic or not url or sid in seen:
                continue
            try:
                mp3 = LIB / "sounds" / skey / f"{sid}.mp3"
                if not save(url, mp3, min_size=2000):
                    break
                wav = mp3.with_suffix(".wav")
                to_wav(mp3, wav, one_shot=not skey.startswith("amb_"))
                mp3.unlink(missing_ok=True)
            except Exception as exc:
                print(f"[Assets] Freesound {sid} : {exc}")
                continue
            sounds[skey].append({"path": rel(wav), "id": sid, "title": r.get("name", ""),
                                 "creator": r.get("username", ""), "source": "Freesound", "licence": lic,
                                 "licence_name": str(r.get("license", "")),
                                 "url": f"https://freesound.org/s/{sid}/"})
            seen.add(sid)


# ------------------------------------------------------------------ manual folder
# ------------------------------------------------------------------ Objaverse (Hugging Face)
OBJAVERSE = "https://huggingface.co/datasets/allenai/objaverse/resolve/main/"
LVIS_FAMILIES = {     # family -> LVIS category names to look for (missing names are simply ignored)
    "tree": ["tree", "bonsai"], "pine": ["pine_tree", "fir_tree"], "palm": ["palm_tree"],
    "bush": ["bush", "shrub"], "mushroom": ["mushroom"], "rock": ["boulder", "rock"],
    "house": ["house", "cabin", "cottage", "hut"],
    "village_prop": ["bench", "cart", "barrel", "wheelbarrow", "lantern", "mailbox_(at_home)", "well"],
    "flower": ["flowerpot", "flower_arrangement", "sunflower", "tulip"],
    "boat": ["boat", "canoe", "kayak", "rowboat"], "snowman": ["snowman"],
}


def _gz_json(url, dest):
    """Downloads a .json.gz index once (cached in assets/library/_index) and loads it."""
    if not dest.exists():
        data = http_bytes(url, timeout=600)
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
    return json.loads(gzip.decompress(dest.read_bytes()).decode("utf-8"))


def objaverse(lib):
    """Objaverse 1.0 (allenai/objaverse on Hugging Face): 800 000+ downloadable Sketchfab objects, each with its own
    Creative Commons licence in the metadata (mostly CC-BY, some CC0, some NC/SA which are refused). No key needed.
    Objects are picked through the LVIS categories (tree, boat, snowman, bench...) and filtered by the licence
    policy, polygon count, animation, age restriction and child-safe titles. Stylised names are preferred."""
    if not enabled("objaverse"):
        return
    cfg = source_cfg("objaverse")
    idx = LIB / "_index"
    try:
        lvis = _gz_json(OBJAVERSE + "lvis-annotations.json.gz", idx / "lvis-annotations.json.gz")
        paths = _gz_json(OBJAVERSE + "object-paths.json.gz", idx / "object-paths.json.gz")
    except Exception as exc:
        print(f"[Assets] Objaverse : index indisponible ({exc})")
        return
    norm = lambda n: n.lower().replace(" ", "_")
    cats = {norm(k): v for k, v in lvis.items()}
    shards, new_shards = {}, [int(cfg.get("max_new_shards", 3))]

    def shard(name):
        if name in shards:
            return shards[name]
        dest = idx / "metadata" / f"{name}.json.gz"
        if not dest.exists():
            if new_shards[0] <= 0:
                return None
            new_shards[0] -= 1
        try:
            shards[name] = _gz_json(OBJAVERSE + f"metadata/{name}.json.gz", dest)
        except Exception as exc:
            print(f"[Assets] Objaverse metadata {name} : {exc}")
            shards[name] = None
        return shards[name]

    models = lib.setdefault("models", {})
    for family, (_, keep, avoid) in MODEL_FAMILIES.items():
        keep = quota("objaverse", min(keep, 2))
        _, mine = family_items(models, family, "Objaverse")
        if len(mine) >= keep:
            continue
        seen = {m["id"] for m in models[family]}
        uids = [u for c in LVIS_FAMILIES.get(family, []) for u in cats.get(norm(c), []) if u in paths]
        uids = sorted(set(uids), key=lambda u: hash((family, u)) & 0xFFFF)[:120]
        by_shard = {}
        for u in uids:
            by_shard.setdefault(paths[u].split("/")[1], []).append(u)
        # shards already cached first, then the ones with most candidates
        order = sorted(by_shard, key=lambda n: (not (idx / "metadata" / f"{n}.json.gz").exists(), -len(by_shard[n])))
        candidates = []
        for name in order:
            meta = shard(name)
            if meta:
                candidates += [(u, meta[u]) for u in by_shard[name] if u in meta]
        style = lambda m: -sum(w in (m.get("name", "") + " " + " ".join(t.get("name", "") for t in m.get("tags", [])))
                               .lower() for w in ("low poly", "lowpoly", "stylized", "stylised", "cartoon", "toon"))
        candidates.sort(key=lambda um: (style(um[1]), -int(um[1].get("likeCount") or 0)))
        for uid, m in candidates:
            if len([x for x in models[family] if x.get("source") == "Objaverse"]) >= keep or budget["left"] <= 0:
                break
            title = str(m.get("name", ""))
            if (uid in seen or m.get("isAgeRestricted") or int(m.get("animationCount") or 0) > 0
                    or int(m.get("faceCount") or 0) > 25000 or any(w in title.lower() for w in avoid)
                    or not child_safe(title)):
                continue
            lic_text = m.get("license")
            lic = accept("Objaverse", title, lic_text)
            if not lic or L.needs_encryption(lic):
                continue
            try:
                path = save(OBJAVERSE + paths[uid], LIB / "models" / family / f"obj_{uid}.glb", min_size=1000,
                            magic=b"glTF")
            except Exception as exc:
                print(f"[Assets] Objaverse {uid} : {exc}")
                continue
            if not path:
                break
            user = m.get("user") or {}
            models[family].append({"path": path, "id": uid, "title": title, "format": "glb",
                                   "creator": user.get("displayName") or user.get("username", ""),
                                   "source": "Objaverse", "licence": lic, "licence_name": str(lic_text),
                                   "url": m.get("viewerUrl") or f"https://sketchfab.com/3d-models/{uid}"})
            seen.add(uid)


# ------------------------------------------------------------------ packs (direct links)
MODEL_EXT = (".glb", ".gltf", ".fbx", ".obj", ".blend")
EXT_PREF = {".glb": 0, ".blend": 1, ".gltf": 2, ".fbx": 3, ".obj": 4}


def slug(text):
    return "".join(c if c.isalnum() else "_" for c in text.lower()).strip("_")[:40]


def packs(lib):
    """Complete packs downloaded from a direct link (config/asset_sources.json -> "packs").
    Each pack declares its licence; files are sorted into families with filename patterns.
    Restricted licences (Quaternius QAL...) keep only self-contained .glb / .blend files, encrypted."""
    if not enabled("packs"):
        return
    models = lib.setdefault("models", {})
    for pack in CONFIG.get("packs", []):
        if not pack.get("enabled") or not pack.get("url"):
            continue
        name = pack.get("name", "pack")
        lic = accept("Pack", name, pack.get("licence"))
        if not lic:
            print(f"[Assets] pack '{name}' : licence {pack.get('licence')} refusée par la configuration")
            continue
        secure = L.needs_encryption(lic)
        folder = LIB / "packs" / slug(name)
        if not folder.exists() or not any(folder.rglob("*")):
            if budget["left"] <= 0:
                continue
            try:
                data = http_bytes(pack["url"], timeout=600)
                budget["left"] -= 1
                with zipfile.ZipFile(io.BytesIO(data)) as z:
                    for n in z.namelist():
                        if n.endswith("/") or ".." in n or n.startswith("/"):
                            continue
                        low = n.lower()
                        if secure:
                            if not low.endswith((".glb", ".blend")):
                                continue
                            plain = folder / "_tmp" / Path(n).name
                            plain.parent.mkdir(parents=True, exist_ok=True)
                            plain.write_bytes(z.read(n))
                            encrypt_file(plain, folder / (Path(n).name + ".enc"))
                            plain.unlink()
                        else:
                            dest = folder / n
                            dest.parent.mkdir(parents=True, exist_ok=True)
                            dest.write_bytes(z.read(n))
                shutil.rmtree(folder / "_tmp", ignore_errors=True)
                print(f"[Assets] pack '{name}' téléchargé ({lic}{', chiffré' if secure else ''})")
            except Exception as exc:
                print(f"[Assets] pack '{name}' : {exc}")
                shutil.rmtree(folder, ignore_errors=True)
                continue
        files = [f for f in folder.rglob("*") if f.is_file()]
        for family, patterns in pack.get("families", {}).items():
            have = [m for m in models.get(family, []) if (BASE / m["path"]).exists() and m.get("pack") != name]
            chosen = {}
            for f in sorted(files):
                plain_name = f.name[:-4] if f.name.endswith(".enc") else f.name
                stem, ext = Path(plain_name).stem, Path(plain_name).suffix.lower()
                if ext not in MODEL_EXT or not any(fnmatch.fnmatch(plain_name.lower(), p.lower()) for p in patterns):
                    continue
                best = chosen.get(stem)                       # prefer .glb > .blend > .gltf > .fbx > .obj
                if best is None or EXT_PREF[ext] < EXT_PREF[best[1]]:
                    chosen[stem] = (f, ext)
            items = []
            for stem, (f, ext) in sorted(chosen.items())[: int(pack.get("max_per_family", 4))]:
                items.append({"path": rel(f), "id": f"{slug(name)}_{stem}", "title": stem, "format": ext.lstrip("."),
                              "encrypted": f.name.endswith(".enc"), "creator": pack.get("credit", ""),
                              "source": name, "pack": name, "licence": lic,
                              "licence_name": str(pack.get("licence")), "url": pack.get("page", "")})
            if items:
                models[family] = have + items


# ------------------------------------------------------------------ manual folder
def manual_licence(d):
    """<folder>/licence.txt : line 1 = licence (CC0, CC-BY, QAL, Royalty Free...), line 2 = author / credit."""
    f = d / "licence.txt"
    if not f.exists():
        return "MANUEL", ""
    lines = [x.strip() for x in f.read_text(encoding="utf-8").splitlines() if x.strip()]
    return (lines[0] if lines else "MANUEL"), (lines[1] if len(lines) > 1 else "")


def manual(lib):
    """Files you put by hand in assets/manual/ always win over downloaded ones.
    textures/<kind>/   *color* or *diff* or *albedo*, *rough*, *normal* or *nor*   (jpg / png)
    hdri/<mood>/       one .hdr or .exr
    models/<family>/   .glb .gltf .fbx .obj .blend   (or .glb.enc / .blend.enc made with tools/encrypt_asset.sh)
    sounds/<key>/      .wav / .mp3 / .ogg
    Optional <folder>/licence.txt declares the licence (checked like any other source).
    Restricted licences MUST be encrypted: the repository is public, a plain file there would be redistributed."""
    if not enabled("manual") or not MANUAL.exists():
        return

    def gate(d, title, encrypted=False):
        text, credit = manual_licence(d)
        if text == "MANUEL":
            return "MANUEL", credit
        code = accept("manuel", title, text)
        if code and L.needs_encryption(code) and not encrypted:
            REJECTED.append(("manuel", title, text, "restreinte NON chiffrée (dépôt public !)"))
            return None, credit
        return code, credit

    for d in sorted((MANUAL / "textures").glob("*/")) if (MANUAL / "textures").exists() else []:
        files = [f for f in d.iterdir() if f.suffix.lower() in (".jpg", ".jpeg", ".png")]
        pick = lambda *tags: next((rel(f) for f in files if any(t in f.name.lower() for t in tags)), None)
        maps = {"diff": pick("color", "diff", "albedo", "basecolor"), "rough": pick("rough"),
                "nor": pick("normal", "nor")}
        code, credit = gate(d, d.name)
        if maps["diff"] and code:
            lib.setdefault("textures", {})[d.name] = {**maps, "id": d.name, "source": "manuel", "licence": code,
                                                      "creator": credit}
    for d in sorted((MANUAL / "hdri").glob("*/")) if (MANUAL / "hdri").exists() else []:
        f = next((f for f in d.iterdir() if f.suffix.lower() in (".hdr", ".exr")), None)
        code, credit = gate(d, d.name)
        if f and code:
            lib.setdefault("hdri", {})[d.name] = {"path": rel(f), "id": f.stem, "source": "manuel", "licence": code,
                                                  "creator": credit}
    for d in sorted((MANUAL / "models").glob("*/")) if (MANUAL / "models").exists() else []:
        items = []
        for f in sorted(d.iterdir()):
            enc = f.name.endswith(".enc")
            plain = f.name[:-4] if enc else f.name
            if Path(plain).suffix.lower() not in MODEL_EXT:
                continue
            code, credit = gate(d, plain, enc)
            if code:
                items.append({"path": rel(f), "id": Path(plain).stem, "title": Path(plain).stem, "source": "manuel",
                              "licence": code, "creator": credit, "encrypted": enc,
                              "format": Path(plain).suffix.lower().lstrip(".")})
        if items:
            lib.setdefault("models", {})[d.name] = items
    for d in sorted((MANUAL / "sounds").glob("*/")) if (MANUAL / "sounds").exists() else []:
        code, credit = gate(d, d.name)
        if not code:
            continue
        out = []
        for f in sorted(d.iterdir()):
            if f.suffix.lower() in (".wav", ".mp3", ".ogg", ".flac"):
                wav = LIB / "sounds_manual" / d.name / (f.stem + ".wav")
                wav.parent.mkdir(parents=True, exist_ok=True)
                try:
                    if not wav.exists():
                        to_wav(f, wav, one_shot=not d.name.startswith("amb_"))
                    out.append({"path": rel(wav), "id": f.stem, "title": f.stem, "source": "manuel",
                                "licence": code, "creator": credit})
                except Exception as exc:
                    print(f"[Assets] son manuel {f.name} : {exc}")
        if out:
            lib.setdefault("sounds", {})[d.name] = out


# ------------------------------------------------------------------ credits
def credits(lib):
    rows = []
    for group in ("hdri", "textures"):
        for k, v in lib.get(group, {}).items():
            rows.append((group, k, v))
    for group in ("models", "sounds"):
        for k, items in lib.get(group, {}).items():
            for v in items:
                rows.append((group, k, v))
    lines = ["# Crédits des ressources", "", f"Politique de licence : {POLICY}", "",
             "| Type | Usage | Ressource | Auteur | Source | Licence |", "|---|---|---|---|---|---|"]
    for group, k, v in rows:
        lines.append(f"| {group} | {k} | {v.get('title') or v.get('id', '')} | {v.get('creator', '')} | "
                     f"{v.get('source', '')} | {v.get('licence', '')} |")
    if REJECTED:
        lines += ["", "## Refusés pendant ce lancement", "", "| Source | Ressource | Licence annoncée | Raison |",
                  "|---|---|---|---|"]
        lines += [f"| {s} | {t} | {lt} | {why} |" for s, t, lt, why in REJECTED[:300]]
    (LIB / "CREDITS.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    LIB.mkdir(parents=True, exist_ok=True)
    path = LIB / "library.json"
    lib = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    for name, fn in (("Poly Haven", polyhaven), ("ambientCG", ambientcg), ("Poly Pizza", polypizza),
                     ("Sketchfab", sketchfab), ("BlendKit", blendkit), ("Objaverse", objaverse),
                     ("packs", packs), ("Freesound", freesound), ("dossier manuel", manual)):
        try:
            fn(lib)
        except Exception as exc:                # one source down never blocks the others
            print(f"[Assets] {name} indisponible : {exc}")
    lib["updated"] = time.strftime("%Y-%m-%d %H:%M")
    path.write_text(json.dumps(lib, ensure_ascii=False, indent=2), encoding="utf-8")
    credits(lib)
    n_models = sum(len(v) for v in lib.get("models", {}).values())
    n_sounds = sum(len(v) for v in lib.get("sounds", {}).values())
    print(f"[Assets] bibliothèque : {len(lib.get('hdri', {}))} ciels, {len(lib.get('textures', {}))} matières, "
          f"{n_models} modèles 3D, {n_sounds} sons ({MAX_NEW_DOWNLOADS - budget['left']} nouveaux téléchargements, "
          f"{len(REJECTED)} refus de licence)")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:                    # never block the episode
        print(f"[Assets] ignoré : {exc}")
    sys.exit(0)
