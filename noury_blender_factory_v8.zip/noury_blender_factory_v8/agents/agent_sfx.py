#!/usr/bin/env python3
"""Sound effects synchronised with the animation.

Each sound uses, in order: a real recording from the asset library (Freesound / manual folder,
see agent_assets.py), otherwise a procedural synthesis (always available, royalty free).
- ambience per location: birds, wind, sea waves, magic shimmer, night crickets, soft snow wind
- footsteps exactly when the feet touch the ground (same formulas as noury_anim.py)
- fall thud, jump landings, wind gusts, sparkles around the magic object, magic bloom swell
- guest animals: meow, woof, chirps, hoot when they appear
Output: export/sfx.wav
"""
import json
import math
from pathlib import Path

import numpy as np
import soundfile as sf
from scipy.signal import butter, sosfilt

SR = 24000
rng = np.random.default_rng(42)
SPECIES_SOUND = {"cat": "meow", "dog": "woof", "bird": "chirp", "owl": "hoot"}
BASE = Path(__file__).resolve().parent.parent


# ------------------------------------------------------------------ library (real recordings)
class Library:
    def __init__(self):
        p = BASE / "assets" / "library" / "library.json"
        lib = json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
        self.files = {k: [BASE / s["path"] for s in v if (BASE / s["path"]).exists()]
                      for k, v in lib.get("sounds", {}).items()}
        self.cache = {}
        self.used = set()
        self.files_used = set()

    def has(self, key):
        return bool(self.files.get(key))

    def get(self, key):
        """Random recording of `key`, mono 24 kHz, peak 0.8 (None if the library has none)."""
        files = self.files.get(key)
        if not files:
            return None
        f = files[int(rng.integers(len(files)))]
        self.files_used.add(str(f.resolve().relative_to(BASE)))
        if f not in self.cache:
            data, sr = sf.read(str(f), dtype="float32")
            if data.ndim > 1:
                data = data.mean(axis=1)
            if sr != SR:
                data = np.interp(np.arange(0, len(data), sr / SR), np.arange(len(data)), data)
            self.cache[f] = data / max(1e-6, float(np.abs(data).max())) * 0.8
        self.used.add(key)
        return self.cache[f]

    def loop(self, key, n):
        """Loop an ambience recording to n samples with 1 s cross-fades and a random start."""
        src = self.get(key)
        if src is None or len(src) < SR * 2:
            return None
        fade = SR
        out = np.zeros(n)
        pos = 0
        start = int(rng.integers(0, max(1, len(src) - SR)))
        piece = src[start:]
        while pos < n:
            m = min(len(piece), n - pos)
            seg = piece[:m].copy()
            if pos > 0:
                k = min(fade, m)
                seg[:k] *= np.linspace(0, 1, k)
                out[pos:pos + k] *= np.linspace(1, 0, k)
            out[pos:pos + m] += seg
            if pos + m >= n:
                break
            pos += m - fade                      # next piece overlaps the last second (cross-fade)
            piece = src
        return out


LIB = None


def band(x, lo=None, hi=None, order=2):
    if lo and hi:
        sos = butter(order, [lo, hi], btype="band", fs=SR, output="sos")
    elif lo:
        sos = butter(order, lo, btype="high", fs=SR, output="sos")
    else:
        sos = butter(order, hi, btype="low", fs=SR, output="sos")
    return sosfilt(sos, x)


def put(buf, t, snd, gain=1.0):
    if snd is None:
        return
    a = int(t * SR)
    if a < 0 or a >= len(buf):
        return
    m = min(len(snd), len(buf) - a)
    buf[a:a + m] += snd[:m] * gain


def env_exp(n, decay):
    return np.exp(-np.arange(n) / SR * decay)


def trimmed(x, seconds):
    n = min(len(x), int(seconds * SR))
    out = x[:n].copy()
    k = min(n, int(0.03 * SR))
    out[n - k:] *= np.linspace(1, 0, k)
    return out


# ------------------------------------------------------------------ one-shots
def footstep(surface):
    real = LIB.get(f"step_{surface}")
    if real is not None:
        return trimmed(real, 0.35) * rng.uniform(0.35, 0.5)
    n = int(0.12 * SR)
    noise = rng.standard_normal(n)
    if surface == "sand":
        s = band(noise, 300, 2500) * env_exp(n, 35) * 0.5
    elif surface == "snow":
        s = band(noise, 500, 4000) * env_exp(n, 25) * 0.55
    else:   # grass
        s = band(noise, 900, 5000) * env_exp(n, 45) * 0.35
    tt = np.arange(n) / SR
    s += 0.5 * np.sin(2 * np.pi * 90 * tt) * env_exp(n, 40)
    return s * rng.uniform(0.7, 1.0)


def thud(strength=1.0, real_ok=True):
    real = LIB.get("thud") if real_ok else None
    if real is not None:
        return trimmed(real, 0.8) * strength * 0.7
    n = int(0.35 * SR)
    tt = np.arange(n) / SR
    s = np.sin(2 * np.pi * (70 * np.exp(-tt * 8) + 40) * tt) * env_exp(n, 12)
    s += band(rng.standard_normal(n), 200, 1200) * env_exp(n, 30) * 0.4
    return s * strength


def chime(freq):
    real = LIB.get("chime")
    if real is not None:
        return trimmed(real, 1.5) * 0.25
    n = int(1.2 * SR)
    tt = np.arange(n) / SR
    return (np.sin(2 * np.pi * freq * tt) + 0.5 * np.sin(2 * np.pi * freq * 2.76 * tt) * env_exp(n, 10)) \
        * env_exp(n, 4.5) * 0.25


def whoosh(seconds=2.0):
    real = LIB.get("whoosh")
    if real is not None:
        return trimmed(real, seconds) * 0.6
    n = int(seconds * SR)
    x = band(rng.standard_normal(n), 250, 2500)
    return x * np.sin(np.linspace(0, math.pi, n)) ** 2 * 0.6


def swell(seconds=8.0):
    n = int(seconds * SR)
    tt = np.arange(n) / SR
    s = np.zeros(n)
    for k, f in enumerate((523.25, 659.25, 783.99, 1046.5, 1318.5)):
        s += np.sin(2 * np.pi * f * tt * (1 + 0.002 * np.sin(2 * np.pi * (3 + k) * tt)))
    shape = np.minimum(1, tt / (seconds * 0.7)) * np.minimum(1, (seconds - tt) / 1.0)
    return s * shape * 0.06


def glide(f_points, seconds, harmonics=6, lo=400, hi=4000):
    n = int(seconds * SR)
    f = np.interp(np.linspace(0, 1, n), np.linspace(0, 1, len(f_points)), f_points)
    ph = 2 * np.pi * np.cumsum(f) / SR
    s = sum(np.sin(k * ph) / k for k in range(1, harmonics + 1))
    return band(s, lo, hi) * np.sin(np.linspace(0, math.pi, n)) ** 0.7


def animal_sound(kind):
    real = LIB.get(kind)
    if real is not None:
        return trimmed(real, 2.5) * 0.7
    if kind == "meow":
        return glide([480, 720, 760, 520], 0.65) * 0.5
    if kind == "woof":
        out = np.zeros(int(0.7 * SR))
        for k in (0.0, 0.32):
            b = glide([300, 420, 260], 0.18, harmonics=8, lo=150, hi=2500)
            b += band(rng.standard_normal(len(b)), 300, 2000) * 0.3 * np.sin(np.linspace(0, math.pi, len(b)))
            put(out, k, b * 0.7)
        return out
    if kind == "chirp":
        out = np.zeros(int(0.8 * SR))
        t = 0.0
        for _ in range(3):
            m = int(0.09 * SR)
            ph = 2 * np.pi * np.cumsum(np.linspace(3200, 4600, m)) / SR
            put(out, t, np.sin(ph) * np.sin(np.linspace(0, math.pi, m)) * 0.3)
            t += 0.14
        return out
    if kind == "hoot":
        out = np.zeros(int(1.2 * SR))
        for k, f in ((0.0, 390), (0.5, 360)):
            m = int(0.38 * SR)
            tt = np.arange(m) / SR
            put(out, k, np.sin(2 * np.pi * f * tt) * np.sin(np.linspace(0, math.pi, m)) ** 1.5 * 0.4)
        return out
    return np.zeros(1)


# ------------------------------------------------------------------ ambiences
def birds(n, density):
    real = LIB.loop("amb_birds", n)
    if real is not None:
        return real * 0.22 * min(1.0, density)
    out = np.zeros(n)
    t = rng.uniform(0.3, 2.0)
    while t < n / SR:
        for _ in range(rng.integers(1, 4)):
            m = int(rng.uniform(0.06, 0.14) * SR)
            f0, f1 = rng.uniform(2500, 4200), rng.uniform(2000, 5000)
            ph = 2 * np.pi * np.cumsum(np.linspace(f0, f1, m)) / SR
            put(out, t, np.sin(ph) * np.sin(np.linspace(0, math.pi, m)) * 0.12)
            t += m / SR + rng.uniform(0.03, 0.09)
        t += rng.uniform(1.0, 4.0) / density
    return out


def crickets(n):
    real = LIB.loop("amb_crickets", n)
    if real is not None:
        return real * 0.2
    out = np.zeros(n)
    tt = np.arange(n) / SR
    for f, rate, ph in ((4300, 0.7, 0.0), (4700, 0.55, 1.3)):
        chirp_env = (np.sin(2 * np.pi * rate * tt + ph) > 0.4) * (0.5 + 0.5 * np.sin(2 * np.pi * 30 * tt))
        out += np.sin(2 * np.pi * f * tt) * chirp_env * 0.025
    return band(out, 3000, 6000)


def wind(n, level):
    real = LIB.loop("amb_wind", n)
    if real is not None:
        return real * 0.25 * level
    x = band(rng.standard_normal(n), 120, 900)
    tt = np.arange(n) / SR
    gust = 0.55 + 0.45 * np.sin(2 * np.pi * 0.11 * tt + 1.0) * np.sin(2 * np.pi * 0.047 * tt)
    return x * gust * 0.18 * level


def waves(n):
    real = LIB.loop("amb_waves", n)
    if real is not None:
        return real * 0.3
    x = band(np.cumsum(rng.standard_normal(n)) * 0.02, 150, 1800)
    tt = np.arange(n) / SR
    cycle = (np.sin(2 * np.pi * tt / 7.0) * 0.5 + 0.5) ** 3
    return x * (0.15 + 0.85 * cycle) * 0.35


def shimmer(n):
    tt = np.arange(n) / SR
    s = sum(np.sin(2 * np.pi * f * tt) * (0.5 + 0.5 * np.sin(2 * np.pi * (0.2 + 0.07 * k) * tt + k))
            for k, f in enumerate((1568, 2093, 2637, 3136)))
    return s * 0.012


def ambience(p, n):
    a = wind(n, max(0.15, float(p.get("wind", 0.1))))
    if p.get("night"):
        a = a + crickets(n)
    elif p.get("snow"):
        a = a * 0.7
    elif p.get("terrain") == "meadow":
        a = a + birds(n, 1.2 if "trees" in p.get("props", []) else 0.8)
    if p.get("water"):
        a = a + waves(n)
    if p.get("glow"):
        a = a + shimmer(n)
    return a


# ------------------------------------------------------------------ main
def steps(buf, f, t0, t1, surface, gain, phases=(0.0, 0.9)):
    """Foot contact when cos(t*f + phase) == 0 (lowest body position in noury_anim)."""
    for ph in phases:
        k = math.ceil((t0 * f + ph - math.pi / 2) / math.pi)
        while True:
            t = (math.pi / 2 + k * math.pi - ph) / f
            if t >= t1:
                break
            if t >= t0:
                put(buf, t, footstep(surface), gain)
            k += 1


def main():
    global LIB
    LIB = Library()
    out = BASE / "export"
    script = json.loads((out / "script_config.json").read_text(encoding="utf-8"))
    pal = json.loads((out / "sets_config.json").read_text(encoding="utf-8"))["environments"]
    actors = {c["key"]: c for c in json.loads((out / "actors_config.json").read_text(encoding="utf-8"))["characters"]}
    duration = float(script.get("duration_seconds", 240))
    n = int(duration * SR)
    buf = np.zeros(n)
    fade = int(1.5 * SR)
    seen = set()

    for i, s in enumerate(script["scenes"]):
        p = pal.get(s["environment"], {})
        a = max(0, int(s["start"] * SR) - fade // 2)
        b = min(n, int(s["end"] * SR) + fade // 2)
        amb = ambience(p, b - a)
        e = np.ones(b - a)
        if i:
            e[:fade] = np.linspace(0, 1, fade)
        if i < len(script["scenes"]) - 1:
            e[-fade:] = np.linspace(1, 0, fade)
        buf[a:b] += amb * e

        start, end, act = float(s["start"]), float(s["end"]), s["action"]
        surface = "snow" if p.get("snow") else ("sand" if p.get("terrain") == "coast" else "grass")
        if act == "approach_seed":
            steps(buf, 6.5, start, start + 0.6 * (end - start), surface, 0.7)
        elif act == "meet_guest":
            steps(buf, 6.5, start, start + 0.35 * (end - start), surface, 0.7)
        elif act == "run_together":
            steps(buf, 10.0, start, end, surface, 1.0)
        for g in s.get("guests", []):
            if g["act"] == "enter" and actors.get(g["key"], {}).get("kind") != "animal":
                steps(buf, 6.5, start, start + 3.0, surface, 0.5, phases=(0.4,))
            sp = actors.get(g["key"], {}).get("species")
            if sp in SPECIES_SOUND and g["key"] not in seen:
                put(buf, start + 1.0, animal_sound(SPECIES_SOUND[sp]), 0.9)
            seen.add(g["key"])
        if act == "brace_wind":
            put(buf, start + 0.3, whoosh(3.0), 1.0)
            put(buf, start + 12.0, whoosh(2.5), 0.8)
        if act == "help_friend":
            put(buf, start + 2.8, thud(1.0), 0.9)
        if act == "celebrate":
            if s.get("bloom", True):
                put(buf, start + 0.2, swell(4.0), 1.2)
            for ph in (0.0, 0.9 * 1.4):
                k = math.ceil((start * 6.0 + ph - math.pi) / (2 * math.pi))
                while True:
                    t = (math.pi + 2 * math.pi * k - ph) / 6.0
                    if t >= end:
                        break
                    if t >= start:
                        put(buf, t, thud(0.35, real_ok=False), 0.6)
                    k += 1
        if act == "plant_seed" and s.get("magic", True):
            put(buf, start + 0.7 * (end - start), swell(8.0), 1.4)
        if s.get("magic", True) and act != "celebrate":
            visible_until = start + 0.7 * (end - start) if act == "plant_seed" else end
            t = start + rng.uniform(0.2, 1.0)
            while t < visible_until:
                put(buf, t, chime(rng.choice([2093, 2349, 2637, 3136, 3520])), 0.5)
                t += rng.uniform(1.0, 2.4) if LIB.has("chime") else rng.uniform(0.7, 1.8)

    buf[:SR] *= np.linspace(0, 1, SR)
    buf[-2 * SR:] *= np.linspace(1, 0, 2 * SR)
    buf /= max(1e-6, np.abs(buf).max()) / 0.7
    sf.write(str(out / "sfx.wav"), buf.astype(np.float32), SR, subtype="PCM_16")
    (out / "sfx_used.json").write_text(json.dumps(sorted(LIB.files_used), indent=2), encoding="utf-8")
    real = sorted(LIB.used)
    print(f"[SFX] bruitages prêts - enregistrements réels : {', '.join(real) if real else 'aucun (synthèse)'}")


if __name__ == "__main__":
    main()
