#!/usr/bin/env python3
"""Licence audit of the asset library, run before every scene build.

- every model / sound / texture / sky is re-checked against the CURRENT policy (config/asset_sources.json):
  an entry that is no longer allowed is removed from the library (quarantine), so it can never reach a video;
- a "restricted" file (no redistribution) that is NOT encrypted is removed as well (the repository is public);
- writes assets/library/LICENCE_REPORT.md (counts per source and licence + every removal).
Exit code 0 (the episode continues with what is allowed). Run by hand: python agents/agent_licence_check.py
"""
import json
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import licences as L  # noqa: E402

BASE = Path(__file__).resolve().parent.parent
LIB = BASE / "assets" / "library"


def verdict(item, pol):
    code = item.get("licence")
    if code == "MANUEL":
        return True, "déclaré à la main (ajoute licence.txt pour qu'il soit vérifié)"
    if code not in ("CC0", "CC-BY", "CC-BY-SA", "RESTRICTED"):
        code = L.normalise(code)
    if not code or not L.allowed(code, pol):
        return False, f"licence {item.get('licence_name') or item.get('licence')} non autorisée"
    if L.needs_encryption(code) and not item.get("encrypted") and not str(item.get("path", "")).endswith(".enc"):
        return False, "licence restreinte mais fichier non chiffré"
    if L.needs_credit(code) and not (item.get("creator") or item.get("url")):
        return False, "CC-BY sans auteur ni lien : impossible de créditer"
    return True, ""


def main():
    path = LIB / "library.json"
    if not path.exists():
        print("[Licences] pas de bibliothèque : rien à vérifier")
        return
    lib = json.loads(path.read_text(encoding="utf-8"))
    pol = L.policy()
    kept, removed, notes = Counter(), [], []
    for group in ("hdri", "textures"):
        for k in list(lib.get(group, {})):
            item = lib[group][k]
            ok, why = verdict(item, pol)
            if ok:
                kept[(item.get("source"), item.get("licence"))] += 1
                if why:
                    notes.append((group, k, item.get("source"), why))
            else:
                removed.append((group, k, item.get("source"), item.get("title") or item.get("id"), why))
                del lib[group][k]
    for group in ("models", "sounds"):
        for k, items in lib.get(group, {}).items():
            keep = []
            for item in items:
                ok, why = verdict(item, pol)
                if ok:
                    keep.append(item)
                    kept[(item.get("source"), item.get("licence"))] += 1
                    if why:
                        notes.append((group, k, item.get("source"), why))
                else:
                    removed.append((group, k, item.get("source"), item.get("title") or item.get("id"), why))
                    f = BASE / item.get("path", "")
                    if f.is_file() and why.startswith("licence restreinte"):
                        f.unlink()                       # never keep an unencrypted restricted file around
            lib[group][k] = keep
    path.write_text(json.dumps(lib, ensure_ascii=False, indent=2), encoding="utf-8")
    lines = ["# Rapport de licences", "", f"Politique : {pol}", "", "| Source | Licence | Éléments autorisés |",
             "|---|---|---|"]
    lines += [f"| {s} | {lic} | {n} |" for (s, lic), n in sorted(kept.items(), key=lambda x: (str(x[0][0]), str(x[0][1])))]
    if removed:
        lines += ["", "## Retirés de la bibliothèque", "", "| Type | Usage | Source | Ressource | Raison |",
                  "|---|---|---|---|---|"]
        lines += [f"| {g} | {k} | {s} | {t} | {w} |" for g, k, s, t, w in removed]
    if notes:
        lines += ["", "## À vérifier", ""] + [f"- {g}/{k} ({s}) : {w}" for g, k, s, w in notes]
    (LIB / "LICENCE_REPORT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"[Licences] {sum(kept.values())} éléments autorisés, {len(removed)} retirés, {len(notes)} à vérifier "
          f"-> assets/library/LICENCE_REPORT.md")


if __name__ == "__main__":
    main()
