#!/usr/bin/env python3
"""Noury Blender Factory supervisor.

python agents/agent_supervisor.py prepare    story, asset library, voices, music, sound effects, lip-sync, scene
python agents/agent_supervisor.py render I N render chunk I of N (default 0 1 = everything)
python agents/agent_supervisor.py finalize   montage, QC, thumbnail, metadata, YouTube upload
python agents/agent_supervisor.py all        everything on one machine (GPU PC / self-hosted runner)
"""
import logging
import subprocess
import sys
import time
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(levelname)s:NOURY:%(message)s")
log = logging.getLogger("Supervisor")

PREPARE = ["agent_director.py", "agent_scriptwriter.py", "agent_sets.py", "agent_actors.py", "agent_assets.py",
           "agent_licence_check.py", "agent_audio.py", "agent_sfx.py", "agent_lipsync.py", "agent_expression.py", "agent_animation.py",
           "agent_blender_build.py"]
FINALIZE = ["agent_montage.py", "agent_quality_control.py", "agent_thumbnail.py",
            "agent_youtube_metadata.py", "agent_youtube_upload.py"]


def run(name, *args):
    here = Path(__file__).resolve().parent
    t0 = time.time()
    log.info(f"=== {name} {' '.join(args)} ===")
    r = subprocess.run([sys.executable, str(here / name), *args], cwd=str(here))
    if r.returncode:
        log.error(f"{name} failed (code {r.returncode}) - chain stopped, nothing published")
        sys.exit(r.returncode)
    log.info(f"{name} OK ({time.time() - t0:.0f}s)")


def main():
    stage = sys.argv[1] if len(sys.argv) > 1 else "all"
    if stage in ("prepare", "all"):
        for a in PREPARE:
            run(a)
    if stage == "render":
        run("agent_blender_render.py", *(sys.argv[2:4] or ["0", "1"]))
    if stage == "all":
        run("agent_blender_render.py", "0", "1")
    if stage in ("finalize", "all"):
        for a in FINALIZE:
            run(a)
    log.info(f"Stage '{stage}' finished.")


if __name__ == "__main__":
    main()
