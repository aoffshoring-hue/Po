#!/usr/bin/env python3
"""Builds export/episode.blend with Blender (headless).

Royalty-free BlendKit files are stored encrypted in the library: they are decrypted into a temporary
folder only for the build, then deleted. If NOURY_ARTIFACT_KEY is set, episode.blend is encrypted
(episode.blend.enc) before being shared with the render machines (see tools/secure_episode.sh).
"""
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path


def blender_bin() -> str:
    b = os.environ.get("BLENDER_BIN") or shutil.which("blender")
    if not b:
        sys.exit("[Blender] executable not found (set BLENDER_BIN or add blender to PATH)")
    return b


def decrypt(src, dst, key):
    subprocess.run(["openssl", "enc", "-d", "-aes-256-cbc", "-pbkdf2", "-in", str(src), "-out", str(dst),
                    "-pass", "env:NOURY_ARTIFACT_KEY"], check=True, env={**os.environ, "NOURY_ARTIFACT_KEY": key})


def main():
    base = Path(__file__).resolve().parent.parent
    secure = base / "export" / "_secure"
    key = os.environ.get("NOURY_ARTIFACT_KEY", "").strip()
    lib_path = base / "assets" / "library" / "library.json"
    n = 0
    if key and lib_path.exists():
        lib = json.loads(lib_path.read_text(encoding="utf-8"))
        secure.mkdir(parents=True, exist_ok=True)
        for items in lib.get("models", {}).values():
            for m in items:
                src = base / m["path"]
                if m.get("encrypted") and src.exists():
                    try:
                        decrypt(src, secure / src.name.replace(".enc", ""), key)
                        n += 1
                    except Exception as exc:
                        print(f"[Blender build] déchiffrement impossible {src.name} : {exc}")
    if n:
        print(f"[Blender build] {n} modèles royalty-free déchiffrés temporairement")
    cmd = [blender_bin(), "-b", "--factory-startup", "--python-exit-code", "1",
           "--python", str(base / "agents" / "blender" / "build_scene.py")]
    print("[Blender build]", " ".join(cmd), flush=True)
    try:
        r = subprocess.run(cmd, cwd=str(base), env={**os.environ, "NOURY_SECURE_DIR": str(secure)})
    finally:
        shutil.rmtree(secure, ignore_errors=True)          # never leave decrypted files behind
    blend = base / "export" / "episode.blend"
    if r.returncode or not blend.exists():
        sys.exit(f"[Blender build] failed (code {r.returncode})")
    print(f"[Blender build] OK ({blend.stat().st_size // 1024} Ko)")


if __name__ == "__main__":
    main()
