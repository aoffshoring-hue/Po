#!/usr/bin/env python3
"""Director - a NEW episode on every run, with secondary characters and locations.

Three story structures (more can be added to TEMPLATES):
  quest     Yakine & Nour follow a magic object; a companion animal joins, a mentor gives advice
  lost      a lost animal is brought back home to its owner
  festival  the village elder asks for help: the magic object must come back for the festival
Each scene lists the guests present (role, place, attitude, emotion) and up to 3 lines of dialogue.
Roles are filled from agents/cast_library.py; locations come from agents/agent_sets.py.
"""
import datetime as dt
import json
import os
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import cast_library as CL  # noqa: E402

THEMES = {
    "courage": ("le courage", "Le courage, ce n'est pas ne jamais avoir peur : c'est avancer ensemble."),
    "entraide": ("l'entraide", "Quand on s'aide les uns les autres, on va beaucoup plus loin."),
    "partage": ("le partage", "Ce qu'on partage grandit et rend tout le monde heureux."),
    "patience": ("la patience", "Les plus belles choses demandent un peu de patience."),
    "gentillesse": ("la gentillesse", "Un petit geste gentil peut illuminer toute une journée."),
    "ecoute": ("l'écoute", "Écouter son ami, c'est déjà l'aider."),
    "perseverance": ("la persévérance", "Quand c'est difficile, on essaie encore, et on finit par y arriver."),
    "confiance": ("la confiance", "Avoir confiance en son ami, ça donne des ailes."),
}
OBJECTS = {
    "seed": {"short": "la graine", "title": "La Graine Lumineuse", "f": True},
    "star": {"short": "la petite étoile", "title": "La Petite Étoile", "f": True},
    "shell": {"short": "le coquillage", "title": "Le Coquillage Chantant", "f": False},
    "lantern": {"short": "la lanterne", "title": "La Lanterne Magique", "f": True},
}
ANIMAL_DESC = {"cat": ("un petit chat", "une petite chatte"), "dog": ("un petit chien", "une petite chienne"),
               "rabbit": ("un petit lapin", "une petite lapine"), "bird": ("un petit oiseau", "une petite oiselle"),
               "owl": ("un grand hibou", "une grande chouette")}


def B(sid, env, action, emotion, camera, lines, guests=(), magic=True, bloom=True, emotions=None):
    return {"id": sid, "env": env, "action": action, "emotion": emotion, "camera": camera,
            "lines": lines, "guests": list(guests), "magic": magic, "bloom": bloom, "emotions": emotions or {}}


def G(role, slot, act, emotion):
    return {"role": role, "slot": slot, "act": act, "emotion": emotion}


TEMPLATES = {
    # ------------------------------------------------------------------ 1. magic quest
    "quest": {
        "roles": {"C": "companion", "M": "mentor"},
        "envs": {"start": ["meadow", "garden", "forest"], "path": ["forest", "meadow", "snowy_hill"],
                 "storm": ["storm_meadow", "rocky_coast"], "cross": ["coast", "desert_oasis", "forest"],
                 "end": ["magical_clearing", "night_forest"]},
        "themes": list(THEMES), "objects": list(OBJECTS),
        "title": "Yakine et Nour : {obj_title}",
        "beats": [
            B("discovery", "start", "look_around", "wonder", "wide", [
                [("Y", "Regarde, Nour ! {Obj} brille dans l'herbe !")],
                [("Y", "Nour, viens voir ! Qu'est-ce qui brille là-bas ?"), ("N", "Oh ! C'est {obj} !")],
                [("N", "Yakine, tu as vu ? Il y a une lumière dans l'herbe !")]]),
            B("call", "start", "approach_seed", "curiosity", "tracking", [
                [("N", "On dirait que {obj} veut nous montrer le chemin !"), ("C", "{C_cry} Je peux venir avec vous ?"),
                 ("Y", "Bien sûr, {C} !")],
                [("Y", "{Pron} bouge {seul} ! On {cod} suit, Nour ?"), ("C", "{C_cry} Moi aussi, je viens !")]],
                guests=[G("C", "right", "enter", "happy")], emotions={"N": "excited"}),
            B("wind", "storm", "brace_wind", "fear", "dynamic", [
                [("Y", "Oh non, le vent souffle très fort ! Reste près de moi !"), ("C", "Au secours ! J'ai peur !")],
                [("N", "Le vent est si fort... j'ai un peu peur !"), ("Y", "Accroche-toi, Nour ! On ne lâche rien !")]],
                guests=[G("C", "left", "hide", "fear")], emotions={"Y": "determination", "N": "fear"}),
            B("help", "path", "help_friend", "care", "medium", [
                [("Y", "Ne t'inquiète pas, Nour. Donne-moi ta main, je suis là !")],
                [("Y", "Tu es tombé ? Attends, je vais t'aider à te relever !"), ("N", "Merci, Yakine !")],
                [("Y", "Ce n'est rien, Nour. On se relève et on continue ensemble.")]],
                guests=[G("C", "left", "idle", "worried")], emotions={"Y": "care", "N": "hurt"}),
            B("crossing", "cross", "run_together", "determination", "tracking", [
                [("N", "Merci Yakine ! Ensemble, on peut courir jusqu'au bout !")],
                [("N", "Allez, on y va ensemble ! Un, deux, trois !"), ("C", "{C_cry}")],
                [("Y", "Courons ! Je suis sûre qu'on va y arriver !")]],
                guests=[G("C", "follow", "follow", "happy")]),
            B("setback", "end", "protect_seed", "tension", "close", [
                [("Y", "Vite, protégeons {obj} !"), ("M", "{M_hello} Pour {cod} protéger, posez-{cod} doucement sur la terre.")],
                [("N", "Attention ! Gardons {obj} bien au chaud !"), ("M", "{M_hello} N'ayez pas peur, posez-{cod} ici.")]],
                guests=[G("M", "right", "enter", "calm"), G("C", "left", "hide", "fear")],
                emotions={"Y": "determination", "N": "tension"}),
            B("solution", "end", "plant_seed", "hope", "slow_push", [
                [("N", "Doucement... on {cod} pose ici, tous les deux.")],
                [("Y", "Si on {cod} pose ici, {pron} sera à l'abri pour toujours.")],
                [("N", "Doucement... Voilà, {pron} est bien {installe} maintenant.")]],
                guests=[G("M", "back", "idle", "calm"), G("C", "right", "idle", "happy")]),
            B("payoff", "end", "celebrate", "joy", "wide", [
                [("Y", "Waouh ! Regarde, Nour ! C'est grâce {a_theme} !"), ("M", "Bravo, les enfants ! {Moral}")],
                [("N", "On a réussi, Yakine !"), ("M", "Bravo, les enfants ! {Moral}")]],
                guests=[G("M", "right", "cheer", "happy"), G("C", "left", "cheer", "joy")]),
        ],
    },
    # ------------------------------------------------------------------ 2. lost animal
    "lost": {
        "roles": {"L": "lost", "O": "owner"},
        "envs": {"start": ["garden", "meadow", "forest"], "search": ["forest", "coast", "snowy_hill", "desert_oasis"],
                 "storm": ["storm_meadow", "rocky_coast"], "back": ["meadow", "forest"], "home": ["village", "garden"]},
        "themes": ["entraide", "gentillesse", "ecoute", "confiance"], "objects": ["seed"],
        "title": "Yakine et Nour : {L} s'est perdu{e_L}",
        "beats": [
            B("crying", "start", "look_around", "curiosity", "wide", [
                [("Y", "Écoute, Nour... Tu entends ? Quelqu'un pleure !"), ("N", "Là-bas ! C'est {L_desc} tout{e_L} seul{e_L} !")],
                [("N", "Yakine, regarde ! {L_Desc} pleure près du buisson !")]],
                guests=[G("L", "right", "sad", "sad")], magic=False),
            B("meet", "start", "meet_guest", "care", "medium", [
                [("L", "{L_cry} Je me suis perdu{e_L}... Je ne retrouve plus ma maison !"), ("Y", "Ne pleure pas, {L}. On va t'aider !")],
                [("Y", "Bonjour ! Comment tu t'appelles ?"), ("L", "Je m'appelle {L}... Je suis perdu{e_L} !"),
                 ("N", "On va t'aider à rentrer chez toi !")]],
                guests=[G("L", "right", "sad", "sad")], magic=False),
            B("tracks", "search", "approach_seed", "determination", "tracking", [
                [("N", "Regarde, des traces de pas ! Suivons-les !"), ("L", "Merci, Yakine et Nour !")],
                [("Y", "Ta maison doit être par là. Allons-y !")]],
                guests=[G("L", "follow", "follow", "hope")], magic=False),
            B("storm", "storm", "brace_wind", "fear", "dynamic", [
                [("L", "Le vent est trop fort, j'ai peur !"), ("Y", "Accroche-toi à nous, {L} !")],
                [("N", "Oh là là, quelle tempête !"), ("Y", "Restons tous ensemble !")]],
                guests=[G("L", "left", "hide", "fear")], magic=False, emotions={"Y": "determination", "N": "fear"}),
            B("fall", "search", "help_friend", "care", "medium", [
                [("Y", "Tu es tombé, Nour ? Je vais t'aider à te relever !"), ("L", "Ça va, Nour ?")],
                [("Y", "Donne-moi ta main, Nour. On continue ensemble !")]],
                guests=[G("L", "left", "idle", "worried")], magic=False, emotions={"Y": "care", "N": "hurt"}),
            B("path_home", "back", "run_together", "hope", "tracking", [
                [("L", "Je reconnais ce chemin ! Ma maison n'est plus très loin !")],
                [("L", "{L_cry} Ça sent bon la maison !"), ("N", "Plus vite, alors !")]],
                guests=[G("L", "follow", "follow", "happy")], magic=False),
            B("reunion", "home", "talk_together", "excited", "medium", [
                [("O", "{L} ! Te voilà enfin ! Je t'ai cherché{e_L} partout !"), ("L", "Ce sont Yakine et Nour qui m'ont aidé{e_L} !")],
                [("O", "Oh, {L} ! Quelle joie de te revoir !"), ("Y", "{L_Pron} était perdu{e_L}, alors on l'a ramené{e_L} !")]],
                guests=[G("O", "right", "enter", "surprised"), G("L", "near", "cheer", "joy")], magic=False),
            B("thanks", "home", "celebrate", "joy", "wide", [
                [("O", "Merci, les enfants ! {Moral}"), ("Y", "Au revoir, {L} ! À bientôt !")]],
                guests=[G("O", "right", "cheer", "happy"), G("L", "near", "cheer", "joy")], magic=False, bloom=False),
        ],
    },
    # ------------------------------------------------------------------ 3. village festival
    "festival": {
        "roles": {"E": "elder", "F": "friend"},
        "envs": {"village": ["village"], "quest": ["forest", "coast", "snowy_hill"], "storm": ["storm_meadow"],
                 "back": ["meadow", "desert_oasis"], "night": ["village_night"]},
        "themes": ["partage", "gentillesse", "confiance", "perseverance"], "objects": ["lantern", "star"],
        "title": "Yakine et Nour : La Fête du Village",
        "beats": [
            B("worry", "village", "look_around", "worried", "wide", [
                [("E", "Oh là là... Ce soir, c'est la fête du village, mais {obj} a disparu !"),
                 ("N", "Ne vous inquiétez pas, {E} !")]],
                guests=[G("E", "right", "sad", "worried"), G("F", "left", "idle", "worried")], magic=False,
                emotions={"Y": "curiosity", "N": "care"}),
            B("promise", "village", "talk_together", "determination", "medium", [
                [("Y", "On va {cod} retrouver, c'est promis !"), ("F", "Bonne chance, Yakine et Nour !")],
                [("N", "Nous allons partir à sa recherche !"), ("E", "Merci, mes petits. Soyez prudents !")]],
                guests=[G("E", "right", "talk", "calm"), G("F", "left", "idle", "happy")], magic=False),
            B("found", "quest", "approach_seed", "wonder", "tracking", [
                [("N", "Regarde ! {Obj} brille là-bas !")],
                [("Y", "Je {cod} vois ! {Pron} est là-bas !")]]),
            B("wind", "storm", "brace_wind", "fear", "dynamic", [
                [("Y", "Oh non, le vent ! Tiens bon, Nour !")],
                [("N", "Le vent est si fort... j'ai un peu peur !"), ("Y", "Reste près de moi !")]],
                emotions={"Y": "determination", "N": "fear"}),
            B("help", "quest", "help_friend", "care", "medium", [
                [("Y", "Donne-moi ta main, Nour. On y est presque !")],
                [("Y", "Ce n'est rien, Nour. On se relève et on continue ensemble.")]],
                emotions={"Y": "care", "N": "hurt"}),
            B("return", "back", "run_together", "determination", "tracking", [
                [("N", "Vite, rentrons au village avant la nuit !")],
                [("Y", "Courons ! Le village nous attend !")]]),
            B("place", "night", "plant_seed", "hope", "slow_push", [
                [("E", "Posez-{cod} ici, au milieu de la place."), ("F", "Ça brille déjà !")]],
                guests=[G("E", "back", "idle", "calm"), G("F", "right", "idle", "excited")]),
            B("party", "night", "celebrate", "joy", "wide", [
                [("E", "Merci, les enfants ! {Moral}"), ("F", "Hourra ! Vive Yakine et Nour !")]],
                guests=[G("E", "right", "cheer", "happy"), G("F", "left", "cheer", "joy")]),
        ],
    },
}


def episode_number() -> int:
    forced = os.environ.get("NOURY_EPISODE", "").strip()
    if forced.isdigit():
        return int(forced)
    now = dt.datetime.now(dt.timezone.utc)
    slot = 0 if now.hour < 10 else (1 if now.hour < 17 else 2)
    return (now.date() - dt.date(2026, 1, 1)).days * 3 + slot + 1


def cap(s: str) -> str:
    return s[:1].upper() + s[1:]


def main():
    base = Path(__file__).resolve().parent.parent
    out = base / "export"
    out.mkdir(parents=True, exist_ok=True)
    ep = episode_number()
    rnd = random.Random(ep * 7919)
    forced = os.environ.get("NOURY_TEMPLATE", "").strip()
    tkey = forced if forced in TEMPLATES else list(TEMPLATES)[ep % len(TEMPLATES)]
    tpl = TEMPLATES[tkey]

    theme_key = tpl["themes"][(ep // len(TEMPLATES)) % len(tpl["themes"])]
    theme_word, moral = THEMES[theme_key]
    obj_type = tpl["objects"][(ep // (len(TEMPLATES) * 2)) % len(tpl["objects"])]
    obj = OBJECTS[obj_type]
    fem = obj["f"]

    roles = {"Y": "Yakine", "N": "Nour"}
    used = set()
    for r, role_name in tpl["roles"].items():
        pool = [k for k in CL.by_role(role_name) if k not in used]
        roles[r] = rnd.choice(pool)
        used.add(roles[r])
    envs = {role: rnd.choice(pool) for role, pool in tpl["envs"].items()}

    fmt = {
        "obj": obj["short"], "Obj": cap(obj["short"]), "obj_title": obj["title"],
        "pron": "elle" if fem else "il", "Pron": "Elle" if fem else "Il", "cod": "la" if fem else "le",
        "seul": "toute seule" if fem else "tout seul", "installe": "installée" if fem else "installé",
        "theme": theme_word, "Theme": cap(theme_word), "Moral": moral,
        "a_theme": ("au " + theme_word[3:]) if theme_word.startswith("le ") else "à " + theme_word,
    }
    for r, key in roles.items():
        if r in ("Y", "N"):
            continue
        c = CL.get(key)
        animal = c["kind"] == "animal"
        f = c.get("f", False)
        fmt[r] = c["name"]
        fmt[f"{r}_cry"] = c.get("cry", "") if animal else ""
        fmt[f"{r}_hello"] = c.get("cry", "") if animal else "Bonjour, les enfants !"
        fmt[f"e_{r}"] = "e" if f else ""
        fmt[f"{r}_Pron"] = "Elle" if f else "Il"
        desc = ANIMAL_DESC.get(c.get("species", ""), ("un ami", "une amie"))[1 if f else 0] if animal else c["name"]
        fmt[f"{r}_desc"] = desc
        fmt[f"{r}_Desc"] = cap(desc)

    scenes = []
    for i, b in enumerate(tpl["beats"]):
        variant = rnd.choice(b["lines"])
        lines = [{"character": roles[who], "text": " ".join(text.format(**fmt).split())} for who, text in variant]
        lines = [ln for ln in lines if ln["text"]]
        guests = [{"key": roles[g["role"]], "slot": g["slot"], "act": g["act"], "emotion": g["emotion"]}
                  for g in b["guests"]]
        scenes.append({
            "id": b["id"], "start": i * 30, "end": (i + 1) * 30, "environment": envs[b["env"]],
            "action": b["action"], "emotion": b["emotion"], "camera": b["camera"],
            "magic": b["magic"], "bloom": b["bloom"],
            "emotions": {roles[k]: v for k, v in b["emotions"].items()},
            "guests": guests, "lines": lines, "dialogue": lines[0] if lines else {},
        })
    cast = sorted({g["key"] for s in scenes for g in s["guests"]})
    title = tpl["title"].format(**fmt)
    plan = {
        "episode": ep, "episode_label": f"Épisode {ep}", "template": tkey, "title": title,
        "language": "fr", "theme": theme_key, "moral": moral, "target_age": "3-7",
        "magic_object": obj_type, "magic_object_name": obj["short"],
        "fps": 24, "duration_seconds": 240,
        "characters": [{"name": "Yakine"}, {"name": "Nour"}],
        "cast": cast, "cast_names": [CL.get(k)["name"] for k in cast],
        "locations": sorted({s["environment"] for s in scenes}),
        "scenes": scenes,
    }
    (out / "director_plan.json").write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[Director] Episode {ep} [{tkey}] {title} | invités : {', '.join(plan['cast_names']) or '-'} "
          f"| lieux : {', '.join(plan['locations'])}")


if __name__ == "__main__":
    main()
