#!/usr/bin/env python3
"""Animation planner: validates the timeline and the data needed by the renderer."""
import json
from pathlib import Path

KNOWN_ACTIONS = {"look_around", "approach_seed", "brace_wind", "help_friend", "run_together",
                 "protect_seed", "plant_seed", "celebrate", "meet_guest", "talk_together"}
KNOWN_SLOTS = {"right", "left", "back", "far", "near", "follow"}
KNOWN_ACTS = {"idle", "sad", "enter", "follow", "hide", "talk", "cheer", "wave"}


def main():
    base = Path(__file__).resolve().parent.parent
    out = base / "export"
    plan = json.loads((out / "script_config.json").read_text(encoding="utf-8"))
    actors = {c["key"] for c in json.loads((out / "actors_config.json").read_text(encoding="utf-8"))["characters"]}
    sets = json.loads((out / "sets_config.json").read_text(encoding="utf-8"))["environments"]
    fps = int(plan.get("fps", 24))
    duration = int(plan.get("duration_seconds", 240))
    cursor = 0
    for s in plan["scenes"]:
        if s["start"] != cursor or s["end"] <= s["start"]:
            raise ValueError(f"Invalid scene timing: {s.get('id')}")
        if s["action"] not in KNOWN_ACTIONS:
            raise ValueError(f"Unknown action {s['action']} in {s['id']}")
        if s["environment"] not in sets:
            raise ValueError(f"Unknown location {s['environment']} in {s['id']}")
        for g in s.get("guests", []):
            if g["key"] not in actors:
                raise ValueError(f"Guest {g['key']} has no design sheet")
            if g["slot"] not in KNOWN_SLOTS or g["act"] not in KNOWN_ACTS:
                raise ValueError(f"Guest {g['key']} in {s['id']}: unknown slot/act {g['slot']}/{g['act']}")
        cursor = s["end"]
    if cursor != duration:
        raise ValueError(f"Timeline ends at {cursor}s, expected {duration}s")
    for f in ("actors_config.json", "expression_config.json", "lipsync.json", "sets_config.json"):
        if not (out / f).exists():
            raise FileNotFoundError(f"export/{f} missing")
    data = {"fps": fps, "duration_seconds": duration, "total_frames": fps * duration}
    (out / "animation_config.json").write_text(json.dumps(data, indent=2), encoding="utf-8")
    print(f"[Animation] OK : {len(plan['scenes'])} scènes, {fps * duration} images, {len(actors)} personnages")


if __name__ == "__main__":
    main()
