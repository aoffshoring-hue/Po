"""Licence policy of the Noury factory (shared by agent_assets.py and tools/check_licences.py).

Every licence text found on a site (slug, name or URL) is normalised to one code:
  CC0         public domain / CC0                         always allowed
  CC-BY       attribution                                  allowed if policy.attribution (credited automatically)
  CC-BY-SA    attribution + share-alike                    allowed if policy.share_alike
  RESTRICTED  free to use in videos, NOT redistributable   allowed if policy.restricted AND files kept encrypted
              (BlendKit Royalty Free, Quaternius QAL, Fab Standard, CGTrader Royalty Free)
  NC / ND     non-commercial / no derivatives               ALWAYS refused (a monetised channel is commercial,
                                                             an animation modifies / adapts the model)
  None        unknown                                       ALWAYS refused
"""
import json
import os
import re
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
CONFIG_PATH = BASE / "config" / "asset_sources.json"

RESTRICTED_NAMES = ("royalty_free", "royalty free", "royaltyfree", "qal", "quaternius asset license",
                    "fab standard", "standard license")


def load_config():
    try:
        return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def policy(cfg=None):
    lic = (cfg if cfg is not None else load_config()).get("licences", {})
    return {
        "attribution": bool(lic.get("attribution", False)) or os.environ.get("NOURY_ALLOW_CCBY") == "1",
        "share_alike": bool(lic.get("share_alike", False)),
        "restricted": bool(lic.get("restricted", True)) and bool(os.environ.get("NOURY_ARTIFACT_KEY", "").strip()),
    }


def normalise(text):
    """Licence slug / name / URL -> CC0 | CC-BY | CC-BY-SA | NC | ND | RESTRICTED | None."""
    if text is None:
        return None
    t = str(text).strip().lower()
    if not t:
        return None
    if any(n in t for n in RESTRICTED_NAMES):
        return "RESTRICTED"
    if t in ("cc_zero", "cc0", "pd", "public domain") or "publicdomain" in t or "public domain" in t \
            or "creative commons 0" in t or re.search(r"\bcc0\b", t):
        return "CC0"
    tokens = set(re.split(r"[^a-z0-9]+", t))
    if "nc" in tokens or "noncommercial" in tokens or "non" in tokens and "commercial" in tokens:
        return "NC"
    if "nd" in tokens or "noderivatives" in tokens or "noderivs" in tokens:
        return "ND"
    if "sa" in tokens or "sharealike" in tokens or ("share" in tokens and "alike" in tokens):
        return "CC-BY-SA"
    if "by" in tokens or "attribution" in tokens or t.startswith("cc-by") or t.startswith("cc by"):
        return "CC-BY"
    if "sampling" in tokens:                       # old Freesound "Sampling+": no commercial redistribution
        return "NC"
    return None


def allowed(code, pol=None):
    pol = pol or policy()
    if code == "CC0":
        return True
    if code == "CC-BY":
        return pol["attribution"]
    if code == "CC-BY-SA":
        return pol["share_alike"]
    if code == "RESTRICTED":
        return pol["restricted"]
    return False


def check(text, pol=None):
    """Returns the normalised code if this licence may be used, else None."""
    code = normalise(text)
    return code if code and allowed(code, pol) else None


def needs_credit(code):
    return code in ("CC-BY", "CC-BY-SA")


def needs_encryption(code):
    return code == "RESTRICTED"
