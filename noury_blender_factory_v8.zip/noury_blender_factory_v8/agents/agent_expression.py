#!/usr/bin/env python3
"""Expression engine: emotion presets + emotion timeline for every character."""
import json
from pathlib import Path

#            eye_open brow_y  brow_tilt smile mouth_open head_tilt
PRESETS = {
    "neutral":       (1.00, 0.000, 0.00, 0.30, 0.00, 0.00),
    "calm":          (0.92, 0.005, 0.10, 0.40, 0.00, 0.05),
    "happy":         (0.90, 0.020, 0.10, 0.80, 0.15, 0.08),
    "wonder":        (1.18, 0.035, 0.25, 0.45, 0.30, 0.08),
    "curiosity":     (1.08, 0.022, -0.10, 0.35, 0.06, 0.14),
    "excited":       (1.12, 0.030, 0.05, 0.90, 0.40, 0.06),
    "surprised":     (1.25, 0.040, 0.20, 0.20, 0.55, 0.00),
    "fear":          (1.22, 0.032, 0.95, -0.55, 0.30, -0.06),
    "worried":       (1.00, 0.015, 0.75, -0.40, 0.06, 0.07),
    "sad":           (0.78, 0.012, 0.80, -0.65, 0.00, 0.10),
    "hurt":          (0.80, 0.010, 0.85, -0.60, 0.10, 0.12),
    "care":          (0.92, 0.010, 0.50, 0.35, 0.00, 0.16),
    "determination": (0.86, -0.016, -0.75, 0.15, 0.00, 0.00),
    "tension":       (1.08, 0.000, 0.55, -0.45, 0.14, 0.00),
    "hope":          (1.02, 0.022, 0.35, 0.60, 0.08, 0.10),
    "joy":           (0.75, 0.030, 0.10, 1.00, 0.45, 0.10),
}
KEYS = ("eye_open", "brow_y", "brow_tilt", "smile", "mouth_open", "head_tilt")


def main():
    base = Path(__file__).resolve().parent.parent
    out = base / "export"
    script = json.loads((out / "script_config.json").read_text(encoding="utf-8"))
    timeline = []
    for s in script["scenes"]:
        item = {"start": s["start"], "end": s["end"]}
        for hero in ("Yakine", "Nour"):
            emo = s.get("emotions", {}).get(hero, s.get("emotion", "neutral"))
            item[hero] = emo if emo in PRESETS else "neutral"
        for g in s.get("guests", []):
            emo = g.get("emotion", s.get("emotion", "neutral"))
            item[g["key"]] = emo if emo in PRESETS else "neutral"
        timeline.append(item)
    presets = {k: dict(zip(KEYS, v)) for k, v in PRESETS.items()}
    (out / "expression_config.json").write_text(
        json.dumps({"presets": presets, "timeline": timeline}, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[Expression] {len(timeline)} scènes, {len(presets)} expressions")


if __name__ == "__main__":
    main()
