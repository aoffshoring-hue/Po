#!/usr/bin/env python3
"""Quality control: blocks publication if the video is broken."""
import json
import os
import subprocess
import sys
from pathlib import Path

from PIL import Image, ImageStat


def probe(video: Path) -> dict:
    r = subprocess.run(["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", str(video)],
                       capture_output=True, text=True, check=True)
    return json.loads(r.stdout)


def main():
    base = Path(__file__).resolve().parent.parent
    out = base / "export"
    cfg = json.loads((out / "animation_config.json").read_text(encoding="utf-8"))
    w, h = (1280, 720) if os.environ.get("NOURY_QUALITY") == "preview" else (1920, 1080)
    video = out / "FINAL_VIDEO.mp4"
    errors = []
    if not video.exists() or video.stat().st_size < 1_000_000:
        errors.append("video missing or too small")
    else:
        info = probe(video)
        v = [s for s in info["streams"] if s["codec_type"] == "video"]
        a = [s for s in info["streams"] if s["codec_type"] == "audio"]
        dur = float(info["format"].get("duration", 0))
        if not v or int(v[0]["width"]) != w or int(v[0]["height"]) != h:
            errors.append(f"bad resolution (expected {w}x{h})")
        if not a:
            errors.append("no audio track")
        if abs(dur - cfg["duration_seconds"]) > 1.5:
            errors.append(f"bad duration {dur:.1f}s")
        for k in range(1, 13):
            ts = cfg["duration_seconds"] * k / 13.0
            raw = subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{ts:.2f}", "-i", str(video), "-frames:v", "1",
                                  "-vf", "scale=320:180,format=gray", "-f", "rawvideo", "-"],
                                 capture_output=True).stdout
            if len(raw) < 320 * 180:
                errors.append(f"cannot read frame at {ts:.0f}s")
                continue
            st = ImageStat.Stat(Image.frombytes("L", (320, 180), raw[:320 * 180]))
            if st.mean[0] < 18 or st.stddev[0] < 8:     # night scenes are darker
                errors.append(f"image at {ts:.0f}s too dark or empty (mean={st.mean[0]:.0f}, std={st.stddev[0]:.0f})")
    report = {"passed": not errors, "errors": errors}
    (out / "qc_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    if errors:
        print("[QC] ÉCHEC - publication bloquée :", *errors, sep="\n  - ")
        sys.exit(1)
    print("[QC] OK - vidéo validée")


if __name__ == "__main__":
    main()
