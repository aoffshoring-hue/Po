"""Noury cast: main heroes + recurring secondary characters.

To add a character: add an entry to CAST (key without spaces). It is then available to the
story templates in agent_director.py (roles) and is built automatically in Blender:
  kind "human"  -> procedural human (same face engine as the heroes), or the artist's file
                   assets/characters/<key lowercase>.blend if it exists
  kind "animal" -> procedural animal; species: cat, dog, rabbit, bird, owl
Voices: Azure neural voice + pitch / rate (%), gtts_shift used by the free fallback voice.
"""

HEROES = {
    "Yakine": {
        "key": "Yakine", "name": "Yakine", "kind": "hero", "f": True,
        "design": {
            "outfit_color": [0.93, 0.33, 0.60], "accent_color": [1.00, 0.80, 0.25],
            "pants_color": [0.55, 0.30, 0.70], "shoe_color": [1.00, 0.95, 0.90],
            "skin_color": [0.97, 0.76, 0.62], "hair_color": [0.24, 0.12, 0.07],
            "iris_color": [0.45, 0.27, 0.12], "lip_color": [0.70, 0.28, 0.32],
            "cheek_color": [1.00, 0.58, 0.60], "hair_style": "side_buns", "skirt": True, "height": 0.97,
        },
        "voice": {"azure": "fr-FR-EloiseNeural", "pitch": 0, "rate": 0, "gtts_shift": 1.13},
    },
    "Nour": {
        "key": "Nour", "name": "Nour", "kind": "hero", "f": False,
        "design": {
            "outfit_color": [0.16, 0.48, 0.92], "accent_color": [1.00, 0.76, 0.20],
            "pants_color": [0.20, 0.26, 0.45], "shoe_color": [1.00, 0.78, 0.25],
            "skin_color": [0.80, 0.56, 0.40], "hair_color": [0.13, 0.08, 0.05],
            "iris_color": [0.30, 0.18, 0.08], "lip_color": [0.55, 0.27, 0.25],
            "cheek_color": [0.95, 0.50, 0.45], "hair_style": "curly", "skirt": False, "height": 1.0,
        },
        "voice": {"azure": "fr-FR-HenriNeural", "pitch": 22, "rate": 0, "gtts_shift": 0.95},
    },
}

CAST = {
    # ------------------------------------------------------------ humans
    "Zahra": {
        "key": "Zahra", "name": "Mamie Zahra", "kind": "human", "f": True, "roles": ["elder", "owner", "mentor"],
        "design": {
            "outfit_color": [0.18, 0.52, 0.42], "accent_color": [0.95, 0.75, 0.22],
            "pants_color": [0.18, 0.52, 0.42], "shoe_color": [0.85, 0.30, 0.25],
            "skin_color": [0.86, 0.64, 0.48], "hair_color": [0.78, 0.76, 0.74],
            "iris_color": [0.35, 0.22, 0.12], "lip_color": [0.62, 0.32, 0.32], "cheek_color": [0.95, 0.55, 0.50],
            "hair_style": "headscarf", "scarf_color": [0.86, 0.30, 0.42], "glasses": True,
            "skirt": True, "adult": True, "height": 1.22,
        },
        "voice": {"azure": "fr-FR-DeniseNeural", "pitch": -6, "rate": -10, "gtts_shift": 0.97},
    },
    "Ali": {
        "key": "Ali", "name": "Papi Ali", "kind": "human", "f": False, "roles": ["elder", "owner", "mentor"],
        "design": {
            "outfit_color": [0.86, 0.79, 0.64], "accent_color": [0.62, 0.36, 0.20],
            "pants_color": [0.86, 0.79, 0.64], "shoe_color": [0.95, 0.82, 0.30],
            "skin_color": [0.78, 0.55, 0.40], "hair_color": [0.82, 0.81, 0.79],
            "iris_color": [0.30, 0.20, 0.10], "lip_color": [0.55, 0.30, 0.28], "cheek_color": [0.90, 0.50, 0.42],
            "hair_style": "cap", "cap_color": [0.96, 0.95, 0.92], "beard": True,
            "skirt": True, "adult": True, "height": 1.3,
        },
        "voice": {"azure": "fr-FR-HenriNeural", "pitch": -10, "rate": -10, "gtts_shift": 0.88},
    },
    "Lina": {
        "key": "Lina", "name": "Lina", "kind": "human", "f": True, "roles": ["friend", "owner"],
        "design": {
            "outfit_color": [1.00, 0.78, 0.20], "accent_color": [0.30, 0.70, 0.90],
            "pants_color": [0.30, 0.70, 0.90], "shoe_color": [0.90, 0.30, 0.40],
            "skin_color": [0.92, 0.70, 0.54], "hair_color": [0.38, 0.20, 0.10],
            "iris_color": [0.25, 0.40, 0.20], "lip_color": [0.70, 0.30, 0.32], "cheek_color": [1.00, 0.58, 0.58],
            "hair_style": "ponytail", "skirt": True, "height": 0.95,
        },
        "voice": {"azure": "fr-FR-EloiseNeural", "pitch": 8, "rate": 4, "gtts_shift": 1.2},
    },
    # ------------------------------------------------------------ animals
    "Mimi": {
        "key": "Mimi", "name": "Mimi", "kind": "animal", "species": "cat", "f": True,
        "roles": ["lost", "companion"], "cry": "Miaou !", "sound": "meow",
        "design": {"fur": [0.96, 0.60, 0.24], "belly": [1.0, 0.93, 0.82], "iris": [0.35, 0.72, 0.30],
                   "nose": [0.95, 0.50, 0.55], "size": 1.0},
        "voice": {"azure": "fr-FR-EloiseNeural", "pitch": 30, "rate": 6, "gtts_shift": 1.35},
    },
    "Rocky": {
        "key": "Rocky", "name": "Rocky", "kind": "animal", "species": "dog", "f": False,
        "roles": ["lost", "companion"], "cry": "Ouaf ouaf !", "sound": "woof",
        "design": {"fur": [0.62, 0.40, 0.22], "belly": [0.98, 0.90, 0.78], "iris": [0.35, 0.22, 0.10],
                   "nose": [0.08, 0.06, 0.06], "size": 1.15},
        "voice": {"azure": "fr-FR-HenriNeural", "pitch": 28, "rate": 8, "gtts_shift": 1.15},
    },
    "Pompon": {
        "key": "Pompon", "name": "Pompon", "kind": "animal", "species": "rabbit", "f": False,
        "roles": ["lost", "companion"], "cry": "Hop hop !", "sound": None,
        "design": {"fur": [0.95, 0.95, 0.96], "belly": [1.0, 0.86, 0.88], "iris": [0.45, 0.25, 0.15],
                   "nose": [0.95, 0.55, 0.62], "size": 1.0},
        "voice": {"azure": "fr-FR-EloiseNeural", "pitch": 22, "rate": 10, "gtts_shift": 1.3},
    },
    "Piou": {
        "key": "Piou", "name": "Piou", "kind": "animal", "species": "bird", "f": False,
        "roles": ["companion"], "cry": "Piou piou !", "sound": "chirp",
        "design": {"fur": [0.30, 0.65, 0.95], "belly": [1.0, 0.85, 0.30], "iris": [0.10, 0.08, 0.08],
                   "nose": [1.0, 0.55, 0.15], "size": 1.0},
        "voice": {"azure": "fr-FR-EloiseNeural", "pitch": 45, "rate": 12, "gtts_shift": 1.5},
    },
    "Hibou": {
        "key": "Hibou", "name": "Grand Hibou", "kind": "animal", "species": "owl", "f": False,
        "roles": ["mentor"], "cry": "Hou hou !", "sound": "hoot",
        "design": {"fur": [0.55, 0.40, 0.28], "belly": [0.92, 0.82, 0.65], "iris": [1.0, 0.75, 0.15],
                   "nose": [0.95, 0.70, 0.25], "size": 1.2},
        "voice": {"azure": "fr-FR-HenriNeural", "pitch": -8, "rate": -12, "gtts_shift": 0.85},
    },
}

ALL = {**HEROES, **CAST}


def get(key):
    return ALL[key]


def by_role(role):
    return [k for k, v in CAST.items() if role in v.get("roles", [])]
