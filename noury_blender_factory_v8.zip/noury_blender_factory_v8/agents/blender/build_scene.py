"""Builds the complete Noury episode scene in Blender and saves export/episode.blend.

Run:  blender -b --factory-startup --python agents/blender/build_scene.py

Contents: every location family (meadow, coast, village, garden, oasis, snow, night), the heroes,
the guests of the episode (humans and animals), the magic object, lights and camera.
Uses the asset library (assets/library/library.json, see agents/agent_assets.py) when available:
  sky HDRIs per mood, photo textures (grass, sand, rock, snow, plaster, wood, soil, tiles, pebbles),
  stylised 3D models (trees, pines, palms, bushes, mushrooms, rocks, houses, village props, flowers, boats,
  snowmen) from Poly Pizza, Sketchfab and BlendKit. Without it, everything is procedural.
Artist characters in assets/characters/<key>.blend replace the procedural ones automatically.
All images are packed: the render machines only need episode.blend.
"""
import json
import math
import os
import random
import sys
from pathlib import Path

import bmesh
import bpy
from mathutils import Matrix, Vector

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import noury_anim as NA  # noqa: E402

BASE = HERE.parent.parent
EXPORT = BASE / "export"
rng = random.Random(20261015)
_lib_path = BASE / "assets" / "library" / "library.json"
LIB = json.loads(_lib_path.read_text(encoding="utf-8")) if _lib_path.exists() else {}
USE_MODELS = os.environ.get("NOURY_MODELS", "1") == "1"


def asset_path(rel):
    if not rel:
        return None
    p = BASE / rel
    return str(p) if p.exists() else None


def tex(kind):
    t = LIB.get("textures", {}).get(kind)
    return t if t and asset_path(t.get("diff")) else None


SECURE_DIR = Path(os.environ.get("NOURY_SECURE_DIR", str(EXPORT / "_secure")))


def model_file(m):
    """Real file of a library model (royalty-free BlendKit files are decrypted by agent_blender_build.py)."""
    if m.get("encrypted"):
        p = SECURE_DIR / Path(m["path"]).name.replace(".enc", "")
        return str(p) if p.exists() else None
    return asset_path(m.get("path"))


def models(family):
    return [m for m in LIB.get("models", {}).get(family, []) if model_file(m)] if USE_MODELS else []


# ================================================================== helpers
def coll(name, parent=None):
    c = bpy.data.collections.new(name)
    (parent or bpy.context.scene.collection).children.link(c)
    return c


def set_in(node, names, value):
    for n in names:
        if n in node.inputs:
            try:
                node.inputs[n].default_value = value
                return
            except (TypeError, ValueError):
                pass


def material(name, color, rough=0.5, sss=0.0, coat=0.0, sheen=0.0, emit=0.0, emit_color=None):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    b = m.node_tree.nodes["Principled BSDF"]
    set_in(b, ["Base Color"], tuple(color) + (1.0,))
    set_in(b, ["Roughness"], rough)
    if sss > 0:
        set_in(b, ["Subsurface Weight", "Subsurface"], sss)
        set_in(b, ["Subsurface Radius"], (1.0, 0.45, 0.3))
        set_in(b, ["Subsurface Scale"], 0.04)
    if coat > 0:
        set_in(b, ["Coat Weight", "Clearcoat"], coat)
    if sheen > 0:
        set_in(b, ["Sheen Weight", "Sheen"], sheen)
    if emit > 0:
        set_in(b, ["Emission Color", "Emission"], tuple(emit_color or color) + (1.0,))
        set_in(b, ["Emission Strength"], emit)
    m.diffuse_color = tuple(color) + (1.0,)
    return m


def glow_material(name, color, strength, alpha=1.0):
    """Additive glow (transparent + emission) for halos, sparkles, fireflies."""
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    em = nt.nodes.new("ShaderNodeEmission")
    em.inputs[0].default_value = tuple(color) + (1.0,)
    em.inputs[1].default_value = strength * alpha
    tr = nt.nodes.new("ShaderNodeBsdfTransparent")
    ad = nt.nodes.new("ShaderNodeAddShader")
    nt.links.new(tr.outputs[0], ad.inputs[0])
    nt.links.new(em.outputs[0], ad.inputs[1])
    nt.links.new(ad.outputs[0], out.inputs[0])
    for attr, val in (("blend_method", "BLEND"), ("surface_render_method", "BLENDED"), ("shadow_method", "NONE")):
        try:
            setattr(m, attr, val)
        except (AttributeError, TypeError):
            pass
    return m


def add_detail(m, t, tex_scale=0.5, amount=0.55, bump=0.6, coords="Object"):
    """Adds a photo texture to a material WITHOUT losing its cartoon colour: the photo luminance
    multiplies the colour (detail), roughness and normal maps add the relief."""
    if not t:
        return m
    nt = m.node_tree
    bsdf = nt.nodes["Principled BSDF"]
    tc = nt.nodes.new("ShaderNodeTexCoord")
    mp = nt.nodes.new("ShaderNodeMapping")
    mp.inputs["Scale"].default_value = (tex_scale, tex_scale, tex_scale)
    nt.links.new(tc.outputs[coords], mp.inputs["Vector"])

    def img(rel_path, non_color=False):
        path = asset_path(rel_path)
        if not path:
            return None
        n = nt.nodes.new("ShaderNodeTexImage")
        n.image = bpy.data.images.load(path, check_existing=True)
        if non_color:
            n.image.colorspace_settings.name = "Non-Color"
        n.projection = "BOX"
        n.projection_blend = 0.3
        nt.links.new(mp.outputs["Vector"], n.inputs["Vector"])
        return n

    base_link = next((lk for lk in nt.links if lk.to_node == bsdf and lk.to_socket.name == "Base Color"), None)
    d = img(t.get("diff"))
    if d:
        if base_link is not None:
            src = base_link.from_socket
            nt.links.remove(base_link)
        else:
            rgb = nt.nodes.new("ShaderNodeRGB")
            rgb.outputs[0].default_value = tuple(bsdf.inputs["Base Color"].default_value)
            src = rgb.outputs[0]
        bw = nt.nodes.new("ShaderNodeRGBToBW")
        nt.links.new(d.outputs["Color"], bw.inputs[0])
        boost = nt.nodes.new("ShaderNodeMath")
        boost.operation = "MULTIPLY"
        boost.inputs[1].default_value = 2.2
        nt.links.new(bw.outputs[0], boost.inputs[0])
        det = nt.nodes.new("ShaderNodeMixRGB")
        det.blend_type = "MULTIPLY"
        det.inputs["Fac"].default_value = amount
        nt.links.new(src, det.inputs["Color1"])
        nt.links.new(boost.outputs[0], det.inputs["Color2"])
        nt.links.new(det.outputs[0], bsdf.inputs["Base Color"])
    r = img(t.get("rough"), True)
    if r:
        nt.links.new(r.outputs["Color"], bsdf.inputs["Roughness"])
    nm = img(t.get("nor"), True)
    if nm:
        nmap = nt.nodes.new("ShaderNodeNormalMap")
        nmap.inputs["Strength"].default_value = bump
        nt.links.new(nm.outputs["Color"], nmap.inputs["Color"])
        nt.links.new(nmap.outputs["Normal"], bsdf.inputs["Normal"])
    return m


def noise_ground_material(name, a, b, rough=0.95, scale=3.0, t=None, tex_scale=0.5):
    """Stylised two-colour ground (ColA / ColB are animated per location) + optional photo detail."""
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    bsdf = nt.nodes["Principled BSDF"]
    set_in(bsdf, ["Roughness"], rough)
    tc = nt.nodes.new("ShaderNodeTexCoord")
    nz = nt.nodes.new("ShaderNodeTexNoise")
    nz.inputs["Scale"].default_value = scale
    nz.inputs["Detail"].default_value = 6.0
    ca = nt.nodes.new("ShaderNodeRGB")
    ca.name = "ColA"
    ca.outputs[0].default_value = tuple(a) + (1.0,)
    cb = nt.nodes.new("ShaderNodeRGB")
    cb.name = "ColB"
    cb.outputs[0].default_value = tuple(b) + (1.0,)
    mx = nt.nodes.new("ShaderNodeMixRGB")
    nt.links.new(tc.outputs["Object"], nz.inputs["Vector"])
    nt.links.new(nz.outputs["Fac"], mx.inputs["Fac"])
    nt.links.new(ca.outputs[0], mx.inputs["Color1"])
    nt.links.new(cb.outputs[0], mx.inputs["Color2"])
    nt.links.new(mx.outputs[0], bsdf.inputs["Base Color"])
    return add_detail(m, t, tex_scale)


def smooth_mesh(me):
    me.polygons.foreach_set("use_smooth", [True] * len(me.polygons))


def _xform(loc, rot, scl):
    return Matrix.Translation(loc) @ Matrix.Rotation(rot[2], 4, "Z") @ Matrix.Rotation(rot[1], 4, "Y") \
        @ Matrix.Rotation(rot[0], 4, "X") @ Matrix.Diagonal(Vector(scl).to_4d())


def bm_sphere(bm, r, loc=(0, 0, 0), scl=(1, 1, 1), rot=(0, 0, 0), seg=32, mat_index=0, hemi=False):
    res = bmesh.ops.create_uvsphere(bm, u_segments=seg, v_segments=max(8, seg // 2), radius=r)
    verts = res["verts"]
    if hemi:
        kill = [v for v in verts if v.co.z < -1e-5]
        bmesh.ops.delete(bm, geom=kill, context="VERTS")
        verts = [v for v in verts if v.is_valid]
    bmesh.ops.transform(bm, matrix=_xform(loc, rot, scl), verts=verts)
    for f in {f for v in verts for f in v.link_faces}:
        f.material_index = mat_index
    return verts


def bm_cone(bm, r_bottom, r_top, depth, loc=(0, 0, 0), seg=24, mat_index=0, rot=(0, 0, 0)):
    res = bmesh.ops.create_cone(bm, cap_ends=True, cap_tris=False, segments=seg,
                                radius1=r_bottom, radius2=r_top, depth=depth)
    bmesh.ops.transform(bm, matrix=_xform(loc, rot, (1, 1, 1)), verts=res["verts"])
    for f in {f for v in res["verts"] for f in v.link_faces}:
        f.material_index = mat_index


def bm_box(bm, size, loc=(0, 0, 0), rot=(0, 0, 0), mat_index=0, bevel=0.0):
    res = bmesh.ops.create_cube(bm, size=1.0)
    verts = res["verts"]
    bmesh.ops.transform(bm, matrix=_xform(loc, rot, size), verts=verts)
    faces = {f for v in verts for f in v.link_faces}
    for f in faces:
        f.material_index = mat_index
    if bevel > 0:
        edges = list({e for f in faces for e in f.edges})
        bmesh.ops.bevel(bm, geom=edges, offset=bevel, segments=2, affect="EDGES")


MAIN = None
TARGET = None          # collection used when none is given (switched while building a guest)


def mesh_obj(name, build, mats, parent=None, loc=(0, 0, 0), rot=(0, 0, 0), scl=(1, 1, 1),
             collection=None, shadow=True, smooth=True):
    me = bpy.data.meshes.new(name)
    bm = bmesh.new()
    build(bm)
    bm.to_mesh(me)
    bm.free()
    if smooth:
        smooth_mesh(me)
    for m in mats:
        me.materials.append(m)
    ob = bpy.data.objects.new(name, me)
    (collection or TARGET).objects.link(ob)
    ob.parent = parent
    ob.location, ob.rotation_euler, ob.scale = loc, rot, scl
    if not shadow:
        try:
            ob.visible_shadow = False
        except AttributeError:
            pass
    return ob


def sphere(name, r, mat, parent=None, loc=(0, 0, 0), scl=(1, 1, 1), rot=(0, 0, 0), seg=32, hemi=False,
           collection=None, shadow=True):
    return mesh_obj(name, lambda bm: bm_sphere(bm, r, seg=seg, hemi=hemi), [mat], parent, loc, rot, scl,
                    collection, shadow)


def cone(name, rb, rt, depth, mat, parent=None, loc=(0, 0, 0), rot=(0, 0, 0), seg=24, collection=None):
    return mesh_obj(name, lambda bm: bm_cone(bm, rb, rt, depth, seg=seg), [mat], parent, loc, rot,
                    collection=collection)


def empty(name, parent=None, loc=(0, 0, 0), collection=None):
    ob = bpy.data.objects.new(name, None)
    (collection or TARGET).objects.link(ob)
    ob.parent = parent
    ob.location = loc
    ob.empty_display_size = 0.1
    return ob


def ring(name, radius, thickness, mat, parent, loc, rot=(0, 0, 0)):
    """Thin torus made with a beveled Bezier circle (glasses)."""
    cu = bpy.data.curves.new(name, "CURVE")
    cu.dimensions = "3D"
    cu.bevel_depth = thickness
    cu.bevel_resolution = 3
    sp = cu.splines.new("BEZIER")
    sp.bezier_points.add(3)
    k = 0.5523 * radius
    for i, (x, y) in enumerate([(radius, 0), (0, radius), (-radius, 0), (0, -radius)]):
        bp = sp.bezier_points[i]
        bp.co = (x, 0, y)
        tx, ty = -y / radius * k, x / radius * k
        bp.handle_left = (x - tx, 0, y - ty)
        bp.handle_right = (x + tx, 0, y + ty)
    sp.use_cyclic_u = True
    cu.materials.append(mat)
    ob = bpy.data.objects.new(name, cu)
    TARGET.objects.link(ob)
    ob.parent = parent
    ob.location, ob.rotation_euler = loc, rot
    return ob


# ---------------------------------------------------------------- library 3D models (glTF / .blend)
_PROTOS = {}
USED_MODELS = []          # written to export/used_assets.json -> exact credits in the YouTube description


def _import_blend(path):
    """Appends every collection (or every object) of a .blend asset (BlendKit, manual). Returns the new objects."""
    with bpy.data.libraries.load(path, link=False) as (src, dst):
        if src.collections:
            dst.collections = list(src.collections)
        else:
            dst.objects = list(src.objects)
    objs = []
    for c in dst.collections if dst.collections else []:
        if c is not None:
            objs += [o for o in c.all_objects if o not in objs]
    for o in (dst.objects if not dst.collections else []):
        if o is not None:
            objs.append(o)
    tmp = bpy.data.collections.new("_import_tmp")
    bpy.context.scene.collection.children.link(tmp)
    for o in objs:
        if not o.users_collection:
            tmp.objects.link(o)
    for c in dst.collections if dst.collections else []:
        if c is not None:
            try:
                tmp.children.link(c)        # makes their objects evaluable (matrix_world)
            except RuntimeError:
                pass
    bpy.context.view_layer.update()
    bpy.context.scene.collection.children.unlink(tmp)
    return objs


def model_proto(m):
    """Imports a library model once (.glb / .gltf / .blend / .fbx / .obj) into an unlinked collection;
    returns (collection, height) or None."""
    key = m["path"]
    if key in _PROTOS:
        return _PROTOS[key]
    try:
        path = model_file(m)
        fmt = (m.get("format") or Path(path).suffix.lstrip(".")).lower()
        before = set(bpy.data.objects)
        if fmt == "blend":
            new = _import_blend(path)
        elif fmt in ("fbx", "obj"):
            if fmt == "fbx":
                bpy.ops.import_scene.fbx(filepath=path)
            elif hasattr(bpy.ops.wm, "obj_import"):
                bpy.ops.wm.obj_import(filepath=path)
            else:
                bpy.ops.import_scene.obj(filepath=path)
            new = [o for o in bpy.data.objects if o not in before]
            bpy.context.view_layer.update()
            for o in new:                      # FBX / OBJ often arrive 100x too big or Y-up: size is normalised
                if o.type == "ARMATURE":       # later anyway; armatures are not needed for static props
                    o.hide_render = True
        else:
            try:
                import addon_utils
                addon_utils.enable("io_scene_gltf2", default_set=True)
            except Exception:
                pass
            bpy.ops.import_scene.gltf(filepath=path)
            new = [o for o in bpy.data.objects if o not in before]
            bpy.context.view_layer.update()
        meshes = [o for o in new if o.type == "MESH"]
        if not meshes:
            raise ValueError("no mesh")
        pts = [o.matrix_world @ Vector(c) for o in meshes for c in o.bound_box]
        lo = Vector((min(p.x for p in pts), min(p.y for p in pts), min(p.z for p in pts)))
        hi = Vector((max(p.x for p in pts), max(p.y for p in pts), max(p.z for p in pts)))
        h = hi.z - lo.z
        if h < 1e-3 or max(hi.x - lo.x, hi.y - lo.y) > 8 * h:
            raise ValueError("flat or odd proportions")
        col = bpy.data.collections.new(f"proto_{m.get('id') or Path(key).stem}")
        for o in new:
            for c in list(o.users_collection):
                c.objects.unlink(o)
            col.objects.link(o)
            if o.animation_data:
                o.animation_data_clear()
            if o.type in ("LIGHT", "CAMERA"):          # asset files sometimes ship their own lights / cameras
                o.hide_render = True
        col.instance_offset = ((lo.x + hi.x) / 2, (lo.y + hi.y) / 2, lo.z)
        _PROTOS[key] = (col, h)
        USED_MODELS.append({k: m.get(k) for k in ("id", "title", "creator", "source", "licence", "url")})
        print(f"[Blender build] modèle 3D importé : {m.get('title') or key} ({m.get('source')}, {m.get('licence')})")
    except Exception as exc:
        print(f"[Blender build] modèle ignoré {key} : {exc}")
        _PROTOS[key] = None
    return _PROTOS[key]


def place_model(name, m, loc, height, collection, rot_z=0.0):
    proto = model_proto(m)
    if not proto:
        return None
    col, h = proto
    e = bpy.data.objects.new(name, None)
    e.instance_type = "COLLECTION"
    e.instance_collection = col
    s = height / h
    e.scale = (s, s, s)
    e.location = loc
    e.rotation_euler = (0.0, 0.0, rot_z)
    collection.objects.link(e)
    return e


# ================================================================== scene setup
bpy.ops.wm.read_factory_settings(use_empty=True)
scene = bpy.context.scene
scene.name = "Noury"
MAIN = coll("Main")
TARGET = MAIN
ep = NA.Episode(EXPORT)
scene.frame_start, scene.frame_end = 1, ep.total
scene.render.fps = ep.fps

# ---------------------------------------------------------------- world: cartoon sky + real HDRI lighting
world = bpy.data.worlds.new("NouryWorld")
scene.world = world
world.use_nodes = True
wn = world.node_tree
wn.nodes.clear()
w_out = wn.nodes.new("ShaderNodeOutputWorld")
w_bg = wn.nodes.new("ShaderNodeBackground")
w_bg.name = "SkyBG"
w_tc = wn.nodes.new("ShaderNodeTexCoord")
w_sep = wn.nodes.new("ShaderNodeSeparateXYZ")
w_map = wn.nodes.new("ShaderNodeMapRange")
w_map.inputs["From Min"].default_value = -0.05
w_map.inputs["From Max"].default_value = 0.65
w_top = wn.nodes.new("ShaderNodeRGB")
w_top.name = "SkyTop"
w_top.outputs[0].default_value = (0.25, 0.5, 0.85, 1)
w_hor = wn.nodes.new("ShaderNodeRGB")
w_hor.name = "SkyHorizon"
w_hor.outputs[0].default_value = (0.75, 0.88, 0.98, 1)
w_mix = wn.nodes.new("ShaderNodeMixRGB")
wn.links.new(w_tc.outputs["Generated"], w_sep.inputs[0])
wn.links.new(w_sep.outputs["Z"], w_map.inputs["Value"])
wn.links.new(w_map.outputs[0], w_mix.inputs["Fac"])
wn.links.new(w_hor.outputs[0], w_mix.inputs["Color1"])
wn.links.new(w_top.outputs[0], w_mix.inputs["Color2"])
wn.links.new(w_mix.outputs[0], w_bg.inputs["Color"])

hdris = {m: asset_path(v.get("path")) for m, v in LIB.get("hdri", {}).items()}
hdris = {m: p for m, p in hdris.items() if p}
if "day" not in hdris and hdris:                       # any sky can light the day scenes
    hdris["day"] = next(iter(hdris.values()))
if hdris:
    h_map = wn.nodes.new("ShaderNodeMapping")
    h_map.inputs["Rotation"].default_value = (0.0, 0.0, math.radians(-32))
    wn.links.new(w_tc.outputs["Generated"], h_map.inputs["Vector"])

    def hdri_bg(mood, path):
        et = wn.nodes.new("ShaderNodeTexEnvironment")
        et.image = bpy.data.images.load(path, check_existing=True)
        wn.links.new(h_map.outputs["Vector"], et.inputs["Vector"])
        bg = wn.nodes.new("ShaderNodeBackground")
        bg.name = "HdriBG" if mood == "day" else f"HdriBG_{mood}"
        bg.inputs["Strength"].default_value = 0.8
        wn.links.new(et.outputs["Color"], bg.inputs["Color"])
        return bg.outputs[0]

    light = hdri_bg("day", hdris["day"])
    for mood in ("sunset", "storm", "night"):              # each mood switched on by noury_anim.apply_env
        if mood in hdris:
            mx = wn.nodes.new("ShaderNodeMixShader")
            mx.name = f"HdriMix_{mood}"
            mx.inputs[0].default_value = 0.0
            wn.links.new(light, mx.inputs[1])
            wn.links.new(hdri_bg(mood, hdris[mood]), mx.inputs[2])
            light = mx.outputs[0]
    lp = wn.nodes.new("ShaderNodeLightPath")
    w_ms = wn.nodes.new("ShaderNodeMixShader")
    wn.links.new(lp.outputs["Is Camera Ray"], w_ms.inputs["Fac"])
    wn.links.new(light, w_ms.inputs[1])                    # lighting and reflections: real sky
    wn.links.new(w_bg.outputs[0], w_ms.inputs[2])          # what the camera sees: cartoon sky
    wn.links.new(w_ms.outputs[0], w_out.inputs["Surface"])
    print(f"[Blender build] éclairage HDRI : {', '.join(sorted(hdris))}")
else:
    wn.links.new(w_bg.outputs[0], w_out.inputs["Surface"])


# ---------------------------------------------------------------- lights + camera
def sun_light(name, rot_deg, energy, color, angle=0.1):
    d = bpy.data.lights.new(name, "SUN")
    d.energy, d.color, d.angle = energy, color, angle
    o = bpy.data.objects.new(name, d)
    MAIN.objects.link(o)
    o.rotation_euler = tuple(math.radians(v) for v in rot_deg)
    return o


sun_light("sun", (48, 0, -32), 4.0, (1.0, 0.93, 0.8), math.radians(4))
sun_light("fill", (60, 0, 40), 0.8, (0.6, 0.75, 1.0), math.radians(20))
rim = sun_light("rim", (-55, 0, 15), 2.5, (0.85, 0.92, 1.0), math.radians(3))
try:
    rim.data.use_shadow = False
except AttributeError:
    pass

cam_data = bpy.data.cameras.new("cam")
cam_data.sensor_fit = "VERTICAL"
cam_data.sensor_height = 24.0
cam_data.clip_start, cam_data.clip_end = 0.05, 400.0
cam_data.dof.use_dof = True
cam_data.dof.aperture_blades = 7
cam = bpy.data.objects.new("cam", cam_data)
MAIN.objects.link(cam)
scene.camera = cam

# ================================================================== locations
C_MEADOW, C_COAST, C_WATER = coll("meadow_set"), coll("coast_set"), coll("water_set")
C_GRASS, C_TREES, C_PINES, C_PALMS = coll("grass_set"), coll("trees_set"), coll("pines_set"), coll("palms_set")
C_HOUSES, C_GARDEN, C_ROCKS = coll("houses_set"), coll("garden_set"), coll("rocks_set")
C_FIRE, C_SNOW, C_NIGHT = coll("fireflies_set"), coll("snow_set"), coll("night_set")

m_ground = noise_ground_material("M_ground", (0.38, 0.7, 0.33), (0.22, 0.5, 0.22), t=tex("grass"))
m_sand = noise_ground_material("M_sand", (0.92, 0.82, 0.6), (0.78, 0.66, 0.45), scale=6.0, t=tex("sand"))
m_snow_g = noise_ground_material("M_snow", (0.95, 0.97, 1.0), (0.8, 0.86, 0.95), rough=0.7, scale=4.0,
                                 t=tex("snow"), tex_scale=0.4)


def terrain(name, coast, mat, col, x0=-50, x1=50, y0=-20, y1=70, n=160):
    def build(bm):
        bmesh.ops.create_grid(bm, x_segments=n, y_segments=n, size=1.0)
        for v in bm.verts:
            x = x0 + (v.co.x + 1.0) * 0.5 * (x1 - x0)
            y = y0 + (v.co.y + 1.0) * 0.5 * (y1 - y0)
            v.co = (x, y, NA.terrain_h(x, y, coast))
    return mesh_obj(name, build, [mat], collection=col)


terrain("terrain_meadow", False, m_ground, C_MEADOW)
terrain("terrain_coast", True, m_sand, C_COAST)
terrain("terrain_snow", False, m_snow_g, C_SNOW)
m_water = material("M_water", (0.08, 0.42, 0.7), rough=0.06, coat=0.6)
mesh_obj("water", lambda bm: bmesh.ops.create_grid(bm, x_segments=1, y_segments=1, size=1.0),
         [m_water], loc=(0, 50, -0.12), scl=(90, 40, 1), collection=C_WATER, smooth=False)


def free_spot(xr, yr, keep_x=8.5, keep_y=7.0, tries=200):
    for _ in range(tries):
        x, y = rng.uniform(*xr), rng.uniform(*yr)
        if not (abs(x) < keep_x and y < keep_y):
            return x, y
    return xr[1], yr[1]


# ---------------------------------------------------------------- grass + flowers
m_grass = material("M_grass", (0.3, 0.62, 0.22), rough=0.8, sheen=0.4)


def grass_build(bm):
    bmesh.ops.create_grid(bm, x_segments=60, y_segments=40, size=1.0)
    for v in bm.verts:
        x = v.co.x * 16.0
        y = -5.0 + (v.co.y + 1.0) * 0.5 * 14.0
        v.co = (x, y, NA.terrain_h(x, y, False) + 0.005)


grass = mesh_obj("grass_patch", grass_build, [m_ground, m_grass], collection=C_GRASS)
ps_mod = grass.modifiers.new("grass", "PARTICLE_SYSTEM")
gs = ps_mod.particle_system.settings
gs.type = "HAIR"
gs.count = 45000
gs.hair_length = 0.16
gs.use_advanced_hair = True
gs.material = 2
gs.root_radius, gs.tip_radius, gs.radius_scale = 1.0, 0.0, 0.012
gs.factor_random = 0.25
gs.brownian_factor = 0.03
ps_mod.particle_system.seed = 3

flower_protos = bpy.data.collections.new("FlowerProtos")      # not linked to the scene
m_center = material("M_flower_center", (1.0, 0.8, 0.15), rough=0.5)
for fi, pc in enumerate([(1, 1, 1), (1, 0.45, 0.65), (1, 0.85, 0.2), (0.65, 0.5, 1.0), (1, 0.55, 0.25)]):
    pm = material(f"M_petal_{fi}", pc, rough=0.55, sss=0.2, sheen=0.3)

    def fb(bm):
        bm_sphere(bm, 0.022, (0, 0, 0.012), (1, 1, 0.6), seg=12, mat_index=0)
        for k in range(6):
            a = math.tau * k / 6
            bm_sphere(bm, 0.03, (math.cos(a) * 0.035, math.sin(a) * 0.035, 0.008), (1.0, 0.55, 0.22),
                      rot=(0, 0, a), seg=10, mat_index=1)
    mesh_obj(f"flower_proto_{fi}", fb, [m_center, pm], collection=flower_protos)
fl_mod = grass.modifiers.new("flowers", "PARTICLE_SYSTEM")
fs = fl_mod.particle_system.settings
fs.type = "HAIR"
fs.count = 700
fs.hair_length = 0.2
fs.render_type = "COLLECTION"
fs.instance_collection = flower_protos
fs.use_collection_pick_random = True
fs.particle_size = 1.6
fs.size_random = 0.5
fs.use_rotations = True
fs.rotation_mode = "NOR"
fs.phase_factor_random = 2.0
fl_mod.particle_system.seed = 11

# ---------------------------------------------------------------- trees (procedural + library models)
m_trunk = add_detail(material("M_trunk", (0.42, 0.26, 0.15), rough=0.9), tex("wood"), 2.0, 0.4, 0.4)
leaf_mats = [material(f"M_leaf_{i}", c, rough=0.8, sss=0.15, sheen=0.3) for i, c in enumerate(
    [(0.16, 0.5, 0.22), (0.22, 0.58, 0.25), (0.12, 0.42, 0.2), (0.3, 0.62, 0.28)])]
tree_models = models("tree")
n_proc_trees = 30 if tree_models else 55
for i in range(55):
    x, y = free_spot((-34, 34), (-6, 32))
    s = rng.uniform(0.8, 1.5)
    z = NA.terrain_h(x, y, False) - 0.05
    if i >= n_proc_trees and place_model(f"tree_{i}", tree_models[i % len(tree_models)], (x, y, z),
                                         rng.uniform(3.2, 4.6), C_TREES, rng.uniform(0, math.tau)):
        continue
    lm = leaf_mats[rng.randrange(len(leaf_mats))]
    blobs = [(rng.uniform(0, math.tau), rng.uniform(0.75, 1.1), rng.uniform(-0.2, 0.5)) for _ in range(rng.randint(4, 6))]

    def tb(bm, blobs=blobs):
        bm_cone(bm, 0.28, 0.16, 2.0, (0, 0, 1.0), seg=12, mat_index=0)
        for a, r, dz in blobs:
            bm_sphere(bm, r, (math.cos(a) * 0.6, math.sin(a) * 0.6, 2.4 + dz), seg=20, mat_index=1)
        bm_sphere(bm, 1.05, (0, 0, 3.1), seg=20, mat_index=1)
    mesh_obj(f"tree_{i}", tb, [m_trunk, lm], loc=(x, y, z), rot=(0, 0, rng.uniform(0, math.tau)), scl=(s, s, s),
             collection=C_TREES)

# bushes and mushrooms (library only): fill the middle distance of meadows, forests, gardens, village
for fam, count, hr, yr in (("bush", 26, (0.6, 1.2), (2.5, 12)), ("mushroom", 14, (0.25, 0.45), (2.0, 6))):
    lst = models(fam)
    for i in range(count if lst else 0):
        x, y = free_spot((-14, 14), (-2, yr[1]), keep_x=7.0, keep_y=yr[0])
        place_model(f"{fam}_{i}", lst[i % len(lst)], (x, y, NA.terrain_h(x, y, False) - 0.02),
                    rng.uniform(*hr), C_TREES, rng.uniform(0, math.tau))

# pines with snowy tips (snowy hill)
m_pine = material("M_pine", (0.1, 0.36, 0.24), rough=0.85, sheen=0.3)
m_snowcap = material("M_snowcap", (0.95, 0.97, 1.0), rough=0.6, sss=0.2)
pine_models = models("pine")
n_proc_pines = 25 if pine_models else 45
for i in range(45):
    x, y = free_spot((-30, 30), (-5, 30))
    z = NA.terrain_h(x, y, False) - 0.05
    if i >= n_proc_pines and place_model(f"pine_{i}", pine_models[i % len(pine_models)], (x, y, z),
                                         rng.uniform(3.5, 5.5), C_PINES, rng.uniform(0, math.tau)):
        continue

    def pb(bm):
        bm_cone(bm, 0.18, 0.12, 0.8, (0, 0, 0.4), seg=10, mat_index=0)
        for k, (r, zz) in enumerate(((1.2, 1.3), (0.95, 2.1), (0.68, 2.8))):
            bm_cone(bm, r, 0.0, 1.3, (0, 0, zz), seg=14, mat_index=1)
            bm_cone(bm, r * 0.45, 0.0, 0.5, (0, 0, zz + 0.42), seg=14, mat_index=2)
    s = rng.uniform(0.8, 1.6)
    mesh_obj(f"pine_{i}", pb, [m_trunk, m_pine, m_snowcap], loc=(x, y, z), rot=(0, 0, rng.uniform(0, math.tau)),
             scl=(s, s, s), collection=C_PINES)

# palms (coast, oasis)
m_palm = material("M_palm_trunk", (0.62, 0.45, 0.28), rough=0.9)
m_frond = material("M_frond", (0.2, 0.58, 0.25), rough=0.7, sss=0.2, sheen=0.3)
m_coco = material("M_coco", (0.35, 0.22, 0.1), rough=0.6)
palm_models = models("palm")
n_proc_palms = 14 if palm_models else 26
for i in range(26):
    x, y = free_spot((-24, 24), (-4, 16), keep_x=6.0, keep_y=4.0)
    z = NA.terrain_h(x, y, True) - 0.05
    if i >= n_proc_palms and place_model(f"palm_{i}", palm_models[i % len(palm_models)], (x, y, z),
                                         rng.uniform(3.5, 5.0), C_PALMS, rng.uniform(0, math.tau)):
        continue
    bend = rng.uniform(-0.25, 0.25)

    def palm(bm, bend=bend):
        top = (0.0, 0.0, 0.0)
        for k in range(8):
            zz = k * 0.42
            top = (bend * (k / 8.0) ** 2 * 2.0, 0.0, zz)
            bm_sphere(bm, 0.17 - k * 0.008, (top[0], 0, zz + 0.2), (1, 1, 1.5), seg=10, mat_index=0)
        crown = (top[0], 0, top[2] + 0.45)
        for k in range(8):
            a = math.tau * k / 8
            bm_sphere(bm, 1.0, (crown[0] + math.cos(a) * 0.75, math.sin(a) * 0.75, crown[2] - 0.15),
                      (0.85, 0.2, 0.05), rot=(0, 0.45, a), seg=12, mat_index=1)
        for k in range(3):
            a = math.tau * k / 3
            bm_sphere(bm, 0.09, (crown[0] + math.cos(a) * 0.14, math.sin(a) * 0.14, crown[2] - 0.12), seg=10,
                      mat_index=2)
    s = rng.uniform(0.9, 1.4)
    mesh_obj(f"palm_{i}", palm, [m_palm, m_frond, m_coco], loc=(x, y, z), rot=(0, 0, rng.uniform(0, math.tau)),
             scl=(s, s, s), collection=C_PALMS)

# ---------------------------------------------------------------- Moroccan-style village
wall_cols = [(0.97, 0.94, 0.88), (0.93, 0.78, 0.6), (0.96, 0.7, 0.62), (0.98, 0.88, 0.7)]
door_cols = [(0.12, 0.38, 0.72), (0.15, 0.55, 0.45), (0.75, 0.2, 0.2), (0.95, 0.65, 0.15)]
m_roof = add_detail(material("M_roof_tiles", (0.1, 0.5, 0.32), rough=0.35, coat=0.6), tex("tiles"), 1.5, 0.45, 0.8)
m_trim = material("M_trim", (0.98, 0.98, 0.96), rough=0.6)
m_window = material("M_window", (0.25, 0.32, 0.45), rough=0.2, coat=0.8)
house_spots = [(-11, 9), (-6.5, 11), (6.5, 10), (11.5, 8), (-15, 13), (15, 13), (-2.5, 15), (3.5, 16), (-9, 17), (10, 18)]
for i, (hx, hy) in enumerate(house_spots):
    w, d, hgt = rng.uniform(2.2, 3.4), rng.uniform(2.0, 3.0), rng.uniform(1.8, 2.8)
    wall = add_detail(material(f"M_wall_{i}", wall_cols[i % 4], rough=0.85), tex("plaster"), 0.8, 0.35, 0.5)
    door = add_detail(material(f"M_door_{i}", door_cols[(i * 3) % 4], rough=0.45, coat=0.4), tex("wood"), 2.0, 0.3, 0.4)
    tiled = i % 3 == 0

    def house(bm, w=w, d=d, hgt=hgt, tiled=tiled):
        bm_box(bm, (w, d, hgt), (0, 0, hgt / 2), mat_index=0, bevel=0.05)
        if tiled:     # green tile pyramid roof
            bm_cone(bm, max(w, d) * 0.78, 0.0, 0.9, (0, 0, hgt + 0.45), seg=4, mat_index=2, rot=(0, 0, math.pi / 4))
        else:         # flat roof with parapet
            bm_box(bm, (w + 0.12, d + 0.12, 0.18), (0, 0, hgt + 0.09), mat_index=3)
        bm_box(bm, (0.62, 0.08, 1.05), (0, -d / 2 - 0.02, 0.53), mat_index=1)          # door
        bm_sphere(bm, 0.31, (0, -d / 2 - 0.02, 1.05), (1, 0.13, 1), seg=16, hemi=True, mat_index=1)  # arch
        for sx in (-w * 0.3, w * 0.3):
            bm_box(bm, (0.38, 0.06, 0.45), (sx, -d / 2 - 0.02, hgt * 0.62), mat_index=4)
    mesh_obj(f"house_{i}", house, [wall, door, m_roof, m_trim, m_window], loc=(hx, hy, NA.terrain_h(hx, hy, False) - 0.05),
             rot=(0, 0, rng.uniform(-0.25, 0.25)), collection=C_HOUSES)
m_stone = add_detail(material("M_fountain", (0.88, 0.86, 0.8), rough=0.8), tex("plaster"), 1.0, 0.3, 0.5)
m_zellige = material("M_zellige", (0.1, 0.45, 0.65), rough=0.2, coat=1.0)
m_pool = material("M_fountain_water", (0.25, 0.6, 0.85), rough=0.05, coat=1.0)


def fountain(bm):
    bm_cone(bm, 1.0, 1.0, 0.45, (0, 0, 0.22), seg=8, mat_index=0)
    bm_cone(bm, 1.03, 1.03, 0.12, (0, 0, 0.3), seg=8, mat_index=1)
    bm_cone(bm, 0.85, 0.85, 0.05, (0, 0, 0.42), seg=24, mat_index=2)
    bm_cone(bm, 0.12, 0.08, 0.8, (0, 0, 0.75), seg=12, mat_index=1)
    bm_sphere(bm, 0.25, (0, 0, 1.15), (1, 1, 0.35), seg=16, mat_index=0)


mesh_obj("fountain", fountain, [m_stone, m_zellige, m_pool], loc=(-4.6, 4.2, 0.0), collection=C_HOUSES)
m_lamp = glow_material("M_garland", (1.0, 0.75, 0.35), 6.0)
for i in range(16):
    x = -7.0 + i * 0.95
    sphere(f"garland_{i}", 0.07, m_lamp, loc=(x, 5.5, 2.6 - 0.35 * math.sin(math.pi * i / 15)), seg=10,
           collection=C_HOUSES, shadow=False)
if tex("pebbles"):                       # cobbled village square
    m_square = add_detail(material("M_square", (0.82, 0.74, 0.62), rough=0.9), tex("pebbles"), 0.7, 0.6, 0.9)
    mesh_obj("village_square", lambda bm: bm_cone(bm, 6.5, 6.5, 0.04, seg=48), [m_square],
             loc=(-1.0, 3.5, 0.01), collection=C_HOUSES)

# ---------------------------------------------------------------- vegetable garden
m_soil = add_detail(material("M_soil", (0.36, 0.24, 0.15), rough=0.95), tex("soil"), 1.0, 0.6, 0.8)
m_lettuce = material("M_lettuce", (0.45, 0.78, 0.3), rough=0.6, sss=0.2, sheen=0.3)
m_carrot = material("M_carrot_top", (0.25, 0.6, 0.22), rough=0.7)
m_wood = add_detail(material("M_wood", (0.6, 0.42, 0.25), rough=0.85), tex("wood"), 2.0, 0.45, 0.5)
m_sunpetal = material("M_sun_petal", (1.0, 0.8, 0.1), rough=0.6, sss=0.2)
for r in range(4):
    y = 3.2 + r * 1.1

    def row(bm, r=r):
        bm_box(bm, (9.0, 0.6, 0.12), (0, 0, 0.06), mat_index=0)
        for k in range(14):
            x = -4.2 + k * 0.65
            if r % 2 == 0:
                bm_sphere(bm, 0.2, (x, 0, 0.2), (1, 1, 0.7), seg=12, mat_index=1)
            else:
                for j in range(3):
                    bm_cone(bm, 0.03, 0.0, 0.3, (x + j * 0.05 - 0.05, 0, 0.27), seg=6, mat_index=2,
                            rot=(0.25 * (j - 1), 0, 0))
    mesh_obj(f"garden_row_{r}", row, [m_soil, m_lettuce, m_carrot], loc=(0.6, y, NA.terrain_h(0.6, y, False)),
             collection=C_GARDEN)


def fence(bm):
    for k in range(18):
        bm_box(bm, (0.1, 0.1, 0.9), (-8.5 + k, 0, 0.45), mat_index=0)
    for zz in (0.35, 0.7):
        bm_box(bm, (17.2, 0.06, 0.1), (0, 0, zz), mat_index=0)


mesh_obj("garden_fence", fence, [m_wood], loc=(0.3, 8.0, NA.terrain_h(0.3, 8.0, False)), collection=C_GARDEN)
for i, (sx, sy) in enumerate(((-6.5, 6.5), (-5.6, 7.0), (6.2, 6.6), (7.1, 7.1))):
    def sunflower(bm):
        bm_cone(bm, 0.04, 0.03, 1.8, (0, 0, 0.9), seg=8, mat_index=0)
        bm_sphere(bm, 0.16, (0, -0.04, 1.85), (1, 0.4, 1), seg=14, mat_index=1)
        for k in range(12):
            a = math.tau * k / 12
            bm_sphere(bm, 0.12, (math.cos(a) * 0.24, -0.03, 1.85 + math.sin(a) * 0.24), (1, 0.15, 0.4),
                      rot=(0, -a + math.pi / 2, 0), seg=8, mat_index=2)
    mesh_obj(f"sunflower_{i}", sunflower, [m_carrot, m_coco, m_sunpetal], loc=(sx, sy, NA.terrain_h(sx, sy, False)),
             collection=C_GARDEN)

# ---------------------------------------------------------------- rocks
m_rock = noise_ground_material("M_rock", (0.6, 0.58, 0.54), (0.42, 0.4, 0.37), scale=2.0, t=tex("rock"), tex_scale=1.0)
rock_models = models("rock")
for i in range(14):
    x, y = rng.uniform(-14, 14), rng.uniform(3, 9)
    if abs(x) < 3:
        x += math.copysign(3, x + 0.01)
    s = rng.uniform(0.4, 1.2)
    if rock_models and i % 2 and place_model(f"rock_{i}", rock_models[i % len(rock_models)], (x, y, 0.0),
                                             s * 0.9, C_ROCKS, rng.uniform(0, math.tau)):
        continue
    sphere(f"rock_{i}", 1.0, m_rock, loc=(x, y, s * 0.25), scl=(s * 1.3, s, s * 0.7),
           rot=(0, 0, rng.uniform(0, math.tau)), seg=16, collection=C_ROCKS)

# ---------------------------------------------------------------- extra library models per location
# (only when the library has them; positions stay out of the acting area: |x| > 5 or y > 4)
for fam, spots, hr, col, coast in (
        ("house", [(-19, 21), (-13, 24), (-6, 26), (7, 25), (14, 22), (20, 20)], (3.0, 4.0), C_HOUSES, False),
        ("village_prop", [(-7.6, 6.3), (6.2, 6.8), (8.8, 4.8), (-9.4, 4.6)], (1.0, 1.6), C_HOUSES, False),
        ("flower", [(-6.0, 2.6), (6.4, 2.8), (-8.2, 5.2), (8.6, 5.6), (-5.4, 9.0), (5.8, 9.2)], (0.4, 0.7),
         C_GARDEN, False),
        ("snowman", [(-6.5, 5.0), (7.2, 7.5)], (1.3, 1.7), C_SNOW, False),
        ("boat", [(-9, 28), (11, 34), (2, 42)], (1.4, 2.2), C_WATER, True)):
    lst = models(fam)
    for i, (x, y) in enumerate(spots if lst else []):
        z = -0.1 if fam == "boat" else NA.terrain_h(x, y, coast) - 0.03
        face_cam = math.atan2(-x, y) * 0.5 + rng.uniform(-0.3, 0.3)   # roughly turned towards the camera
        place_model(f"{fam}_{i}", lst[i % len(lst)], (x, y, z), rng.uniform(*hr), col, face_cam)
    if lst:
        print(f"[Blender build] {fam} : {len(spots)} placés depuis la bibliothèque")

# ---------------------------------------------------------------- clouds, night sky, fireflies, snow
m_cloud = material("M_cloud", (1, 1, 1), rough=1.0, emit=0.6, emit_color=(1, 1, 1))
for i in range(12):
    parts = [(p * 2.2 - 4.4, rng.uniform(-0.4, 0.8), rng.uniform(1.8, 3.2)) for p in range(5)]

    def cb(bm, parts=parts):
        for px, pz, r in parts:
            bm_sphere(bm, r, (px, 0, pz), (1, 1, 0.7), seg=16)
    mesh_obj(f"cloud_{i}", cb, [m_cloud], loc=(rng.uniform(-60, 60), rng.uniform(50, 75), rng.uniform(14, 22)),
             shadow=False, collection=MAIN)

sphere("moon", 4.0, material("M_moon", (1.0, 0.97, 0.85), emit=4.0), loc=(-24, 85, 34), seg=32,
       collection=C_NIGHT, shadow=False)


def stars(bm):
    r = random.Random(5)
    for _ in range(260):
        az, el = r.uniform(-1.3, 1.3), r.uniform(0.12, 1.2)
        d = 150.0
        bm_sphere(bm, r.uniform(0.15, 0.35), (math.sin(az) * math.cos(el) * d, math.cos(az) * math.cos(el) * d,
                                              math.sin(el) * d), seg=6)


mesh_obj("stars", stars, [glow_material("M_star_sky", (1.0, 0.97, 0.9), 8.0)], collection=C_NIGHT, shadow=False)
m_fire = glow_material("M_firefly", (0.85, 1.0, 0.45), 14.0)
for i in range(60):
    sphere(f"firefly_{i}", 0.025, m_fire, seg=8, collection=C_FIRE, shadow=False)
m_flake = material("M_snowflake", (1, 1, 1), rough=0.5, emit=0.8, emit_color=(1, 1, 1))
for i in range(220):
    sphere(f"snow_{i}", 0.022, m_flake, seg=6, collection=C_SNOW, shadow=False)


# ================================================================== human characters (heroes + guests)
def build_human(cfg):
    N = cfg["key"]
    style = cfg.get("hair_style", "short")
    girl = bool(cfg.get("skirt", style == "side_buns"))
    adult = bool(cfg.get("adult"))
    c = lambda k, d: tuple(cfg.get(k, d))
    skin = c("skin_color", (0.96, 0.75, 0.6))
    outfit = c("outfit_color", (0.92, 0.32, 0.58))
    hair_c = c("hair_color", (0.2, 0.1, 0.06))
    m_skin = material(f"{N}_skin", skin, rough=0.45, sss=0.25, sheen=0.15)
    m_lid = material(f"{N}_lid", NA.darken(skin, 0.06), rough=0.45, sss=0.2)
    m_out = material(f"{N}_outfit", outfit, rough=0.7, sheen=0.6)
    m_out2 = material(f"{N}_outfit2", NA.darken(outfit, 0.15), rough=0.7, sheen=0.6)
    m_acc = material(f"{N}_accent", c("accent_color", (1, 0.8, 0.25)), rough=0.5, coat=0.3)
    m_pants = material(f"{N}_pants", c("pants_color", (0.2, 0.25, 0.45)), rough=0.8, sheen=0.4)
    m_shoe = material(f"{N}_shoe", c("shoe_color", (1, 0.95, 0.9)), rough=0.35, coat=0.5)
    m_hair = material(f"{N}_hair", hair_c, rough=0.4, coat=0.35, sheen=0.5)
    m_white = material(f"{N}_eyewhite", (0.97, 0.97, 1.0), rough=0.15, coat=1.0, sss=0.1)
    m_iris = material(f"{N}_iris", c("iris_color", (0.42, 0.25, 0.12)), rough=0.2, coat=1.0)
    m_pupil = material(f"{N}_pupil", (0.01, 0.008, 0.006), rough=0.05, coat=1.0)
    m_spec = material(f"{N}_spec", (1, 1, 1), emit=6.0)
    m_brow = material(f"{N}_brow", NA.darken(hair_c, 0.2), rough=0.7)
    m_lip = material(f"{N}_lip", c("lip_color", (0.62, 0.25, 0.28)), rough=0.4, sss=0.2)
    m_mouth = material(f"{N}_mouthin", (0.3, 0.05, 0.08), rough=0.8)
    m_tongue = material(f"{N}_tongue", (0.95, 0.45, 0.5), rough=0.5, sss=0.3)
    m_cheek = glow_material(f"{N}_cheek", c("cheek_color", (1, 0.55, 0.55)), 0.35)

    leg_len = float(cfg.get("leg_len", 0.48))
    head_s = float(cfg.get("head_scale", 1.0))
    torso_z = 1.3 if adult else 1.15
    neck_z = 0.6 if adult else 0.54
    root = empty(f"{N}_root")
    h = float(cfg.get("height", 1.0))
    root.scale = (h, h, h)
    body = empty(f"{N}_body", root)
    spine = empty(f"{N}_spine", body, (0, 0, leg_len))
    sphere(f"{N}_torso", 0.26, m_out, spine, (0, 0, 0.27 + (0.03 if adult else 0)), (1.05 if adult else 1.0, 0.82, torso_z), seg=48)
    if girl:
        skirt_len = 0.6 if adult else 0.32
        cone(f"{N}_skirt", 0.36 if adult else 0.34, 0.2, skirt_len, m_out2, spine, (0, 0, 0.18 - skirt_len / 2), seg=40)
        sphere(f"{N}_button", 0.045, m_acc, spine, (0, -0.205, 0.36), seg=16)
    else:
        cone(f"{N}_belt", 0.25, 0.24, 0.12, m_pants, spine, (0, 0, 0.03), seg=40)
        sphere(f"{N}_stripe", 1.0, m_acc, spine, (0, -0.2, 0.3), (0.17, 0.02, 0.025), seg=16)
    sphere(f"{N}_collar", 1.0, m_acc, spine, (0, 0, neck_z - 0.01), (0.13, 0.11, 0.04), seg=24)
    arm_z = 0.47 + (0.06 if adult else 0)
    for s, tag in ((-1.0, "L"), (1.0, "R")):
        arm = empty(f"{N}_arm_{tag}", spine, (s * 0.25, 0, arm_z))
        if adult:
            arm.scale = (1, 1, 1.25)
        sphere(f"{N}_shoulder_{tag}", 0.085, m_out, arm, (0, 0, -0.02), seg=20)
        sphere(f"{N}_upper_{tag}", 0.07, m_out, arm, (0, 0, -0.1), (1, 1, 1.9), seg=20)
        sphere(f"{N}_fore_{tag}", 0.052, m_out if adult else m_skin, arm, (0, 0, -0.26), (1, 1, 2.6), seg=20)
        sphere(f"{N}_hand_{tag}", 0.068, m_skin, arm, (0, -0.01, -0.39), (1.0, 0.85, 1.1), seg=24)
        sphere(f"{N}_thumb_{tag}", 0.028, m_skin, arm, (-s * 0.055, -0.035, -0.37), seg=12)
        leg = empty(f"{N}_leg_{tag}", body, (s * 0.1, 0, leg_len))
        leg.scale = (1, 1, leg_len / 0.48)
        sphere(f"{N}_thigh_{tag}", 0.075, m_skin if (girl and not adult) else m_pants, leg, (0, 0, -0.2), (1, 1, 2.9), seg=20)
        if girl and not adult:
            sphere(f"{N}_sock_{tag}", 0.08, m_pants, leg, (0, 0, -0.33), (1, 1, 1.1), seg=20)
        sphere(f"{N}_shoe_{tag}", 0.1, m_shoe, leg, (0, -0.045, -0.425), (1.0, 1.5, 0.62 * 0.48 / leg_len), seg=24)

    head = empty(f"{N}_head", spine, (0, 0, neck_z))
    head.scale = (head_s, head_s, head_s)
    cone(f"{N}_neck", 0.075, 0.065, 0.12, m_skin, head, (0, 0, 0.03), seg=24)
    sphere(f"{N}_skull", 0.34, m_skin, head, (0, 0, 0.33), (1.0, 0.9, 0.94), seg=64)
    for s, tag in ((-1.0, "L"), (1.0, "R")):
        sphere(f"{N}_ear_{tag}", 0.07, m_skin, head, (s * 0.33, 0.01, 0.32), (0.6, 0.9, 1.0), seg=16)
        sphere(f"{N}_cheek_{tag}", 0.05, m_cheek, head, (s * 0.17, -0.25, 0.245), (1.0, 0.35, 0.6), seg=16, shadow=False)
    sphere(f"{N}_nose", 0.036 if not adult else 0.042, m_skin, head, (0, -0.305, 0.285), (1.1, 1.0, 0.9), seg=20)
    for s, tag in ((-1.0, "L"), (1.0, "R")):
        ep_ = empty(f"{N}_eye_{tag}", head, (s * 0.12, -0.25, 0.355))
        if adult:
            ep_.scale = (0.85, 0.85, 0.85)
        sphere(f"{N}_white_{tag}", 0.085, m_white, ep_, (0, 0, 0), (1.0, 0.8, 1.12), seg=40, shadow=False)
        look = empty(f"{N}_look_{tag}", ep_)
        sphere(f"{N}_iris_{tag}", 0.054, m_iris, look, (0, -0.052, 0), (1.0, 0.45, 1.1), seg=32, shadow=False)
        sphere(f"{N}_pupil_{tag}", 0.03, m_pupil, look, (0, -0.069, 0), (1.0, 0.4, 1.1), seg=20, shadow=False)
        sphere(f"{N}_spec_{tag}", 0.016, m_spec, look, (0.02, -0.074, 0.028), seg=12, shadow=False)
        sphere(f"{N}_spec2_{tag}", 0.008, m_spec, look, (-0.018, -0.073, -0.02), seg=10, shadow=False)
        lid = sphere(f"{N}_lid_{tag}", 0.098, m_lid, ep_, (0, 0, 0), (1.0, 1.0, 0.82), seg=40, hemi=True, shadow=False)
        lid.rotation_euler = (-0.96, 0, 0)
        if girl and not adult:
            sphere(f"{N}_lash_{tag}", 1.0, m_pupil, lid, (s * 0.088, -0.03, 0.01), (0.035, 0.008, 0.012),
                   rot=(0, 0, s * 0.6), seg=10, shadow=False)
        low = sphere(f"{N}_low_{tag}", 0.096, m_lid, ep_, (0, 0, 0), (1.0, 1.0, 0.8), seg=32, hemi=True, shadow=False)
        low.rotation_euler = (4.19, 0, 0)
        brow = empty(f"{N}_brow_{tag}", head, (s * 0.125, -0.272, 0.475))
        sphere(f"{N}_browmesh_{tag}", 1.0, m_brow, brow, (0, 0, 0), (0.068, 0.016 if not adult else 0.02, 0.02), seg=16,
               shadow=False)
    if cfg.get("glasses"):
        m_gl = material(f"{N}_glasses", (0.55, 0.3, 0.15), rough=0.3, coat=0.8)
        for s, tag in ((-1.0, "L"), (1.0, "R")):
            ring(f"{N}_glass_{tag}", 0.085, 0.008, m_gl, head, (s * 0.12, -0.33, 0.355))
        sphere(f"{N}_bridge", 1.0, m_gl, head, (0, -0.335, 0.36), (0.04, 0.008, 0.008), seg=8)

    cu = bpy.data.curves.new(f"{N}_mouth", "CURVE")
    cu.dimensions = "3D"
    cu.bevel_depth = 0.011
    cu.bevel_resolution = 4
    cu.resolution_u = 16
    cu.use_fill_caps = True
    sp = cu.splines.new("BEZIER")
    sp.bezier_points.add(2)
    for i, bp in enumerate(sp.bezier_points):
        bp.co = ((i - 1) * 0.075, 0, 0)
        bp.handle_left_type = bp.handle_right_type = "FREE"
    cu.materials.append(m_lip)
    mouth = bpy.data.objects.new(f"{N}_mouth", cu)
    TARGET.objects.link(mouth)
    mouth.parent = head
    mouth.location = (0, -0.292, 0.19)
    inner = sphere(f"{N}_inner", 0.05, m_mouth, mouth, (0, 0.004, -0.01), (1.2, 0.3, 0.1), seg=24, shadow=False)
    sphere(f"{N}_tongue", 0.03, m_tongue, inner, (0, -0.1, -0.35), (1.2, 1.0, 0.6), seg=16, shadow=False)
    if cfg.get("beard"):
        sphere(f"{N}_beard", 0.2, m_hair, head, (0, -0.2, 0.13), (1.15, 0.7, 0.9), seg=32)
        sphere(f"{N}_moustache", 0.06, m_hair, head, (0, -0.3, 0.225), (1.6, 0.5, 0.45), seg=16)

    hair = empty(f"{N}_hair", head, (0, 0, 0.33))
    sway = empty(f"{N}_sway", hair, (0, 0, 0.1))
    if style == "headscarf":
        m_scarf = material(f"{N}_scarf", c("scarf_color", (0.85, 0.3, 0.4)), rough=0.7, sheen=0.8)
        sphere(f"{N}_scarf", 0.385, m_scarf, hair, (0, 0.03, 0.01), (1.04, 1.0, 1.04), rot=(-0.5, 0, 0), seg=56, hemi=True)
        sphere(f"{N}_scarfback", 0.36, m_scarf, hair, (0, 0.1, -0.08), (1.02, 0.85, 1.0), seg=40)
        sphere(f"{N}_drape", 0.3, m_scarf, sway, (0, 0.12, -0.42), (1.05, 0.7, 0.9), seg=32)
        sphere(f"{N}_fringe", 0.08, m_hair, hair, (0, -0.31, 0.11), (2.2, 0.4, 0.45), seg=16)
    else:
        sphere(f"{N}_haircap", 0.362, m_hair, hair, (0, 0, 0), (1.03, 0.97, 1.0), rot=(-0.62, 0, 0), seg=56, hemi=True)
        sphere(f"{N}_hairback", 0.33, m_hair, hair, (0, 0.1, -0.02), (1.0, 0.85, 0.95), seg=40)
        if style == "side_buns":
            for s, tag in ((-1.0, "L"), (1.0, "R")):
                sphere(f"{N}_bun_{tag}", 0.13, m_hair, sway, (s * 0.28, 0.05, 0.27), seg=32)
                sphere(f"{N}_bobble_{tag}", 0.04, m_acc, sway, (s * 0.2, -0.02, 0.2), seg=16)
            for b in range(4):
                bx = -0.15 + b * 0.1
                sphere(f"{N}_bang_{b}", 0.085, m_hair, hair, (bx, -0.235, 0.255 - abs(bx) * 0.25), (1, 0.7, 0.7), seg=20)
        elif style == "curly":
            cr = random.Random(77)
            for k in range(24):
                az = math.tau * k / 24
                el = math.radians(cr.uniform(28, 75))
                d = Vector((math.sin(az) * math.cos(el), -math.cos(az) * math.cos(el), math.sin(el)))
                if d.y < -0.55 and d.z < 0.75:
                    d.z += 0.25
                    d.normalize()
                sphere(f"{N}_curl_{k}", cr.uniform(0.08, 0.105), m_hair, sway,
                       tuple(d * 0.35 + Vector((0, 0.04, -0.16))), seg=18)
        elif style == "ponytail":
            sphere(f"{N}_tie", 0.05, m_acc, sway, (0, 0.33, 0.1), seg=16)
            for k in range(4):
                sphere(f"{N}_tail_{k}", 0.1 - k * 0.012, m_hair, sway, (0, 0.38 + k * 0.03, 0.02 - k * 0.11), seg=20)
            for b in range(3):
                sphere(f"{N}_bang_{b}", 0.085, m_hair, hair, (-0.1 + b * 0.1, -0.235, 0.24), (1, 0.7, 0.7), seg=20)
        elif style == "cap":
            m_cap = material(f"{N}_cap", c("cap_color", (0.95, 0.95, 0.92)), rough=0.8, sheen=0.5)
            cone(f"{N}_cap", 0.3, 0.29, 0.14, m_cap, hair, (0, 0.02, 0.17), seg=40)
        else:
            for b in range(3):
                sphere(f"{N}_bang_{b}", 0.09, m_hair, hair, (-0.1 + b * 0.1, -0.22, 0.26), (1, 0.7, 0.7), seg=20)


# ================================================================== animals
def build_animal(cfg):
    K, sp = cfg["key"], cfg["species"]
    c = lambda k, d: tuple(cfg.get(k, d))
    fur, belly = c("fur", (0.9, 0.6, 0.3)), c("belly", (1, 0.9, 0.8))
    m_fur = material(f"{K}_fur", fur, rough=0.7, sheen=1.0, sss=0.1)
    m_belly = material(f"{K}_belly", belly, rough=0.75, sheen=1.0)
    m_nose = material(f"{K}_nose", c("nose", (0.1, 0.08, 0.08)), rough=0.3, coat=0.6)
    m_white = material(f"{K}_eyewhite", (0.97, 0.97, 1.0), rough=0.15, coat=1.0)
    m_iris = material(f"{K}_iris", c("iris", (0.3, 0.6, 0.3)), rough=0.2, coat=1.0)
    m_pupil = material(f"{K}_pupil", (0.01, 0.01, 0.01), rough=0.05, coat=1.0)
    m_spec = material(f"{K}_spec", (1, 1, 1), emit=6.0)
    m_mouth = material(f"{K}_mouthin", (0.35, 0.06, 0.1), rough=0.8)
    m_pink = material(f"{K}_pink", (1.0, 0.7, 0.75), rough=0.6, sss=0.3)

    root = empty(f"{K}_root")
    s = float(cfg.get("size", 1.0))
    root.scale = (s, s, s)
    body = empty(f"{K}_body", root)

    def eyes(head, spacing, y, z, r, slit=False, big_iris=False):
        for side, tag in ((-1.0, "L"), (1.0, "R")):
            ep_ = empty(f"{K}_eye_{tag}", head, (side * spacing, y, z))
            sphere(f"{K}_white_{tag}", r, m_white, ep_, (0, 0, 0), (1.0, 0.7, 1.15), seg=24, shadow=False)
            look = empty(f"{K}_look_{tag}", ep_)
            ir = r * (0.85 if big_iris else 0.68)
            sphere(f"{K}_iris_{tag}", ir, m_iris, look, (0, -r * 0.55, 0), (1, 0.45, 1.1), seg=20, shadow=False)
            sphere(f"{K}_pupil_{tag}", ir * 0.55, m_pupil, look, (0, -r * 0.72, 0),
                   (0.35 if slit else 1.0, 0.4, 1.15), seg=16, shadow=False)
            sphere(f"{K}_spec_{tag}", r * 0.2, m_spec, look, (r * 0.25, -r * 0.8, r * 0.3), seg=8, shadow=False)
            lid = sphere(f"{K}_lid_{tag}", r * 1.12, m_fur, ep_, (0, 0, 0), (1.0, 1.0, 0.82), seg=24, hemi=True,
                         shadow=False)
            lid.rotation_euler = (-0.96, 0, 0)

    if sp in ("cat", "dog", "rabbit"):
        long_ = {"cat": 0.25, "dog": 0.27, "rabbit": 0.2}[sp]
        sphere(f"{K}_torso", 1.0, m_fur, body, (0, 0, 0.3), (0.15, long_, 0.15), seg=32)
        sphere(f"{K}_chest", 1.0, m_belly, body, (0, -long_ * 0.55, 0.27), (0.1, 0.09, 0.11), seg=24)
        head = empty(f"{K}_head", body, (0, -long_ * 0.9, 0.44 if sp != "dog" else 0.48))
        sphere(f"{K}_skull", 0.15, m_fur, head, (0, 0, 0), (1.1, 0.95, 1.0), seg=40)
        snout = (0.06, 0.05, 0.045) if sp != "dog" else (0.07, 0.09, 0.06)
        sphere(f"{K}_snout", 1.0, m_belly, head, (0, -0.12 if sp != "dog" else -0.15, -0.045), snout, seg=24)
        sphere(f"{K}_nosetip", 0.022 if sp != "dog" else 0.032, m_nose, head,
               (0, -0.17 if sp != "dog" else -0.235, -0.015), (1.2, 0.8, 0.8), seg=12)
        jaw = empty(f"{K}_jaw", head, (0, -0.13 if sp != "dog" else -0.18, -0.08))
        sphere(f"{K}_inner", 0.035, m_mouth, jaw, (0, -0.02, 0), (1.2, 0.6, 0.15), seg=16, shadow=False)
        eyes(head, 0.065, -0.11, 0.03, 0.045 if sp != "rabbit" else 0.042, slit=(sp == "cat"))
        for side, tag in ((-1.0, "L"), (1.0, "R")):
            ear = empty(f"{K}_ear_{tag}", head, (side * (0.085 if sp == "cat" else 0.12 if sp == "dog" else 0.05), 0.0,
                                                 0.12 if sp != "dog" else 0.06))
            if sp == "cat":
                cone(f"{K}_earmesh_{tag}", 0.06, 0.0, 0.12, m_fur, ear, (0, 0, 0.05), rot=(0, side * -0.25, 0), seg=4)
                cone(f"{K}_earin_{tag}", 0.035, 0.0, 0.08, m_pink, ear, (0, -0.02, 0.04), rot=(0, side * -0.25, 0), seg=4)
            elif sp == "dog":
                sphere(f"{K}_earmesh_{tag}", 1.0, m_fur, ear, (side * 0.03, 0.0, -0.08), (0.035, 0.05, 0.1), seg=16)
            else:
                sphere(f"{K}_earmesh_{tag}", 1.0, m_fur, ear, (0, 0, 0.14), (0.035, 0.02, 0.14), rot=(0, side * -0.15, 0), seg=16)
                sphere(f"{K}_earin_{tag}", 1.0, m_pink, ear, (0, -0.012, 0.14), (0.02, 0.01, 0.11), rot=(0, side * -0.15, 0), seg=12)
        legs = [(-0.08, -long_ * 0.6), (0.08, -long_ * 0.6), (-0.08, long_ * 0.6), (0.08, long_ * 0.6)]
        for i, (lx, ly) in enumerate(legs):
            leg = empty(f"{K}_leg_{i}", body, (lx, ly, 0.22))
            back_big = sp == "rabbit" and i >= 2
            sphere(f"{K}_legm_{i}", 1.0, m_fur, leg, (0, 0, -0.09), (0.045, 0.05 if not back_big else 0.08, 0.11), seg=16)
            sphere(f"{K}_paw_{i}", 1.0, m_belly, leg, (0, -0.015, -0.2), (0.045, 0.06 if not back_big else 0.09, 0.03), seg=16)
        tail = empty(f"{K}_tail", body, (0, long_ * 0.95, 0.36))
        if sp == "cat":
            for k in range(6):
                sphere(f"{K}_tailm_{k}", 0.04 - k * 0.003, m_fur, tail, (0, 0.05 + k * 0.05, 0.03 + k * k * 0.012), seg=12)
        elif sp == "dog":
            for k in range(3):
                sphere(f"{K}_tailm_{k}", 0.04 - k * 0.006, m_fur, tail, (0, 0.04 + k * 0.04, 0.05 + k * 0.05), seg=12)
        else:
            sphere(f"{K}_tailm_0", 0.06, m_belly, tail, (0, 0.03, 0.0), seg=16)
        for tag in ("L", "R"):
            empty(f"{K}_wing_{tag}", body)
    elif sp == "bird":
        sphere(f"{K}_torso", 1.0, m_fur, body, (0, 0, 0), (0.07, 0.085, 0.075), seg=24)
        sphere(f"{K}_breast", 1.0, m_belly, body, (0, -0.035, -0.01), (0.055, 0.05, 0.06), seg=20)
        head = empty(f"{K}_head", body, (0, -0.05, 0.075))
        sphere(f"{K}_skull", 0.058, m_fur, head, (0, 0, 0), seg=24)
        cone(f"{K}_beak", 0.02, 0.0, 0.045, m_nose, head, (0, -0.07, -0.005), rot=(math.pi / 2, 0, 0), seg=8)
        jaw = empty(f"{K}_jaw", head, (0, -0.055, -0.015))
        cone(f"{K}_beaklow", 0.014, 0.0, 0.03, m_nose, jaw, (0, -0.012, 0), rot=(math.pi / 2, 0, 0), seg=8)
        sphere(f"{K}_inner", 0.01, m_mouth, jaw, (0, 0, 0), seg=8, shadow=False)
        eyes(head, 0.028, -0.042, 0.015, 0.018, big_iris=True)
        for side, tag in ((-1.0, "L"), (1.0, "R")):
            w = empty(f"{K}_wing_{tag}", body, (side * 0.06, 0.0, 0.02))
            sphere(f"{K}_wingm_{tag}", 1.0, m_fur, w, (side * 0.05, 0.01, 0.0), (0.06, 0.045, 0.015), seg=16)
            empty(f"{K}_ear_{tag}", head)
        tail = empty(f"{K}_tail", body, (0, 0.08, 0.0))
        sphere(f"{K}_tailm", 1.0, m_fur, tail, (0, 0.04, 0.01), (0.03, 0.05, 0.01), rot=(0.4, 0, 0), seg=12)
        for i in range(4):
            leg = empty(f"{K}_leg_{i}", body, ((-0.02 if i % 2 == 0 else 0.02), 0.0, -0.06))
            if i < 2:
                cone(f"{K}_legm_{i}", 0.006, 0.006, 0.05, m_nose, leg, (0, 0, -0.02), seg=6)
    else:   # owl
        sphere(f"{K}_torso", 1.0, m_fur, body, (0, 0, 0.22), (0.17, 0.15, 0.21), seg=32)
        sphere(f"{K}_breast", 1.0, m_belly, body, (0, -0.07, 0.2), (0.12, 0.09, 0.15), seg=24)
        head = empty(f"{K}_head", body, (0, -0.01, 0.42))
        sphere(f"{K}_skull", 1.0, m_fur, head, (0, 0, 0), (0.16, 0.14, 0.13), seg=40)
        for side, tag in ((-1.0, "L"), (1.0, "R")):
            sphere(f"{K}_disc_{tag}", 1.0, m_belly, head, (side * 0.065, -0.11, 0.0), (0.065, 0.02, 0.065), seg=24)
            ear = empty(f"{K}_ear_{tag}", head, (side * 0.1, 0.0, 0.1))
            cone(f"{K}_tuft_{tag}", 0.035, 0.0, 0.09, m_fur, ear, (0, 0, 0.03), rot=(0, side * -0.4, 0), seg=6)
            w = empty(f"{K}_wing_{tag}", body, (side * 0.16, 0.0, 0.28))
            sphere(f"{K}_wingm_{tag}", 1.0, m_fur, w, (side * 0.02, 0.01, -0.05), (0.04, 0.11, 0.16), seg=20)
        eyes(head, 0.065, -0.115, 0.0, 0.045, big_iris=True)
        jaw = empty(f"{K}_jaw", head, (0, -0.14, -0.04))
        cone(f"{K}_beak", 0.02, 0.0, 0.05, m_nose, jaw, (0, 0, -0.01), rot=(math.pi, 0, 0), seg=8)
        sphere(f"{K}_inner", 0.012, m_mouth, jaw, (0, 0.005, 0.0), seg=8, shadow=False)
        tail = empty(f"{K}_tail", body, (0, 0.13, 0.08))
        sphere(f"{K}_tailm", 1.0, m_fur, tail, (0, 0.02, -0.03), (0.08, 0.03, 0.06), seg=12)
        for i in range(4):
            leg = empty(f"{K}_leg_{i}", body, ((-0.06 if i % 2 == 0 else 0.06), -0.04, 0.02))
            if i < 2:
                sphere(f"{K}_foot_{i}", 1.0, m_nose, leg, (0, -0.02, 0.0), (0.035, 0.04, 0.015), seg=12)


# ================================================================== cast
CHAR_DIR = BASE / "assets" / "characters"


def append_pro_character(key):
    """Appends the artist's character (collection <key>) from assets/characters/<key>.blend."""
    path = CHAR_DIR / f"{key.lower()}.blend"
    if not path.exists():
        return False
    with bpy.data.libraries.load(str(path), link=False) as (src, dst):
        if key not in src.collections:
            raise SystemExit(f"{path.name}: collection '{key}' not found (see cahier des charges)")
        dst.collections = [key]
    c = dst.collections[0]
    scene.collection.children.link(c)
    rig = bpy.data.objects.get(f"{key}_rig")
    if rig is None:
        raise SystemExit(f"{path.name}: armature '{key}_rig' not found")
    rig.location, rig.rotation_euler = (0, 0, 0), (0, 0, 0)
    print(f"[Blender build] professional character loaded: {path.name}")
    return True


actors_cfg = json.loads((EXPORT / "actors_config.json").read_text(encoding="utf-8"))["characters"]
for cfg in actors_cfg:
    key, kind = cfg["key"], cfg.get("kind", "hero")
    if append_pro_character(key):
        continue
    if kind != "hero":
        TARGET = coll(key)
    if kind == "animal":
        build_animal(cfg)
    else:
        build_human(cfg)
    TARGET = MAIN
    print(f"[Blender build] {cfg.get('name', key)} ({kind}) construit")

# ================================================================== magic object + bloom
C_MAGIC, C_SPARK, C_BLOOM = coll("magic_set"), coll("sparkle_set"), coll("bloom_set")
magic = empty("magic", collection=C_MAGIC)
kind = ep.object_type
gold = (1.0, 0.82, 0.3)
if kind == "star":
    m = material("M_star", (1.0, 0.9, 0.35), rough=0.3, emit=8.0)

    def star(bm):
        bm_sphere(bm, 0.1, seg=20)
        for i in range(5):
            a = math.tau * i / 5
            bm_cone(bm, 0.07, 0.0, 0.2, (math.sin(a) * 0.14, 0, math.cos(a) * 0.14), seg=8, rot=(0, a, 0))
    mesh_obj("magic_core", star, [m], magic, collection=C_MAGIC)
elif kind == "shell":
    gold = (1.0, 0.7, 0.85)
    sphere("magic_core", 0.15, material("M_shell", (1.0, 0.62, 0.75), rough=0.25, coat=1.0, emit=4.0), magic,
           scl=(1.0, 0.45, 0.75), collection=C_MAGIC)
elif kind == "lantern":
    gold = (1.0, 0.7, 0.35)
    fm = material("M_lframe", (0.55, 0.32, 0.15), rough=0.5, coat=0.4)
    cone("magic_top", 0.09, 0.07, 0.03, fm, magic, (0, 0, 0.12), collection=C_MAGIC)
    cone("magic_bot", 0.07, 0.09, 0.03, fm, magic, (0, 0, -0.12), collection=C_MAGIC)
    sphere("magic_core", 0.1, material("M_lglow", (1.0, 0.7, 0.3), emit=10.0), magic, scl=(1, 1, 1.2),
           collection=C_MAGIC)
else:
    sphere("magic_core", 0.09, material("M_seed", (1.0, 0.85, 0.35), rough=0.3, emit=8.0), magic,
           scl=(1, 1, 1.35), collection=C_MAGIC)
    sphere("magic_leaf", 0.06, material("M_seedleaf", (0.4, 0.85, 0.35), rough=0.5, sss=0.3), magic,
           (0.05, 0, 0.12), (1.5, 0.8, 0.35), rot=(0, 0.6, 0), collection=C_MAGIC)
sphere("magic_halo", 0.28, glow_material("M_halo1", gold, 1.2, 0.35), magic, seg=24, collection=C_MAGIC, shadow=False)
sphere("magic_halo2", 0.55, glow_material("M_halo2", gold, 1.2, 0.12), magic, seg=24, collection=C_MAGIC, shadow=False)
ld = bpy.data.lights.new("magic_light", "POINT")
ld.color, ld.energy, ld.shadow_soft_size = gold, 40.0, 0.1
lo = bpy.data.objects.new("magic_light", ld)
C_MAGIC.objects.link(lo)
lo.parent = magic
m_sp = glow_material("M_sparkle", (1.0, 0.95, 0.6), 12.0)
for i in range(28):
    sphere(f"sparkle_{i}", 0.018, m_sp, seg=8, collection=C_SPARK, shadow=False)

bloom = empty("bloom", loc=(0, 0.9, 0), collection=C_BLOOM)
cone("bloom_stem", 0.08, 0.05, 1.4, material("M_stem", (0.2, 0.6, 0.25)), bloom, (0, 0, 0.7), seg=16, collection=C_BLOOM)
m_bleaf = material("M_bleaf", (0.3, 0.7, 0.3), rough=0.6, sss=0.3)
for s in (-1, 1):
    sphere(f"bloom_leaf_{s}", 0.18, m_bleaf, bloom, (s * 0.2, 0, 0.45), (1.4, 0.7, 0.25), rot=(0, -s * 0.4, 0),
           collection=C_BLOOM)
m_petal = material("M_bpetal", (1.0, 0.5, 0.8), rough=0.4, sss=0.5, emit=1.5)
for i in range(10):
    a = math.tau * i / 10
    sphere(f"bloom_petal_{i}", 0.28, m_petal, bloom, (math.sin(a) * 0.32, -0.05, 1.5 + math.cos(a) * 0.32),
           (0.5, 0.18, 0.95), rot=(0, a, 0), collection=C_BLOOM)
sphere("bloom_core", 0.17, material("M_bcore", (1.0, 0.85, 0.3), emit=10.0), bloom, (0, -0.12, 1.5), collection=C_BLOOM)
sphere("bloom_halo", 0.9, glow_material("M_bhalo", (1.0, 0.75, 0.9), 1.0, 0.1), bloom, (0, 0, 1.5),
       collection=C_BLOOM, shadow=False)
bl = bpy.data.lights.new("bloom_light", "POINT")
bl.color, bl.energy = (1.0, 0.75, 0.85), 0.0
blo = bpy.data.objects.new("bloom_light", bl)
C_BLOOM.objects.link(blo)
blo.parent = bloom
blo.location = (0, -0.5, 1.5)

# ================================================================== check + save
missing = []
OPTIONAL = ("sparkle_", "tree_", "cloud_", "pine_", "palm_", "firefly_", "snow_")


def _get(n):
    o = bpy.data.objects.get(n)
    if o is None and not n.startswith(OPTIONAL) and not n.endswith(("_rig", "_face")):
        missing.append(n)
    return o


ep.bind(_get, lambda o, n: (bpy.data.worlds.get(o) or bpy.data.materials.get(o)).node_tree.nodes[n],
        lambda n: bpy.data.collections[n])
if missing:
    raise SystemExit(f"Missing objects: {missing}")
for f in range(0, ep.total, ep.fps * 15):     # sanity: one update in every scene half
    ep.update(f)
try:
    bpy.ops.file.pack_all()                   # textures, HDRIs and model images inside episode.blend
except Exception as exc:
    print(f"[Blender build] pack_all : {exc}")
n_models = sum(1 for o in bpy.data.objects if o.instance_type == "COLLECTION" and o.instance_collection
               and o.instance_collection.name.startswith("proto_"))
(EXPORT / "used_assets.json").write_text(json.dumps({"models": USED_MODELS}, ensure_ascii=False, indent=2),
                                         encoding="utf-8")
bpy.ops.wm.save_as_mainfile(filepath=str(EXPORT / "episode.blend"), compress=True)
print(f"[Blender build] episode.blend saved - {len(bpy.data.objects)} objects, {n_models} modèles de la bibliothèque")
