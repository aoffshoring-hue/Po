"""Renders one chunk of the episode.

blender -b export/episode.blend --python agents/blender/render_chunk.py -- <chunk_index> <chunk_total>

Env: NOURY_ENGINE  CYCLES (default, CPU-safe) | EEVEE (needs a GPU / OpenGL)
     NOURY_SAMPLES Cycles samples (default 32) / EEVEE samples (default 48)
     NOURY_GPU     1 -> use CUDA/OptiX/HIP/Metal for Cycles if available
     NOURY_QUALITY final (1920x1080) | preview (1280x720)
     NOURY_MOTION_BLUR 1 (default) | 0
"""
import math
import os
import sys
import time
from pathlib import Path

import bpy

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import noury_anim as NA  # noqa: E402

BASE = HERE.parent.parent
EXPORT = BASE / "export"
FRAMES = EXPORT / "frames"
args = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
idx, total = (int(args[0]), int(args[1])) if len(args) >= 2 else (0, 1)

ep = NA.Episode(EXPORT)
ep.bind(lambda n: bpy.data.objects.get(n),
        lambda o, n: (bpy.data.worlds.get(o) or bpy.data.materials.get(o)).node_tree.nodes[n],
        lambda n: bpy.data.collections[n])
scene = bpy.context.scene
r = scene.render
preview = os.environ.get("NOURY_QUALITY") == "preview"
r.resolution_x, r.resolution_y = (1280, 720) if preview else (1920, 1080)
r.resolution_percentage = 100
r.image_settings.file_format = "PNG"
r.image_settings.color_mode = "RGB"
r.image_settings.compression = 15
r.use_persistent_data = True
r.film_transparent = False
for vt, look in (("AgX", "AgX - Punchy"), ("AgX", "Punchy"), ("Filmic", "Medium High Contrast")):
    try:
        scene.view_settings.view_transform = vt
        try:
            scene.view_settings.look = look
        except TypeError:
            pass
        break
    except TypeError:
        continue
scene.view_settings.exposure = 0.15

engine = os.environ.get("NOURY_ENGINE", "CYCLES").upper()
if engine == "EEVEE":
    names = [e.identifier for e in bpy.types.RenderSettings.bl_rna.properties["engine"].enum_items]
    r.engine = "BLENDER_EEVEE_NEXT" if "BLENDER_EEVEE_NEXT" in names else "BLENDER_EEVEE"
    ee = scene.eevee
    ee.taa_render_samples = int(os.environ.get("NOURY_SAMPLES", "48"))
    for attr, val in (("use_gtao", True), ("use_bloom", True), ("use_soft_shadows", True),
                      ("use_raytracing", True), ("use_shadows", True)):
        if hasattr(ee, attr):
            setattr(ee, attr, val)
else:
    r.engine = "CYCLES"
    cy = scene.cycles
    cy.samples = int(os.environ.get("NOURY_SAMPLES", "32"))
    cy.use_adaptive_sampling = True
    cy.adaptive_threshold = 0.04
    cy.use_denoising = True
    try:
        cy.denoiser = "OPENIMAGEDENOISE"
    except TypeError:
        pass
    cy.max_bounces, cy.diffuse_bounces, cy.glossy_bounces = 4, 2, 2
    cy.transmission_bounces, cy.transparent_max_bounces = 2, 8
    cy.caustics_reflective = cy.caustics_refractive = False
    cy.blur_glossy = 1.0
    cy.device = "CPU"
    if os.environ.get("NOURY_GPU") == "1":
        prefs = bpy.context.preferences.addons["cycles"].preferences
        for backend in ("OPTIX", "CUDA", "HIP", "METAL", "ONEAPI"):
            try:
                prefs.compute_device_type = backend
                prefs.get_devices()
                gpus = [d for d in prefs.devices if d.type != "CPU"]
                if gpus:
                    for d in prefs.devices:
                        d.use = d.type != "CPU"
                    cy.device = "GPU"
                    print(f"[Render] GPU backend {backend}: {[d.name for d in gpus]}")
                    break
            except TypeError:
                continue

# ---------------------------------------------------------------- motion blur (sub-frame animation)
if os.environ.get("NOURY_MOTION_BLUR", "1") == "1":
    def _noury_frame(scn, depsgraph=None):
        ep.update(scn.frame_current - 1 + scn.frame_subframe)
    bpy.app.handlers.frame_change_pre.append(_noury_frame)
    r.use_lock_interface = True
    r.use_motion_blur = True
    r.motion_blur_shutter = 0.5
    print("[Render] motion blur ON")


# ---------------------------------------------------------------- compositing: glow + vignette
def setup_compositor():
    scene.use_nodes = True
    nt = scene.node_tree
    nt.nodes.clear()
    rl = nt.nodes.new("CompositorNodeRLayers")
    comp = nt.nodes.new("CompositorNodeComposite")
    glare = nt.nodes.new("CompositorNodeGlare")
    for attr, val in (("glare_type", "FOG_GLOW"), ("quality", "HIGH"), ("threshold", 0.85),
                      ("size", 7), ("mix", -0.55)):
        try:
            setattr(glare, attr, val)
        except (AttributeError, TypeError):
            pass
    nt.links.new(rl.outputs["Image"], glare.inputs[0])
    mask = nt.nodes.new("CompositorNodeEllipseMask")
    mask.width, mask.height = 1.15, 1.05
    blur = nt.nodes.new("CompositorNodeBlur")
    blur.use_relative = True
    blur.factor_x = blur.factor_y = 25.0
    nt.links.new(mask.outputs["Mask"], blur.inputs[0])
    mix = nt.nodes.new("CompositorNodeMixRGB")
    mix.blend_type = "MULTIPLY"
    mix.inputs[0].default_value = 0.22
    nt.links.new(glare.outputs[0], mix.inputs[1])
    nt.links.new(blur.outputs[0], mix.inputs[2])
    nt.links.new(mix.outputs[0], comp.inputs[0])


try:
    setup_compositor()
    print("[Render] compositor: glow + vignette")
except Exception as exc:                 # node API differs between Blender versions
    scene.use_nodes = False
    print(f"[Render] compositor skipped: {exc}")

size = math.ceil(ep.total / total)
first = idx * size + 1
last = min(ep.total, (idx + 1) * size)
FRAMES.mkdir(parents=True, exist_ok=True)
print(f"[Render] {r.engine} chunk {idx + 1}/{total}: frames {first}-{last} at {r.resolution_x}x{r.resolution_y}")
t0 = time.time()
done = 0
for f in range(first, last + 1):
    out = FRAMES / f"frame_{f:04d}.png"
    if out.exists() and out.stat().st_size > 1000:
        continue                                  # resume support
    ep.update(f - 1)
    scene.frame_set(f)
    r.filepath = str(out)
    bpy.ops.render.render(write_still=True)
    done += 1
    if done % 10 == 0:
        el = time.time() - t0
        print(f"[Render] {f}/{last}  {el / done:.1f}s/frame  ETA {(last - f) * el / done / 60:.0f} min", flush=True)
print(f"[Render] chunk done in {(time.time() - t0) / 60:.1f} min")
