"""Drives a professional rigged character (cahier des charges convention).

Pure Python (no bpy / mathutils import): works on Blender objects through their attributes,
so the math can be tested outside Blender.

noury_anim.py computes the SAME pose parameters as for the procedural characters; this module
converts them into bone rotations and shape keys:
  - limbs: target direction in character space -> minimal rotation from the rest direction
  - spine / head / eyes: rotation in character space conjugated into the bone rest frame
  - face: expression + viseme shape keys
"""
import math


# ------------------------------------------------------------------ quaternions (w, x, y, z)
def q_mul(a, b):
    aw, ax, ay, az = a
    bw, bx, by, bz = b
    return (aw * bw - ax * bx - ay * by - az * bz,
            aw * bx + ax * bw + ay * bz - az * by,
            aw * by - ax * bz + ay * bw + az * bx,
            aw * bz + ax * by - ay * bx + az * bw)


def q_conj(q):
    return (q[0], -q[1], -q[2], -q[3])


def q_norm(q):
    n = math.sqrt(sum(c * c for c in q)) or 1.0
    return tuple(c / n for c in q)


def q_axis(axis, angle):
    s = math.sin(angle / 2)
    return (math.cos(angle / 2), axis[0] * s, axis[1] * s, axis[2] * s)


def q_euler_xyz(x, y, z):
    """Blender 'XYZ' euler: R = Rz @ Ry @ Rx."""
    return q_mul(q_axis((0, 0, 1), z), q_mul(q_axis((0, 1, 0), y), q_axis((1, 0, 0), x)))


def q_rotate(q, v):
    p = q_mul(q_mul(q, (0.0, v[0], v[1], v[2])), q_conj(q))
    return (p[1], p[2], p[3])


def q_between(a, b):
    """Shortest rotation taking unit vector a to unit vector b."""
    d = a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
    if d < -0.999999:
        axis = (1.0, 0.0, 0.0) if abs(a[0]) < 0.9 else (0.0, 1.0, 0.0)
        c = (a[1] * axis[2] - a[2] * axis[1], a[2] * axis[0] - a[0] * axis[2], a[0] * axis[1] - a[1] * axis[0])
        return q_norm((0.0,) + c)
    c = (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])
    return q_norm((1.0 + d,) + c)


def q_from_matrix(m):
    """Rotation part of a 3x3 / 4x4 matrix (rows)."""
    m00, m01, m02 = m[0][0], m[0][1], m[0][2]
    m10, m11, m12 = m[1][0], m[1][1], m[1][2]
    m20, m21, m22 = m[2][0], m[2][1], m[2][2]
    tr = m00 + m11 + m22
    if tr > 0:
        s = math.sqrt(tr + 1.0) * 2
        q = (0.25 * s, (m21 - m12) / s, (m02 - m20) / s, (m10 - m01) / s)
    elif m00 > m11 and m00 > m22:
        s = math.sqrt(1.0 + m00 - m11 - m22) * 2
        q = ((m21 - m12) / s, 0.25 * s, (m01 + m10) / s, (m02 + m20) / s)
    elif m11 > m22:
        s = math.sqrt(1.0 + m11 - m00 - m22) * 2
        q = ((m02 - m20) / s, (m01 + m10) / s, 0.25 * s, (m12 + m21) / s)
    else:
        s = math.sqrt(1.0 + m22 - m00 - m11) * 2
        q = ((m10 - m01) / s, (m02 + m20) / s, (m12 + m21) / s, 0.25 * s)
    return q_norm(q)


def normalize(v):
    n = math.sqrt(sum(c * c for c in v)) or 1.0
    return tuple(c / n for c in v)


VISEMES = "ABCDEFGH"


class ProActor:
    def __init__(self, rig, face, name):
        self.rig, self.face, self.name = rig, face, name
        self.pb = rig.pose.bones
        self.rest_q, self.rest_dir = {}, {}
        for pb in self.pb:
            m = [list(row) for row in pb.bone.matrix_local]
            self.rest_q[pb.name] = q_from_matrix(m)
            self.rest_dir[pb.name] = normalize((m[0][1], m[1][1], m[2][1]))     # bone Y axis
            pb.rotation_mode = "QUATERNION"
        self.keys = face.data.shape_keys.key_blocks if face is not None and face.data.shape_keys else None
        self.hair = [n for n in (f"hair_0{i}" for i in range(1, 10)) if n in self.pb]

    def _rot_world(self, bone, q_arm):
        """Apply rotation q_arm (armature space) to a bone at its rest frame."""
        if bone not in self.pb:
            return
        r = self.rest_q[bone]
        self.pb[bone].rotation_quaternion = q_norm(q_mul(q_mul(q_conj(r), q_arm), r))

    def _aim(self, bone, direction):
        if bone in self.pb:
            self._rot_world(bone, q_between(self.rest_dir[bone], normalize(direction)))

    def _key(self, name, value):
        if self.keys is not None and name in self.keys:
            self.keys[name].value = max(0.0, min(1.0, value))

    # -------------------------------------------------- body
    def pose(self, root_pos, p, t, wind, phase):
        self.rig.location = root_pos
        self.rig.rotation_euler = (0.0, 0.0, p["psi"])
        st = p.get("stretch", 1.0)
        self.rig.scale = (1.0 / math.sqrt(st), 1.0 / math.sqrt(st), st)
        if "hips" in self.pb:
            self.pb["hips"].location = q_rotate(q_conj(self.rest_q["hips"]), (0.0, 0.0, p["body_y"]))
        self._rot_world("spine", q_euler_xyz(p["lean"] * 0.6, p["side"] * 0.6, 0.0))
        self._rot_world("chest", q_euler_xyz(p["lean"] * 0.4, p["side"] * 0.4 + math.sin(t * 1.7 + phase) * 0.015, 0.0))
        down = (0.0, 0.0, -1.0)
        self._aim("upperarm_L", q_rotate(q_euler_xyz(-p["al"][0], p["al"][1], 0.0), down))
        self._aim("upperarm_R", q_rotate(q_euler_xyz(-p["ar"][0], -p["ar"][1], 0.0), down))
        for s in ("L", "R"):
            self._rot_world(f"forearm_{s}", q_axis((1, 0, 0), -0.25))      # natural elbow bend
        self._aim("thigh_L", q_rotate(q_euler_xyz(-p["ll"], 0.03, 0.0), down))
        self._aim("thigh_R", q_rotate(q_euler_xyz(-p["lr"], -0.03, 0.0), down))
        for s, k in (("L", p["ll"]), ("R", p["lr"])):               # knee bends when the leg swings back
            self._rot_world(f"shin_{s}", q_axis((1, 0, 0), max(0.0, -k) * 1.2 + (0.6 if abs(k) > 1.0 else 0.0)))
        drag = max(-0.15, min(0.15, p.get("vel", 0.0) * 0.12))
        for i, h in enumerate(self.hair):
            self._rot_world(h, q_euler_xyz(math.sin(t * 2.6 + phase + i) * 0.03 * (0.4 + wind) - drag,
                                           wind * 0.08 + math.sin(t * 3.4 + phase + i) * 0.05 * (0.3 + wind), 0.0))

    # -------------------------------------------------- face
    def face_pose(self, head_euler, eye_euler, f, eye_open, blink, smile, mouth_open, vis):
        self._rot_world("head", q_euler_xyz(*head_euler))
        self._rot_world("neck", q_euler_xyz(head_euler[0] * 0.3, 0.0, head_euler[2] * 0.3))
        for s in ("L", "R"):
            self._rot_world(f"eye_{s}", q_euler_xyz(*eye_euler))
        closed = 1.0 - max(0.0, min(1.0, eye_open))
        self._key("blink_L", closed)
        self._key("blink_R", closed)
        self._key("eyes_wide", (eye_open - 1.0) * 4.0)
        self._key("squint", (f["smile"] - 0.6) * 1.5)
        self._key("smile", smile)
        self._key("frown", -smile)
        self._key("brow_up", f["brow_y"] / 0.035)
        self._key("brow_worried", f["brow_tilt"])
        self._key("brow_down", -f["brow_tilt"])
        talking = sum(vis.values()) > 0.05
        for v in VISEMES:
            self._key(f"vis_{v}", vis.get(v, 0.0))
        if not talking:                                  # silent open mouth (wonder, fear)
            self._key("vis_C", mouth_open)
