"""Noury animation brain for Blender (pure Python - no bpy import).

Everything is computed from the frame number only (stateless), so any chunk of frames can be
rendered on any machine and still match perfectly.

Blender axes: X = right, Y = depth (camera stands on -Y), Z = up.
Characters face -Y (towards the camera) when their root rotation is 0;
facing direction for a rotation psi is (sin psi, -cos psi).

Actors
  hero    Yakine, Nour (procedural or artist rig)
  human   secondary humans (procedural or artist rig) - same body / face engine as the heroes
  animal  cat, dog, rabbit, bird, owl (procedural)
"""
import json
import math
import random
from pathlib import Path


# ------------------------------------------------------------------ math
def clamp(x, a, b):
    return a if x < a else (b if x > b else x)


def lerp(a, b, k):
    return a + (b - a) * k


def smooth(e0, e1, x):
    if e1 == e0:
        return 1.0 if x >= e1 else 0.0
    k = clamp((x - e0) / (e1 - e0), 0.0, 1.0)
    return k * k * (3.0 - 2.0 * k)


def lighten(c, k):
    return tuple(lerp(v, 1.0, k) for v in c)


def darken(c, k):
    return tuple(v * (1.0 - k) for v in c)


def terrain_h(x, y, coast):
    """Ground height. Flat play area around the origin, hills / sea behind."""
    z = -y
    d = math.hypot(x, z * 1.4)
    k = smooth(6.0, 16.0, d)
    if coast:
        dunes = (math.sin(x * 0.35) * 0.3 + math.cos(z * 0.4) * 0.2 + 0.3) * k
        return dunes - max(0.0, -z - 6.0) * 0.12
    h = math.sin(x * 0.21) * 1.2 + math.cos(z * 0.27 + 1.3) * 1.0 + math.sin((x + z) * 0.11) * 1.6
    h = (h + 2.6) * 0.55
    return k * h + max(0.0, -z - 10.0) * 0.2


def rot_z(v, a):
    c, s = math.cos(a), math.sin(a)
    return (v[0] * c - v[1] * s, v[0] * s + v[1] * c, v[2])


def add(a, b):
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def scale(a, k):
    return (a[0] * k, a[1] * k, a[2] * k)


def length(a):
    return math.sqrt(a[0] ** 2 + a[1] ** 2 + a[2] ** 2)


def face_towards(src, dst, k=1.0):
    """Root rotation psi so that the character at src faces dst (k < 1 keeps it a bit towards camera)."""
    return math.atan2(dst[0] - src[0], -(dst[1] - src[1])) * k


def sky_mood(pal):
    """Which HDRI lights a location: night, storm, sunset (magic) or day."""
    if pal.get("night"):
        return "night"
    if pal.get("storm"):
        return "storm"
    if pal.get("glow"):
        return "sunset"
    return "day"


# guest placement around the heroes (x offset from the group centre, y depth)
SLOTS = {"right": (2.0, 0.25), "left": (-2.0, 0.25), "back": (0.3, 1.7), "far": (3.6, 3.2),
         "near": (1.45, -0.45), "follow": (-1.6, 0.5)}
SMALL_SLOTS = {"right": (1.7, -0.1), "left": (-1.7, -0.1), "near": (1.3, -0.5), "follow": (-1.4, 0.2)}
FACE_FWD = {"cat": 0.24, "dog": 0.27, "rabbit": 0.2, "bird": 0.06, "owl": 0.04}
CALM_ACTIONS = ("look_around", "meet_guest", "talk_together", "plant_seed")


# ------------------------------------------------------------------ episode
class Episode:
    def __init__(self, export_dir):
        ex = Path(export_dir)

        def rd(n):
            p = ex / n
            return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}

        s = rd("script_config.json")
        self.scenes = s["scenes"]
        self.fps = int(s.get("fps", 24))
        self.duration = int(s.get("duration_seconds", 240))
        self.total = self.fps * self.duration
        self.object_type = s.get("magic_object", "seed")
        self.pal = rd("sets_config.json").get("environments", {})
        e = rd("expression_config.json")
        self.presets = e.get("presets", {})
        self.etl = e.get("timeline", [])
        lp = rd("lipsync.json")
        self.lip_values = lp.get("values", [])
        self.lip_speakers = lp.get("speakers", [])
        self.visemes = lp.get("visemes", "")
        self.lines = sorted(lp.get("lines", []))
        self.cfgs = rd("actors_config.json").get("characters", [])
        if not self.cfgs:
            self.cfgs = [{"key": "Yakine", "kind": "hero", "height": 0.97, "head_h": 1.35},
                         {"key": "Nour", "kind": "hero", "height": 1.0, "head_h": 1.35}]
        self.blinks = []
        for i in range(len(self.cfgs)):
            r = random.Random(1000 + i * 31)
            bt, lst = r.uniform(0.5, 2.0), []
            while bt < self.duration + 5:
                lst.append(bt)
                if r.random() < 0.15:
                    lst.append(bt + 0.28)
                bt += r.uniform(2.2, 5.0)
            self.blinks.append(lst)
        r = random.Random(99)
        self.firefly_seed = [(r.uniform(-7, 7), r.uniform(-1.5, 7), r.uniform(0.3, 2.2), r.uniform(0, 6.3))
                             for _ in range(60)]
        self.snow_seed = [(r.uniform(-9, 9), r.uniform(-3, 8), r.uniform(0, 7), r.uniform(0.4, 0.9))
                          for _ in range(220)]

    # -------------------------------------------------------------- binding
    def bind(self, get_obj, get_node, get_coll):
        self.O, self.N, self.C = get_obj, get_node, get_coll
        self.actors = []
        for i, c in enumerate(self.cfgs):
            k = c["key"]
            g = lambda part, k=k: get_obj(f"{k}_{part}")
            a = {"key": k, "name": c.get("name", k), "kind": c.get("kind", "hero"), "idx": i,
                 "h": float(c.get("height", 1.0)), "head_h": float(c.get("head_h", 1.35)),
                 "species": c.get("species"), "pro": None,
                 "coll": None if c.get("kind", "hero") == "hero" else get_coll(k)}
            if a["kind"] == "animal":
                a["o"] = {p: g(p) for p in ("root", "body", "head", "jaw", "inner", "tail", "ear_L", "ear_R",
                                              "wing_L", "wing_R", "look_L", "look_R", "lid_L", "lid_R",
                                              "leg_0", "leg_1", "leg_2", "leg_3")}
            else:
                rig = get_obj(f"{k}_rig")
                if rig is not None:                   # artist character
                    from pro_rig import ProActor
                    a["pro"] = ProActor(rig, get_obj(f"{k}_face"), k)
                else:
                    a.update({
                        "root": g("root"), "body": g("body"), "spine": g("spine"), "head": g("head"),
                        "arm_L": g("arm_L"), "arm_R": g("arm_R"), "leg_L": g("leg_L"), "leg_R": g("leg_R"),
                        "sway": g("sway"), "mouth": g("mouth"), "inner": g("inner"),
                        "eyes": [(g(f"look_{s}"), g(f"lid_{s}"), g(f"low_{s}")) for s in ("L", "R")],
                        "brows": [(g("brow_L"), -1.0), (g("brow_R"), 1.0)],
                    })
            self.actors.append(a)
        self.by_key = {a["key"]: a for a in self.actors}
        self.cam = get_obj("cam")
        self.sun, self.rim, self.fill = get_obj("sun"), get_obj("rim"), get_obj("fill")
        self.magic, self.magic_light = get_obj("magic"), get_obj("magic_light")
        self.bloom, self.bloom_light = get_obj("bloom"), get_obj("bloom_light")
        self.water = get_obj("water")
        grab = lambda prefix, n: [o for o in (get_obj(f"{prefix}_{i}") for i in range(n)) if o is not None]
        self.sparkles = grab("sparkle", 40)
        self.trees = grab("tree", 80) + grab("pine", 80) + grab("palm", 40)
        self.clouds = grab("cloud", 20)
        self.fireflies = grab("firefly", 60)
        self.snow = grab("snow", 220)
        self.cloud_base = [tuple(c.location) for c in self.clouds]
        self.tree_base = [tuple(t.rotation_euler) for t in self.trees]

    # -------------------------------------------------------------- lookups
    def scene_index(self, t):
        for i, s in enumerate(self.scenes):
            if s["start"] <= t < s["end"]:
                return i
        return len(self.scenes) - 1

    def palette(self, name):
        p = self.pal.get(name, self.pal.get("meadow", {}))
        return p if isinstance(p, dict) else {}

    def emotion_at(self, key, t):
        for it in self.etl:
            if it["start"] <= t < it["end"]:
                return it.get(key, "neutral")
        return "neutral"

    def face_target(self, key, t):
        d = self.presets.get(self.emotion_at(key, t), self.presets.get("neutral", {}))
        keys = {"eye_open": 1.0, "brow_y": 0.0, "brow_tilt": 0.0, "smile": 0.3, "mouth_open": 0.0, "head_tilt": 0.0}
        return {k: float(d.get(k, v)) for k, v in keys.items()}

    def lip(self, frame, key):
        if frame < 0 or frame >= len(self.lip_values):
            return 0.0
        if frame < len(self.lip_speakers) and self.lip_speakers[frame] != key:
            return 0.0
        return float(self.lip_values[frame])

    def line_at(self, t, pad=0.0):
        for s, e, k in self.lines:
            if s <= t < e + pad:
                return s, e, k
        return None

    def last_line(self, t, since):
        best = None
        for s, e, k in self.lines:
            if s >= since and e <= t:
                best = (s, e, k)
        return best

    def talk_weight(self, key, t):
        ln = self.line_at(t)
        if not ln or ln[2] != key:
            return 0.0
        return smooth(ln[0], ln[0] + 0.3, t) * (1.0 - smooth(ln[1] - 0.2, ln[1] + 0.3, t))

    def blink(self, idx, t):
        for bt in self.blinks[idx]:
            d = t - bt
            if d < -0.01:
                break
            if 0.0 <= d < 0.17:
                return d / 0.06 if d < 0.06 else 1.0 - (d - 0.06) / 0.11
        return 0.0

    # Rhubarb mouth shapes -> (opening, width, roundness)
    VISEME = {"X": (0.0, 1.0, 0.0), "A": (0.0, 0.92, 0.0), "B": (0.22, 1.05, 0.0), "C": (0.5, 1.05, 0.0),
              "D": (0.95, 1.0, 0.0), "E": (0.55, 0.78, 0.55), "F": (0.28, 0.58, 1.0), "G": (0.14, 0.98, 0.0),
              "H": (0.6, 0.95, 0.0)}

    def mouth_shape(self, frame, key):
        if not self.visemes:
            return None
        if frame < len(self.lip_speakers) and self.lip_speakers[frame] != key:
            return (0.0, 1.0, 0.0)
        acc = [0.0, 0.0, 0.0]
        for off, w in ((-1, 0.25), (0, 0.5), (1, 0.25)):
            f = min(max(frame + off, 0), len(self.visemes) - 1)
            v = self.VISEME.get(self.visemes[f], self.VISEME["X"])
            for k in range(3):
                acc[k] += v[k] * w
        return tuple(acc)

    def viseme_weights(self, frame, key, lip):
        if frame < len(self.lip_speakers) and self.lip_speakers[frame] != key:
            return {}
        if not self.visemes:
            return {"C": lip} if lip > 0.05 else {}
        w = {}
        for off, k in ((-1, 0.25), (0, 0.5), (1, 0.25)):
            v = self.visemes[min(max(frame + off, 0), len(self.visemes) - 1)]
            if v != "X":
                w[v] = w.get(v, 0.0) + k
        return w

    def face_point(self, a, root_pos, psi, body_y):
        if a["kind"] == "animal":
            fwd = FACE_FWD.get(a["species"], 0.2) * a["h"]
            local = (0.0, -fwd, a["head_h"] * a["h"] + body_y)
        else:
            local = (0.0, -0.1 * a["h"], a["head_h"] * a["h"] + body_y)
        return add(root_pos, rot_z(local, psi))

    # -------------------------------------------------------------- frame
    def update(self, frame):
        t = frame / float(self.fps)                     # frame may be fractional (motion blur)
        frame = int(math.floor(frame + 1e-6))
        si = self.scene_index(t)
        sc = self.scenes[si]
        local = t - sc["start"]
        prog = clamp(local / max(1.0, sc["end"] - sc["start"]), 0.0, 1.0)
        action = sc["action"]
        env_name = sc["environment"]
        pal = self.palette(env_name)
        wind = float(pal.get("wind", 0.1))
        self.apply_env(pal, t, wind)

        center = self.center_x(action, prog)
        heroes_moving = (action == "approach_seed" and prog < 0.6) or action == "run_together" \
            or (action == "meet_guest" and prog < 0.35)
        y_shift = 0.0
        if action == "help_friend":
            y_shift = 0.35 * smooth(5.0, 8.0, local) * (1.0 - smooth(18.0, 21.0, local))
        guests = {g["key"]: g for g in sc.get("guests", []) if g["key"] in self.by_key}

        chars = {}         # key -> {pos, psi, p, face, small}
        for a in self.actors[:2]:
            i = a["idx"]
            pos = (center + (-0.72 + y_shift if i == 0 else 0.72), 0.0 if i == 0 else -0.12, 0.0)
            p = self.pose(i, t, local, prog, action, wind, guests)
            self.add_dynamics(i, t, sc, p)
            chars[a["key"]] = {"pos": pos, "p": p, "a": a}
        hero_mid = ((chars[self.actors[0]["key"]]["pos"][0] + chars[self.actors[1]["key"]]["pos"][0]) * 0.5, -0.06, 0)

        for a in self.actors[2:]:
            g = guests.get(a["key"])
            if a["coll"] is not None:
                a["coll"].hide_render = g is None
            if g is None:
                continue
            pos, psi, moving, run = self.guest_place(a, g, t, local, center, hero_mid, action, prog, heroes_moving)
            if a["kind"] == "animal":
                chars[a["key"]] = {"pos": pos, "psi": psi, "moving": moving, "run": run, "g": g, "a": a,
                                   "p": {"psi": psi, "body_y": 0.0}}
            else:
                p = self.guest_pose(a, g, t, local, psi, moving, run)
                chars[a["key"]] = {"pos": pos, "p": p, "a": a, "g": g}

        # heroes turn towards a guest during meetings / conversations
        main_guest = next((k for k, c in chars.items() if "g" in c and c["g"]["slot"] not in ("far", "back")), None)
        if main_guest and action in ("meet_guest", "talk_together") and not (action == "meet_guest" and prog < 0.35):
            for a in self.actors[:2]:
                c = chars[a["key"]]
                c["p"]["psi"] = face_towards(c["pos"], chars[main_guest]["pos"], 0.7)

        # talking gestures (calm scenes)
        if action in CALM_ACTIONS:
            for k, c in chars.items():
                if c["a"]["kind"] == "animal":
                    continue
                w = self.talk_weight(k, t)
                if w > 0:
                    ph = c["a"]["idx"] * 1.7
                    ar = c["p"]["ar"]
                    c["p"]["ar"] = (lerp(ar[0], 0.75 + 0.25 * math.sin(t * 3.1 + ph), w),
                                    lerp(ar[1], 0.35 + 0.15 * math.sin(t * 2.3 + ph), w))
                    al = c["p"]["al"]
                    c["p"]["al"] = (lerp(al[0], 0.35 + 0.2 * math.sin(t * 2.7 + ph + 1.0), w * 0.6), al[1])

        for k, c in chars.items():
            c["face"] = self.face_point(c["a"], c["pos"], c["p"]["psi"], c["p"]["body_y"])

        obj_pos, obj_visible = self.object_motion(sc, action, local, prog, t, center, chars)
        bloom_s = 0.0
        if sc.get("bloom", True):
            if action == "plant_seed":
                bloom_s = smooth(0.7, 1.0, prog) * 0.35
            elif action == "celebrate":
                bloom_s = 0.35 + smooth(0.0, 0.25, prog) * 0.65
        self.apply_magic(obj_pos, obj_visible, bloom_s, t)
        bloom_top = (0.0, 0.9, 1.5 * max(bloom_s, 0.3))

        line = self.line_at(t)
        speaker = line[2] if line and line[2] in chars else None
        for k, c in chars.items():
            a = c["a"]
            target = self.gaze_target(k, c, chars, speaker, action, local, t, center, obj_pos, obj_visible,
                                      bloom_top, bloom_s)
            if a["kind"] == "animal":
                self.apply_animal(a, c, t, frame, target, wind)
            else:
                self.apply_pose(a, c["pos"], c["p"], t, wind)
                self.apply_face(a, t, frame, c["face"], c["p"], target)

        self.apply_camera(si, sc, local, prog, action, t, chars, line)

    # -------------------------------------------------------------- placement
    @staticmethod
    def center_x(action, prog):
        if action == "approach_seed":
            return lerp(-2.4, 0.0, smooth(0.0, 0.6, prog))
        if action == "run_together":
            return lerp(-3.5, 3.5, prog)
        if action == "meet_guest":
            return lerp(-1.6, -0.3, smooth(0.0, 0.35, prog))
        return 0.0

    def guest_place(self, a, g, t, local, center, hero_mid, action, prog, heroes_moving):
        small = a["kind"] == "animal" and a["species"] != "owl"
        sx, sy = (SMALL_SLOTS.get(g["slot"]) if small else None) or SLOTS.get(g["slot"], SLOTS["right"])
        x, y = center + sx, sy
        moving, run, psi = False, False, None
        if g["act"] == "enter":
            side = 1.0 if sx >= 0 else -1.0
            k = smooth(0.0, 3.0, local)
            x = lerp(x + side * 5.0, x, k)
            moving = local < 3.0
            if moving:
                psi = -0.9 * side
        elif g["slot"] == "follow":
            moving = heroes_moving
            run = action == "run_together"
            if moving:
                psi = 0.85
        if action == "help_friend" and g["slot"] == "left":
            x -= 0.4
        z = 0.0
        if a["species"] == "bird":
            z = (0.85 if g["act"] == "hide" else 1.3) + 0.08 * math.sin(t * 2.2 + a["idx"])
        pos = (x, y, z)
        if psi is None:
            psi = face_towards(pos, hero_mid, 0.75)
        return pos, psi, moving, run

    # -------------------------------------------------------------- dynamics (heroes)
    def pose_at(self, idx, t, sc, guests):
        t = clamp(t, sc["start"], sc["end"] - 1e-3)
        local = t - sc["start"]
        prog = clamp(local / max(1.0, sc["end"] - sc["start"]), 0.0, 1.0)
        wind = float(self.palette(sc["environment"]).get("wind", 0.1))
        return self.pose(idx, t, local, prog, sc["action"], wind, guests)

    def add_dynamics(self, idx, t, sc, p):
        """Follow-through (arms trail), squash & stretch (jumps), drag (hair) - computed without state."""
        guests = {g["key"]: g for g in sc.get("guests", [])}
        h = 1.0 / 48.0
        y0 = self.pose_at(idx, t - h, sc, guests)["body_y"]
        y2 = self.pose_at(idx, t + h, sc, guests)["body_y"]
        vel = (y2 - y0) / (2 * h)
        acc = (y2 - 2 * p["body_y"] + y0) / (h * h)
        lag = self.pose_at(idx, t - 0.08, sc, guests)
        for k in ("al", "ar"):
            p[k] = (lerp(p[k][0], lag[k][0], 0.45), lerp(p[k][1], lag[k][1], 0.45))
        stretch = 1.0 + clamp(abs(vel) * 0.07, 0.0, 0.08) - clamp(acc * 0.0025, 0.0, 0.1)
        p["stretch"] = clamp(stretch, 0.88, 1.1)
        p["vel"] = vel

    # -------------------------------------------------------------- hero pose
    def pose(self, idx, t, local, prog, action, wind, guests=None):
        ph = idx * 0.9
        side = 1.0 if idx == 0 else -1.0       # Yakine turns to +X (towards Nour)
        p = {"body_y": 0.0, "lean": 0.0, "side": 0.0, "al": (math.sin(t * 1.3 + ph) * 0.05, 0.12),
             "ar": (-math.sin(t * 1.3 + ph) * 0.05, 0.12), "ll": 0.0, "lr": 0.0, "psi": 0.25 * side}
        moving = (action == "approach_seed" and prog < 0.6) or action == "run_together" \
            or (action == "meet_guest" and prog < 0.35)
        run = action == "run_together"
        if moving:
            f, amp = (10.0, 0.8) if run else (6.5, 0.5)
            s = math.sin(t * f + ph)
            p["ll"], p["lr"] = s * amp, -s * amp
            p["al"], p["ar"] = (-s * amp * 0.9, 0.15), (s * amp * 0.9, 0.15)
            p["body_y"] = abs(math.cos(t * f + ph)) * (0.08 if run else 0.035)
            p["lean"] = 0.2 if run else 0.06
            p["psi"] = 0.85
        if action == "look_around":
            if idx == 0 and 3.0 < local < 8.0:
                p["ar"] = (1.45 * smooth(3.0, 3.5, local) * (1 - smooth(7.5, 8.0, local)), 0.15)
            if idx == 1 and 10.0 < local < 14.0:
                p["al"] = (0.6, 0.5)
        elif action == "approach_seed":
            r = smooth(0.6, 0.72, prog)
            p["psi"] = lerp(0.85, 0.15 * side, r)
            if r > 0:
                if idx == 0:
                    p["ar"] = (1.1 * r, 0.1)
                else:
                    p["al"] = (0.5 * r, -0.1)
        elif action == "meet_guest":
            k = smooth(0.4, 0.5, prog) * (1.0 - smooth(0.85, 0.95, prog))
            small = any(self.by_key.get(g, {}).get("kind") == "animal" for g in (guests or {}))
            if idx == 1:                                   # Nour, closest to the guest, reaches out
                p["lean"] = (0.35 if small else 0.12) * k
                p["body_y"] = (-0.12 if small else 0.0) * k
                p["ar"] = (lerp(p["ar"][0], 0.9, k), lerp(0.12, 0.15, k))
            else:
                p["lean"] = 0.1 * k
                p["al"] = (lerp(p["al"][0], 0.5, k), lerp(0.12, -0.1, k))
        elif action == "talk_together":
            p["side"] = math.sin(t * 0.9 + ph) * 0.03
        elif action == "brace_wind":
            j = math.sin(t * 11.0 + ph) * 0.03 * wind
            p.update(side=-0.12 - j, lean=0.12, body_y=-0.03, psi=0.1 * side)
            if idx == 0:
                p["al"], p["ar"] = (1.9, 0.35), (0.4, 1.1)
            else:
                p["al"], p["ar"] = (2.0, 0.3), (2.0, 0.3)
        elif action == "help_friend":
            if idx == 1:
                down = smooth(2.0, 3.0, local) * (1.0 - smooth(15.0, 17.5, local))
                p.update(body_y=-0.3 * down, ll=1.35 * down, lr=1.25 * down, lean=-0.25 * down, psi=-0.45)
                p["al"] = (lerp(p["al"][0], -0.4, down), lerp(0.12, 0.6, down))
                p["ar"] = (lerp(p["ar"][0], -0.4, down), lerp(0.12, 0.6, down))
                if 10.0 < local < 17.5:
                    p["al"] = (lerp(p["al"][0], 1.0, smooth(10.0, 11.0, local)), 0.25)
            else:
                reach = smooth(8.0, 10.0, local) * (1.0 - smooth(17.0, 19.0, local))
                p.update(lean=0.25 * reach, psi=0.5)
                p["ar"] = (lerp(p["ar"][0], 1.0, reach), lerp(0.12, 0.45, reach))
        elif action == "run_together":
            if idx == 0:
                p["ar"] = (0.25, 0.55)
            else:
                p["al"] = (0.25, 0.55)
        elif action == "protect_seed":
            j2 = math.sin(t * 9.0 + ph) * 0.02
            p.update(lean=0.2, body_y=-0.04, psi=0.35 * side)
            if idx == 0:
                p["ar"], p["al"] = (1.2 + j2, -0.35), (0.9, 0.1)
            else:
                p["al"], p["ar"] = (1.2 - j2, -0.35), (0.9, 0.1)
        elif action == "plant_seed":
            bend = smooth(0.0, 0.15, prog) * (1.0 - smooth(0.68, 0.82, prog))
            p.update(lean=0.6 * bend, body_y=-0.06 * bend, psi=0.3 * side)
            p["al"] = (lerp(p["al"][0], 1.0, bend), lerp(0.12, -0.1, bend))
            p["ar"] = (lerp(p["ar"][0], 1.0, bend), lerp(0.12, -0.1, bend))
        elif action == "celebrate":
            jump = max(0.0, math.sin(t * 6.0 + ph * 1.4))
            wave = math.sin(t * 8.0 + ph) * 0.2
            p.update(body_y=jump * 0.26, ll=-jump * 0.25, lr=jump * 0.25, psi=math.sin(t * 1.5 + ph) * 0.3)
            p["al"], p["ar"] = (0.3, 2.5 + wave), (0.3, 2.5 - wave)
        return p

    # -------------------------------------------------------------- human guest pose
    def guest_pose(self, a, g, t, local, psi, moving, run):
        ph = a["idx"] * 1.3
        p = {"body_y": 0.0, "lean": 0.0, "side": 0.0, "al": (math.sin(t * 1.2 + ph) * 0.04, 0.1),
             "ar": (-math.sin(t * 1.2 + ph) * 0.04, 0.1), "ll": 0.0, "lr": 0.0, "psi": psi}
        act = g["act"]
        if moving:
            f, amp = (10.0, 0.75) if run else (6.0, 0.45)
            s = math.sin(t * f + ph)
            p["ll"], p["lr"] = s * amp, -s * amp
            p["al"], p["ar"] = (-s * amp * 0.8, 0.12), (s * amp * 0.8, 0.12)
            p["body_y"] = abs(math.cos(t * f + ph)) * (0.07 if run else 0.03)
            p["lean"] = 0.15 if run else 0.05
            return p
        if act == "sad":
            p.update(lean=0.12)
            p["al"], p["ar"] = (0.15, 0.02), (0.15, 0.02)
        elif act == "hide":
            p.update(lean=-0.1, body_y=-0.03)
            p["al"], p["ar"] = (1.6, 0.3), (1.6, 0.3)
        elif act == "wave" or (act == "enter" and 3.0 < local < 5.5):
            p["ar"] = (0.3, 2.6 + math.sin(t * 8.0) * 0.3)
        elif act == "cheer":
            jump = max(0.0, math.sin(t * 5.0 + ph))
            wave = math.sin(t * 7.0 + ph) * 0.2
            p.update(body_y=jump * 0.12)
            p["al"], p["ar"] = (0.3, 2.3 + wave), (0.3, 2.3 - wave)
        return p

    # -------------------------------------------------------------- gaze
    def gaze_target(self, k, c, chars, speaker, action, local, t, center, obj_pos, obj_visible, bloom_top, bloom_s):
        heroes = [x["key"] for x in self.actors[:2]]
        others = [o for o in chars if o != k]
        nearest = min(others, key=lambda o: length(sub(chars[o]["pos"], c["pos"]))) if others else k
        if speaker and speaker != k:
            return chars[speaker]["face"]
        if speaker == k:                               # talking: look at the main listener
            if k in heroes:
                guest = next((o for o in others if o not in heroes), None)
                return chars[guest]["face"] if guest and action in CALM_ACTIONS else chars[nearest]["face"]
            return chars[min(heroes, key=lambda o: length(sub(chars[o]["pos"], c["pos"])))]["face"]
        if k in heroes:
            looks_obj = action in ("look_around", "approach_seed", "protect_seed", "plant_seed", "brace_wind")
            if action == "celebrate":
                looks_obj = (t % 6.0) < 3.0
            if looks_obj and (obj_visible or bloom_s > 0):
                return obj_pos if obj_visible else bloom_top
            if action == "look_around" and local < 2.5:
                return (math.sin(t * 0.8) * 4.0 + center, 4.0, 1.4)
            guest = next((o for o in others if o not in heroes), None)
            if guest and action in ("meet_guest", "talk_together", "look_around"):
                return chars[guest]["face"]
            return chars[heroes[1] if k == heroes[0] else heroes[0]]["face"]
        if obj_visible and c["g"]["act"] != "hide" and int(t / 4.0) % 2 == 0:
            return obj_pos
        return chars[min(heroes, key=lambda o: length(sub(chars[o]["pos"], c["pos"])))]["face"]

    # -------------------------------------------------------------- apply humans
    def apply_pose(self, a, root_pos, p, t, wind):
        ph = a["idx"] * 0.9
        if a.get("pro"):
            a["pro"].pose(root_pos, p, t, wind, ph)
            return
        a["root"].location = root_pos
        a["root"].rotation_euler = (0.0, 0.0, p["psi"])
        a["body"].location = (0.0, 0.0, p["body_y"])
        st = p.get("stretch", 1.0)
        a["body"].scale = (1.0 / math.sqrt(st), 1.0 / math.sqrt(st), st)
        a["spine"].rotation_euler = (p["lean"], p["side"] + math.sin(t * 1.7 + ph) * 0.015, 0.0)
        a["spine"].scale = (1.0, 1.0, 1.0 + math.sin(t * 2.1 + ph) * 0.012)
        a["arm_L"].rotation_euler = (-p["al"][0], p["al"][1], 0.0)
        a["arm_R"].rotation_euler = (-p["ar"][0], -p["ar"][1], 0.0)
        a["leg_L"].rotation_euler = (-p["ll"], 0.03, 0.0)
        a["leg_R"].rotation_euler = (-p["lr"], -0.03, 0.0)
        a["sway"].rotation_euler = (math.sin(t * 2.6 + ph) * 0.02 * (0.4 + wind)
                                    - clamp(p.get("vel", 0.0) * 0.12, -0.15, 0.15),
                                    wind * 0.06 + math.sin(t * 3.4 + ph) * 0.035 * (0.3 + wind), 0.0)

    def look_angles(self, face_pos, psi, target):
        ld = rot_z(sub(target, face_pos), -psi)
        yaw = clamp(math.atan2(ld[0], -ld[1]), -0.9, 0.9)
        pitch = clamp(math.atan2(ld[2], math.hypot(ld[0], ld[1])), -0.6, 0.5)
        return yaw, pitch

    def apply_face(self, a, t, frame, face_pos, p, target):
        f = self.face_target(a["key"], t)
        lip = self.lip(frame, a["key"])
        blink = self.blink(a["idx"], t)
        eye_open = clamp(f["eye_open"] * (1.0 - blink), 0.0, 1.25)
        yaw, pitch = self.look_angles(face_pos, p["psi"], target)
        head_yaw, head_pitch = yaw * 0.6, pitch * 0.55
        nod = lip * 0.04 * math.sin(t * 9.0)
        eye_yaw = clamp(yaw - head_yaw, -0.55, 0.55)
        eye_pitch = clamp(pitch - head_pitch, -0.4, 0.4)
        if a.get("pro"):
            shape = self.mouth_shape(frame, a["key"])
            talking = (shape[0] > 0.02 or shape[2] > 0.05) if shape else lip > 0.05
            a["pro"].face_pose((-head_pitch + nod, f["head_tilt"], head_yaw), (-eye_pitch, 0.0, eye_yaw), f,
                               eye_open, blink, f["smile"] * (0.7 if talking else 1.0), f["mouth_open"],
                               self.viseme_weights(frame, a["key"], lip))
            return
        a["head"].rotation_euler = (-head_pitch + nod, f["head_tilt"], head_yaw)
        squint = max(0.0, f["smile"] - 0.6) * 0.6
        for look, lid, low in a["eyes"]:
            look.rotation_euler = (-eye_pitch, 0.0, eye_yaw)
            lid.rotation_euler = (lerp(1.571, -0.96, clamp(eye_open, 0.0, 1.0)) - max(0.0, eye_open - 1.0) * 0.8, 0.0, 0.0)
            low.rotation_euler = (4.19 - squint * 1.2 - blink * 0.3, 0.0, 0.0)
        for brow, s in a["brows"]:
            brow.location = (s * 0.125, -0.272, 0.475 + f["brow_y"] - blink * 0.008)
            brow.rotation_euler = (0.0, s * f["brow_tilt"] * 0.42, 0.0)

        smile = f["smile"]
        shape = self.mouth_shape(frame, a["key"])
        if shape is None:
            vis_open, width, rnd = lip * 0.95, 1.0 - lip * 0.16 * (0.5 + 0.5 * math.sin(t * 17.0)), 0.0
        else:
            vis_open, width, rnd = shape
        talking = vis_open > 0.02 or rnd > 0.05
        smile_eff = smile * (1.0 - 0.6 * rnd) * (0.7 if talking else 1.0)
        open_amt = clamp(max(f["mouth_open"] * (0.0 if talking else 1.0), vis_open), 0.0, 1.0)
        half = 0.075 * width
        pts = []
        for u in (-1.0, 0.0, 1.0):
            x = u * half
            z = smile_eff * 0.032 * u * u - smile_eff * 0.012 + open_amt * 0.012
            pts.append((x, x * x * 1.3, z))
        bp = a["mouth"].data.splines[0].bezier_points
        for i in range(3):
            prev_p, next_p = pts[max(0, i - 1)], pts[min(2, i + 1)]
            tan = scale(sub(next_p, prev_p), 0.25 if i == 1 else 0.33)
            bp[i].co = pts[i]
            bp[i].handle_left = sub(pts[i], tan)
            bp[i].handle_right = add(pts[i], tan)
        inner = a["inner"]
        inner.hide_render = open_amt <= 0.04
        inner.scale = ((1.15 + smile_eff * 0.25) * width * (1.0 - 0.35 * rnd), 0.3, 0.08 + open_amt * 0.85 + rnd * 0.25)
        inner.location = (0.0, 0.004, -0.01 - open_amt * 0.028 + smile_eff * 0.004)

    # -------------------------------------------------------------- apply animals
    def apply_animal(self, a, c, t, frame, target, wind):
        o = a["o"]
        sp, ph = a["species"], a["idx"] * 1.3
        emo = self.emotion_at(a["key"], t)
        f = self.face_target(a["key"], t)
        act = c["g"]["act"]
        happy = emo in ("joy", "happy", "excited") or act == "cheer"
        sad = emo in ("sad", "hurt", "worried", "fear")
        body_y, leg = 0.0, [0.0, 0.0, 0.0, 0.0]
        if c["moving"]:
            fr, amp = (12.0, 0.7) if c["run"] else (8.0, 0.5)
            if sp == "rabbit":
                hop = math.sin(t * fr * 0.6 + ph)
                body_y = abs(hop) * 0.14
                leg = [hop * 0.6, hop * 0.6, -hop * 0.8, -hop * 0.8]
            else:
                s = math.sin(t * fr + ph)
                leg = [s * amp, -s * amp, -s * amp, s * amp]
                body_y = abs(math.cos(t * fr + ph)) * 0.025
        elif act == "cheer":
            body_y = max(0.0, math.sin(t * 5.0 + ph)) * 0.12
        elif act == "hide":
            body_y = -0.04
        if sad and not c["moving"]:
            body_y -= 0.015
        o["root"].location = c["pos"]
        o["root"].rotation_euler = (0.0, 0.0, c["psi"])
        o["body"].location = (0.0, 0.0, body_y)
        for i in range(4):
            if o[f"leg_{i}"] is not None:
                o[f"leg_{i}"].rotation_euler = (leg[i], 0.0, 0.0)
        wag_speed, wag_amp = (13.0, 0.5) if happy else (3.0, 0.15)
        lift = -0.5 if sad else (0.3 if happy else 0.0)
        if o["tail"] is not None:
            o["tail"].rotation_euler = (lift, 0.0, math.sin(t * wag_speed + ph) * wag_amp)
        droop = clamp(f["brow_tilt"], 0.0, 1.0) if sad else 0.0
        twitch = 0.08 * max(0.0, math.sin(t * 0.9 + ph * 3.0)) ** 20
        if o["ear_L"] is not None:
            o["ear_L"].rotation_euler = (0.0, -droop * 0.8 - twitch, 0.0)
        if o["ear_R"] is not None:
            o["ear_R"].rotation_euler = (0.0, droop * 0.8 + twitch, 0.0)
        if sp == "bird":
            flap = 0.35 + 0.7 * math.sin(t * 28.0 + ph)
        elif sp == "owl" and act == "cheer":
            flap = 0.6 + 0.5 * math.sin(t * 9.0)
        else:
            flap = 0.0
        if o["wing_L"] is not None:
            o["wing_L"].rotation_euler = (0.0, flap, 0.0)
        if o["wing_R"] is not None:
            o["wing_R"].rotation_euler = (0.0, -flap, 0.0)
        face = c["face"]
        yaw, pitch = self.look_angles(face, c["psi"], target)
        down = 0.3 if sad else 0.0
        o["head"].rotation_euler = (-pitch * 0.7 + down, f["head_tilt"] * 0.8, yaw * 0.8)
        blink = self.blink(a["idx"], t)
        eye_open = clamp(f["eye_open"] * (1.0 - blink), 0.0, 1.25)
        for s in ("L", "R"):
            if o[f"look_{s}"] is not None:
                o[f"look_{s}"].rotation_euler = (-clamp(pitch * 0.3, -0.3, 0.3), 0.0, clamp(yaw * 0.2, -0.4, 0.4))
            if o[f"lid_{s}"] is not None:
                o[f"lid_{s}"].rotation_euler = (lerp(1.571, -0.96, clamp(eye_open, 0.0, 1.0)), 0.0, 0.0)
        lip = self.lip(frame, a["key"])
        open_amt = clamp(max(lip, f["mouth_open"] * 0.5), 0.0, 1.0)
        if o["jaw"] is not None:
            o["jaw"].rotation_euler = (open_amt * 0.45, 0.0, 0.0)
        if o["inner"] is not None:
            o["inner"].scale = (1.0, 1.0, 0.15 + open_amt * 1.2)

    # -------------------------------------------------------------- magic
    def object_motion(self, sc, action, local, prog, t, center, chars):
        if not sc.get("magic", True):
            return (0.0, 0.0, -5.0), False
        bob = math.sin(t * 2.2) * 0.06
        heroes = [chars[a["key"]]["pos"] for a in self.actors[:2]]
        if action == "look_around":
            return (0.0, -0.75, 0.45 + bob), True
        if action == "approach_seed":
            return (prog * 0.3, -0.7, 0.5 + prog * 0.5 + bob), True
        if action == "brace_wind":
            return (math.sin(t * 1.4) * 1.3, -0.5 - math.cos(t * 1.4) * 0.4, 1.1 + math.sin(t * 2.3) * 0.35), True
        if action == "help_friend":
            return (0.2, -0.4, 1.75 + bob), True
        if action == "run_together":
            return (center + 1.4, -0.35, 1.0 + bob), True
        if action == "protect_seed":
            mx = (heroes[0][0] + heroes[1][0]) * 0.5
            return (mx + math.sin(t * 9.0) * 0.03, -0.5, 0.82 + bob * 0.5), True
        if action == "plant_seed":
            return (0.0, -0.5, lerp(0.8, 0.02, smooth(0.05, 0.6, prog))), prog <= 0.7
        if action in ("meet_guest", "talk_together"):
            return (center + 0.0, -0.6, 1.4 + bob), True
        return (0.0, 0.0, -5.0), False

    def apply_magic(self, pos, visible, bloom_s, t):
        self.C("magic_set").hide_render = not visible
        self.C("sparkle_set").hide_render = not visible
        self.magic.location = pos
        self.magic.rotation_euler = (0.0, 0.0, t * 1.2)
        self.magic_light.data.energy = 40.0 + 12.0 * math.sin(t * 3.0)
        for i, sp in enumerate(self.sparkles):
            ang = t * (0.8 + (i % 5) * 0.15) + i * 0.7
            r = 0.35 + 0.2 * math.sin(i * 1.7 + t)
            sp.location = add(pos, (math.cos(ang) * r, math.sin(ang) * r, math.sin(t * 1.5 + i) * 0.25))
            sp.scale = (1.0,) * 3 if math.sin(t * 5.0 + i * 2.1) > -0.3 else (0.4,) * 3
        self.C("bloom_set").hide_render = bloom_s <= 0.002
        s = max(0.001, bloom_s) * (1.0 + 0.02 * math.sin(t * 2.0))
        self.bloom.scale = (s, s, s)
        self.bloom.rotation_euler = (0.0, 0.0, math.sin(t * 0.5) * 0.15)
        self.bloom_light.data.energy = bloom_s * 120.0

    # -------------------------------------------------------------- environment
    def _node(self, owner, name):
        try:
            return self.N(owner, name)
        except (KeyError, AttributeError, TypeError):
            return None

    def apply_env(self, pal, t, wind):
        terrain = pal.get("terrain", "coast" if pal.get("water") else "meadow")
        props = pal.get("props", [])
        snow, night = bool(pal.get("snow")), bool(pal.get("night"))
        storm, magical = bool(pal.get("storm")), bool(pal.get("glow"))
        vis = {"meadow_set": terrain == "meadow" and not snow, "coast_set": terrain == "coast",
               "water_set": bool(pal.get("water")), "grass_set": terrain == "meadow" and not snow,
               "snow_set": snow, "night_set": night}
        for prop in ("trees", "pines", "palms", "houses", "garden", "rocks", "fireflies"):
            vis[f"{prop}_set"] = prop in props
        for name, v in vis.items():
            try:
                self.C(name).hide_render = not v
            except KeyError:
                pass
        sky = tuple(pal.get("sky", (0.4, 0.67, 0.91)))
        self.N("NouryWorld", "SkyTop").outputs[0].default_value = darken(sky, 0.2) + (1.0,)
        self.N("NouryWorld", "SkyHorizon").outputs[0].default_value = lighten(sky, 0.18 if night else 0.5) + (1.0,)
        self.N("NouryWorld", "SkyBG").inputs[1].default_value = 0.55 if storm else (0.8 if magical or night else 1.0)
        # real-sky lighting (HDRI): one per mood, switched with mix nodes when the library has them
        mood = sky_mood(pal)
        for m, node in (("storm", "HdriMix_storm"), ("sunset", "HdriMix_sunset"), ("night", "HdriMix_night")):
            n = self._node("NouryWorld", node)
            if n is not None:
                n.inputs[0].default_value = 1.0 if mood == m else 0.0
        strength = {"day": 0.8, "sunset": 0.55, "storm": 0.35, "night": 0.15}
        for m in ("day", "sunset", "storm", "night"):
            n = self._node("NouryWorld", "HdriBG" if m == "day" else f"HdriBG_{m}")
            if n is not None:
                n.inputs[1].default_value = strength[m]
        if mood != "day" and self._node("NouryWorld", f"HdriMix_{mood}") is None:
            n = self._node("NouryWorld", "HdriBG")          # no HDRI for this mood: dim the day sky instead
            if n is not None:
                n.inputs[1].default_value = strength[mood]
        g = tuple(pal.get("ground", (0.3, 0.62, 0.28)))
        mat = "M_sand" if terrain == "coast" else ("M_snow" if snow else "M_ground")
        self.N(mat, "ColA").outputs[0].default_value = lighten(g, 0.1) + (1.0,)
        self.N(mat, "ColB").outputs[0].default_value = darken(g, 0.12 if snow else 0.2) + (1.0,)
        if self.water is not None:
            self.water.location = (0.0, 50.0, -0.12 + math.sin(t * 0.8) * 0.03)
        if night:
            self.sun.data.energy, self.sun.data.color = 0.7, (0.55, 0.65, 1.0)
            self.fill.data.energy = 1.4
        elif storm:
            self.sun.data.energy, self.sun.data.color = 1.6, (0.75, 0.82, 1.0)
            self.fill.data.energy = 0.8
        elif magical:
            self.sun.data.energy, self.sun.data.color = 2.2, (1.0, 0.82, 0.95)
            self.fill.data.energy = 0.8
        else:
            self.sun.data.energy, self.sun.data.color = (3.2 if snow else 4.0), (1.0, 0.93, 0.8)
            self.fill.data.energy = 0.8
        self.rim.data.energy = 4.0 if (magical or night) else 2.5
        self.rim.data.color = (0.85, 0.7, 1.0) if magical else ((0.6, 0.7, 1.0) if night else (0.85, 0.92, 1.0))
        for tr, base in zip(self.trees, self.tree_base):
            tr.rotation_euler = (base[0], math.sin(t * 1.6 + base[2] * 7.0) * wind * 0.035, base[2])
        for c, base in zip(self.clouds, self.cloud_base):
            x = (base[0] + t * (0.25 + wind * 0.6) + 60.0) % 120.0 - 60.0
            c.location = (x, base[1], base[2])
        if "fireflies" in props:
            for ff, (x, y, z, ph) in zip(self.fireflies, self.firefly_seed):
                ff.location = (x + math.sin(t * 0.4 + ph) * 0.6, y + math.cos(t * 0.33 + ph * 1.3) * 0.5,
                               z + math.sin(t * 0.7 + ph * 2.0) * 0.25)
                k = 0.4 + 0.6 * max(0.0, math.sin(t * 1.8 + ph * 3.0))
                ff.scale = (k, k, k)
        if snow:
            for fl, (x, y, z0, v) in zip(self.snow, self.snow_seed):
                z = 7.0 - ((t * v + z0) % 7.0)
                fl.location = (x + math.sin(t * 0.9 + z0) * 0.3 + (wind * t * 0.1) % 1.0, y, z)

    # -------------------------------------------------------------- camera
    def apply_camera(self, si, sc, local, prog, action, t, chars, line):
        kind = sc.get("camera", "wide")
        heroes = [a["key"] for a in self.actors[:2]]
        near = {k: c for k, c in chars.items() if not ("g" in c and c["g"]["slot"] in ("far", "back"))}
        xs = [c["pos"][0] for c in near.values()]
        gx = (min(xs) + max(xs)) * 0.5
        half = (max(xs) - min(xs)) * 0.5 + 0.9
        aspect = 16.0 / 9.0

        talker = line[2] if line and line[2] in chars else None
        last = None if talker else self.last_line(t, sc["start"])
        if local < 2.5:
            shot = "establish" if (si == 0 or kind == "wide") else kind
        elif talker:
            shot = "close_talker"
        elif last and t - last[1] < 1.8 and last[2] in chars:
            shot = "close_listener"
        else:
            shot = [kind, "medium", "group"][int((local - 2.5) / 5.5) % 3]
        if action == "celebrate" and local > 20.0 and not talker:
            shot = "low_hero"
        if action == "help_friend" and 2.0 <= local < 4.0:
            shot = "medium"
        if action == "run_together" and shot in ("close_talker", "close_listener"):
            shot = "tracking"

        who = None
        if shot == "close_talker":
            who = talker
        elif shot == "close_listener":
            spk = last[2]
            if spk in heroes:
                guest = next((k for k in near if k not in heroes), None)
                who = guest or (heroes[1] if spk == heroes[0] else heroes[0])
            else:
                who = min(heroes, key=lambda h: length(sub(chars[h]["pos"], chars[spk]["pos"])))

        mid = (gx, -0.05, 0.0)

        def fit(fov):
            return half / (math.tan(math.radians(fov) * 0.5) * aspect)

        fov, fstop = 40.0, 5.6
        if who is not None:
            c = chars[who]
            face, psi = c["face"], c["p"]["psi"]
            small = c["a"]["kind"] == "animal"
            fwd = (math.sin(psi), -math.cos(psi), 0.0)
            side = (math.cos(psi), math.sin(psi), 0.0)
            others = [k for k in chars if k != who]
            ref = min(others, key=lambda k: length(sub(chars[k]["pos"], c["pos"]))) if others else who
            sgn = 1.0 if chars[ref]["face"][0] > face[0] else -1.0
            dist = 1.15 if small else 1.55
            pos = add(add(add(face, scale(fwd, dist)), scale(side, 0.32 * sgn)), (0.0, -0.25, 0.05 if small else 0.03))
            look = add(face, (0.0, 0.0, -0.02 if small else -0.04))
            fov, fstop = (32.0, 2.0) if small else (30.0, 2.2)
        elif shot in ("establish", "wide", "group"):
            fov = 42.0
            d = max(8.2 - prog * 0.8, fit(fov) + 1.5) if shot != "group" else max(5.5, fit(fov) + 1.0)
            pos = add(mid, (math.sin(t * 0.05) * 0.8, -d, 2.1 if shot != "group" else 1.5))
            look = add(mid, (0.0, 1.0, 0.9 if shot != "group" else 0.85))
            fstop = 8.0
        elif shot == "tracking":
            pos = add(mid, (-1.3, -max(5.0, fit(40.0) + 1.0), 1.35))
            look = add(mid, (0.6, 0.0, 1.0))
        elif shot == "dynamic":
            pos = add(mid, (1.0 + math.sin(t * 1.3) * 0.15, -max(4.2, fit(46.0) + 0.5), 0.6))
            look = add(mid, (0.0, 0.0, 1.25))
            fov = 46.0
        elif shot == "slow_push":
            pos = add(mid, (0.2, -lerp(max(6.5, fit(40.0) + 1.0), 3.3, prog), lerp(1.6, 1.25, prog)))
            look = add(mid, (0.0, 0.0, 0.95))
            fov, fstop = lerp(40.0, 34.0, prog), 3.5
        elif shot == "close":
            pos = add(mid, (0.3, -max(3.0, fit(34.0) + 0.3), 1.2))
            look = add(mid, (0.0, -0.2, 0.95))
            fov, fstop = 34.0, 2.8
        elif shot == "low_hero":
            pos = add(mid, (math.sin(t * 0.3) * 1.2, -max(3.8, fit(44.0) + 0.8), 0.45))
            look = add(mid, (0.0, 0.4, 1.35))
            fov = 44.0
        else:   # medium
            pos = add(mid, (0.3, -max(4.2, fit(38.0) + 0.6), 1.35))
            look = add(mid, (0.0, 0.0, 1.05))
            fov = 38.0
        pos = add(pos, (math.sin(t * 0.37) * 0.04, 0.0, math.sin(t * 0.51) * 0.03))
        if self.palette(sc.get("environment", "")).get("storm"):
            pos = add(pos, (math.sin(t * 13.0) * 0.012, 0.0, math.sin(t * 17.0) * 0.01))
        d = sub(look, pos)
        dist = length(d)
        d = scale(d, 1.0 / max(1e-6, dist))
        self.cam.location = pos
        self.cam.rotation_euler = (math.acos(clamp(-d[2], -1.0, 1.0)), 0.0, math.atan2(-d[0], d[1]))
        cd = self.cam.data
        cd.lens = (cd.sensor_height * 0.5) / math.tan(math.radians(fov) * 0.5)
        cd.dof.focus_distance = dist
        cd.dof.aperture_fstop = fstop
        self.last_shot = (shot, who)
