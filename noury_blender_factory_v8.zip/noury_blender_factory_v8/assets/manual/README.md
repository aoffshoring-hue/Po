# Ressources déposées à la main

Pour les sites sans API (Kenney.nl, Quaternius.com, 3dtextures.me, freepbr.com, CGTrader…).
Ce que tu déposes ici est **prioritaire** sur les téléchargements automatiques.
Détails et noms des dossiers : `docs/BIBLIOTHEQUES_GRATUITES.md`, section 3.

Exemples :
- `textures/wood/Wood012_Color.jpg`, `Wood012_Roughness.jpg`, `Wood012_NormalGL.jpg`
- `hdri/day/mon_ciel.hdr`
- `models/bush/buisson_kenney.glb` (ou `.blend`)
- `sounds/meow/miaou.wav`

Tu es responsable de la licence des fichiers déposés ici (CC0 conseillé).

## Licence de chaque dossier
Ajoute un fichier `licence.txt` dans le dossier (ligne 1 : licence, ligne 2 : auteur), par exemple :
```
CC-BY
Jean Dupont (sketchfab.com/jeandupont)
```
Licences sans redistribution (Fab Standard, CGTrader Royalty Free, Quaternius QAL) : dépose uniquement la version
chiffrée produite par `tools/encrypt_asset.sh` — jamais le fichier d'origine, le dépôt est public.
