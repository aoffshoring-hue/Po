# Personnages professionnels

Dépose ici les fichiers livrés par l'artiste 3D (un personnage par fichier, nom = clé en minuscules) :

```
assets/characters/yakine.blend
assets/characters/nour.blend
assets/characters/zahra.blend    (optionnel : personnages secondaires humains)
```

1. Vérifie chaque fichier avant de le déposer :
   `blender -b yakine.blend --python tools/check_character.py -- Yakine`
   (personnage secondaire : ajoute sa taille, par exemple `-- Zahra 1.22`)
2. Commit + push. Au prochain épisode, l'usine charge automatiquement ces personnages
   à la place des personnages construits par le code.
3. Un fichier manquant n'est pas un problème : le personnage concerné reste en version code.
